# derived/per_source/ — 五个知识源的单源持久保存目录

> 当前状态：五源抽取层已跑通（`derived/spec/rtsp/norms.jsonl`）。`rfc/` 已由
> `scripts/build_hub.py --sources rfc` 写入完整 Fused Dataset（13 个文件）；
> 其余四源待各自规则集与口径确定后写入。

## 一、本目录定位

**本目录是五个知识源的正式单源产物持久保存目录**。区别于 `derived/spec/rtsp/` 的单源 overwrite 临时产物：

- `derived/spec/rtsp/`：当前 build 的"最后跑过的单源 build"覆盖式写入，**每次单源 build 互相覆盖**
- `derived/per_source/`：每个源独立持久保存，**单源 build 不互相覆盖**

## 二、五个目录与 kb/ 源、source_type 的映射表

| 目录名 | 对应 kb/ 源 | source_type |
|--------|-------------|-------------|
| `rfc/` | `kb/spec/` | `rfc` |
| `expert_note/` | `kb/expert_note/` | `expert_note` |
| `traffic/` | `kb/数据流量/` | `traffic_pcap` + `traffic_raw` |
| `vuln/` | `kb/历史漏洞/` | `vuln` |
| `source/` | `kb/协议实现源码/` | `source` |

## 三、写入规则

每跑通一个单源，该源产物写入对应目录，**持久保留，不被其他源覆盖**。

写入内容包括（待 Step 2.5.3 起逐步落地）：
- norms.jsonl（单源抽取的 norms）
- profile.json（单源 profile，目前等价于 expert_note profile 派生）
- state_machine.json（如适用）
- graph/entities.jsonl + graph/relations.jsonl
- meta.json

## 五、当前状态（2026-09-30）

| 目录 | 文件数 | 备注 |
|------|--------|------|
| `rfc/` | 13 | ✅ 已写入：kb/spec/rfc2326.txt 派生的 11 条 method norm，经 Fused Hub 单源 build 产出完整 Fused Dataset（11 Facts / 11 method entities / 11 lineage / meta.json）。入口 `scripts/build_hub.py --sources rfc` |
| `expert_note/` | 0 | ⏳ 89 条 norm；CR-4 error_code 与 CR-5 security_note 规则已就位，待口径确定后写入 |
| `traffic/` | 0 | ⏳ 25998 条 norm；**观测口径未定**（同一逻辑 norm 按 capture 重复 3000 次，是否跨 capture 求和需先定，见下） |
| `vuln/` | 0 | ⏳ 37 条 vuln_seed norm；规则集未覆盖 |
| `source/` | 0 | ⏳ 无 source extractor（待阶段 5） |

> 历史说明：此前本 README 记「expert_note 有用户手动预置的 13 个拷贝」，该批文件
> 已不在真实目录中（现存于 615 个测试快照 `.derived_test_snapshot_*/` 内）。
> 经逐字节校验，那 13 个文件与 `kb/expert_note/` 完全一致，可从 kb/ 恢复。

### 关于 `traffic/` 的待定口径

`message.describe` 这类 norm 在 `derived/spec/rtsp/norms.jsonl` 里有 3000 条
记录，`content` 完全相同（`method=DESCRIBE occurrences=1 protocol=rtsp`），只有
`source` 指向 3000 个不同的抓包文件。即：**同一句知识声明在 3000 个 capture 里
各被观测一次**。

当前 CR-2 规则「读到一条产一个候选」会产出 15000 个候选，挤进 5 个 Fact，
其中每个 Fact 3000 条 Claim、`method.jsonl` 单行 3.59 MB（实测）。三个候选
口径（全收 / 按 norm_id 去重 / 先聚合再投影）及其代价见
`local/pipeline_rules_design.md` §5.2 附注。**在口径确定前不写 traffic/**。

## 五、与 derived/fused/ 的关系

`derived/fused/`（待 Step 2.5.3 落地）是融合产物的目录：
- 5 源 `derived/per_source/<source>/` 各自持久保存单源产物
- `derived/fused/` 从 5 源聚合归一，**profile 完全派生，不允许人工编辑**（见 fused_schema_v1.md 条款 13）
- graph 是 facts 的派生关系视图（见 fused_schema_v1.md 条款 12）
- audit 是 fusion 过程与决策审计（见 fused_schema_v1.md 条款 14）