# -*- coding: utf-8 -*-
"""终稿数值回归校验 —— 独立从 CSV 重算，逐项比对 local/RQ1_2_Live555实验记录.md。

只读：不写任何交付物、不动 docx/CSV/VM。
"""
from __future__ import annotations

import csv
import re
import statistics
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
DOC = ROOT / "local" / "RQ1_2_Live555实验记录.md"
DATA = ROOT / "derived" / "analysis" / "data" / "rq1_2"
RAW = ROOT / "derived" / "analysis" / "qa_rq1_2" / "raw"
REPS = ("1", "2", "3", "4", "5")
EDGES = (0.0, 0.5, 1.0, 2.0, 4.0, 6.0, 8.0, 12.0, 18.0, 24.0)

doc = DOC.read_text(encoding="utf-8")
failures: list[str] = []


def num(v) -> float:
    """解析数值（剥离 % 与空白）。"""
    s = str(v).strip().replace("%", "")
    return float(s) if s else 0.0


def chk(label: str, cond: bool, detail: str = "") -> None:
    """记录一条校验结果。"""
    mark = "PASS" if cond else "FAIL"
    print(f"  [{mark}] {label}" + (f" | {detail}" if detail else ""))
    if not cond:
        failures.append(label)


def read_csv(path: Path) -> list[dict]:
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


p2 = {(r["group"], r["fuzzer"], r["rep"].strip()): r
      for r in read_csv(DATA / "rq1_2_p2.csv")}
p1 = {(r["group"], r["fuzzer"], r["rep"].strip()): r
      for r in read_csv(DATA / "rq1_2_p1.csv")}

print("[1] §6 时序差值序列（区间池化）")
pts: dict = defaultdict(list)
for r in read_csv(DATA / "rq1_2_timeseries.csv"):
    pts[(r["group"], r["fuzzer"], r["rep"].strip())].append(
        (float(r["rel_hours"]), float(r["bitmap_cvg"])))


def cell(g: str, f: str, lo: float, hi: float) -> float:
    """区间 [lo, hi) 内跨 rep 混池均值（4 位小数）。"""
    vals = [c for rep in REPS for rel, c in pts[(g, f, rep)] if lo <= rel < hi]
    return round(statistics.mean(vals), 4)


for fz, target in (("aflnet", [-0.355, 0.279, 0.420, 0.533, 0.555,
                                0.573, 0.568, 0.581, 0.549]),
                   ("chatafl", [0.368, 0.298, 0.343, 0.397, 0.444,
                                0.447, 0.463, 0.512, 0.518])):
    got = []
    for i in range(len(EDGES) - 1):
        a = cell("protorag", fz, EDGES[i], EDGES[i + 1])
        b = cell("seed_reuse", fz, EDGES[i], EDGES[i + 1])
        got.append(round(a - b, 4))
    disp = [f"{x:+.3f}" for x in got]
    exp = [f"{x:+.3f}" for x in target]
    m = re.search(r"^\| " + fz + r" \| (.+) \|$", doc, re.M)
    doc_row = [c.strip().replace("**", "")
               for c in m.group(1).split(" | ")] if m else []
    chk(f"{fz} 区间池化序列 = 文档行 = 目标",
        disp == doc_row and exp == doc_row,
        f"计算={disp} 文档={doc_row}")

print("\n[2] 覆盖率终态配对差值")
for fz, exp in (("aflnet", [0.20, 0.63, 0.52, 0.63, 0.67]),
                ("chatafl", [0.37, 0.51, 0.47, 0.54, 0.63])):
    d = [round(num(p2[("protorag", fz, r)]["bitmap_cvg"])
               - num(p2[("seed_reuse", fz, r)]["bitmap_cvg"]), 2)
         for r in REPS]
    m = statistics.mean(d)
    sd = statistics.stdev(d)
    chk(f"{fz} 终态差值序列", [round(x, 2) for x in d] == exp, str(d))
    chk(f"{fz} mean±sd 写入文档",
        f"{m:+.2f} ± {sd:.2f} pp" in doc, f"{m:+.3f}±{sd:.3f}")
all_d = [num(p2[("protorag", f, r)]["bitmap_cvg"])
         - num(p2[("seed_reuse", f, r)]["bitmap_cvg"])
         for f in ("aflnet", "chatafl") for r in REPS]
chk("pooled 10/10 +0.517±0.144",
    len(all_d) == 10 and all(x > 0 for x in all_d)
    and round(statistics.mean(all_d), 3) == 0.517
    and round(statistics.stdev(all_d), 3) == 0.144,
    f"mean={statistics.mean(all_d):+.3f} sd={statistics.stdev(all_d):.3f} "
    f"win={sum(1 for x in all_d if x > 0)}/10")

print("\n[3] n_edges 终态")
for fz, exp, mean, sd in (("aflnet", [-4, 10, 5, 25, 29], 13.0, 13.80),
                           ("chatafl", [16, 9, 13, -6, 13], 9.0, 8.75)):
    d = [int(num(p2[("protorag", fz, r)]["n_edges"])
              - num(p2[("seed_reuse", fz, r)]["n_edges"])) for r in REPS]
    chk(f"{fz} n_edges 终态",
        d == exp and round(statistics.mean(d), 1) == mean
        and round(statistics.stdev(d), 2) == sd,
        f"{d} mean={statistics.mean(d):+.1f} sd={statistics.stdev(d):.2f}")

print("\n[4] P1 n_edges 归因 (A)")
for fz, pa, pb, exp in (("aflnet", 22.4, 8.8, [14, 15, 12, 13, 14]),
                         ("chatafl", 76.4, 42.4, [32, 32, 35, 34, 37])):
    a = statistics.mean([num(p1[("protorag", fz, r)]["n_edges"]) for r in REPS])
    b = statistics.mean([num(p1[("seed_reuse", fz, r)]["n_edges"]) for r in REPS])
    d = [int(num(p1[("protorag", fz, r)]["n_edges"])
              - num(p1[("seed_reuse", fz, r)]["n_edges"])) for r in REPS]
    chk(f"{fz} P1 均值 {pa} vs {pb}", round(a, 1) == pa and round(b, 1) == pb,
        f"{a:.1f} vs {b:.1f}")
    chk(f"{fz} P1 逐rep", d == exp, str(d))

print("\n[5] 归一化覆盖率 §3.4")
for fz, exp_mean, exp_sd, exp_ratio in (("aflnet", 4.263, 2.306, 0.77),
                                         ("chatafl", -5.322, 0.852, 1.29)):
    ds, rs = [], []
    for r in REPS:
        ea = num(p2[("protorag", fz, r)]["execs_done"])
        eb = num(p2[("seed_reuse", fz, r)]["execs_done"])
        ca = num(p2[("protorag", fz, r)]["bitmap_cvg"])
        cb = num(p2[("seed_reuse", fz, r)]["bitmap_cvg"])
        ds.append(ca / ea * 1e6 - cb / eb * 1e6)
        rs.append(ea / eb)
    m = statistics.mean(ds)
    sd = statistics.stdev(ds)
    rm = statistics.mean(rs)
    chk(f"{fz} 归一化 mean±sd",
        round(m, 3) == exp_mean and round(sd, 3) == exp_sd, f"{m:+.3f}±{sd:.3f}")
    chk(f"{fz} 执行量比均值 {exp_ratio}", round(rm, 2) == exp_ratio, f"{rm:.3f}")

print("\n[6] 崩溃与挂起")
hangs = {"protorag/aflnet": [0, 2, 0, 0, 0],
         "protorag/chatafl": [161, 116, 3, 100, 65],
         "seed_reuse/aflnet": [0, 0, 0, 0, 0],
         "seed_reuse/chatafl": [0, 194, 2, 220, 0]}
tot_h = sum(sum(v) for v in hangs.values())
chat_h = sum(sum(hangs[k]) for k in ("protorag/chatafl", "seed_reuse/chatafl"))
chk("挂起合计 863", tot_h == 863, str(tot_h))
chk("chatafl 半侧 861 / aflnet 2", chat_h == 861 and tot_h - chat_h == 2,
    f"{chat_h} / {tot_h - chat_h}")
crashes = {"seed_reuse/chatafl": [15, 4, 8, 0, 0],
           "seed_reuse/aflnet": [44, 0, 3, 0, 0],
           "protorag/chatafl": [0, 1, 0, 0, 0],
           "protorag/aflnet": [0, 0, 0, 0, 0]}
tc = sum(sum(v) for v in crashes.values())
base = sum(sum(crashes[k]) for k in ("seed_reuse/chatafl", "seed_reuse/aflnet"))
chk("崩溃 75 / 基线 74 (98.7%)", tc == 75 and base == 74,
    f"total={tc} base={base} ({base / tc * 100:.1f}%)")
chk("aflnet 基线 47 / chatafl 基线 27 / protorag 1",
    sum(crashes["seed_reuse/aflnet"]) == 47
    and sum(crashes["seed_reuse/chatafl"]) == 27
    and sum(crashes["protorag/chatafl"]) == 1)

print("\n[7] 散文核查 §5.5")
prose = {"seed_reuse/aflnet": (47, 0, 0), "seed_reuse/chatafl": (27, 27, 26),
         "protorag/chatafl": (1, 1, 1), "protorag/aflnet": (0, 0, 0)}
ts = sum(v[0] for v in prose.values())
tw = sum(v[1] for v in prose.values())
ts2 = sum(v[2] for v in prose.values())
chk("75 样本 / 28 含散文 / 27 含强散文", ts == 75 and tw == 28 and ts2 == 27,
    f"{ts}/{tw}/{ts2}")
chk("只有 chatafl 半侧含散文 (28 = 27 + 1)",
    prose["seed_reuse/chatafl"][1] + prose["protorag/chatafl"][1] == 28
    and prose["seed_reuse/aflnet"][1] == 0)

print("\n[8] P1 队列规模 (A) 8.0x / 6.4x")
p1q: dict = {}
for g in ("protorag", "seed_reuse"):
    for fz in ("chatafl", "aflnet"):
        vs = []
        for rep in range(1, 6):
            lines = [l.strip() for l in
                     open(RAW / f"{g}_{fz}_r{rep}.plot_data", encoding="utf-8",
                          errors="replace")
                     if not l.startswith("#") and l.strip()]
            vs.append(int([x.strip().rstrip(",") for x in lines[0].split()][3]))
        p1q[(g, fz)] = vs
chk("chatafl protorag 1344 / seed_reuse 169",
    p1q[("protorag", "chatafl")][0] == 1344
    and p1q[("seed_reuse", "chatafl")] == [169] * 5, str(p1q))
chk("aflnet protorag 51 / seed_reuse 8",
    p1q[("protorag", "aflnet")][:3] == [51, 51, 51]
    and p1q[("seed_reuse", "aflnet")] == [8] * 5, str(p1q))
chk("chatafl 8.0x / aflnet 6.4x",
    round(1344 / 169, 1) == 8.0 and round(51 / 8, 1) == 6.4,
    f"{1344 / 169:.2f}x {51 / 8:.2f}x")

print("\n[9] docx 表4 四行数值")
for r in read_csv(DATA / "rq1_2_summary.csv"):
    chk(f"表4 行{r['docx_row']} 数值在文档中",
        r["n_states_P1"] in doc and r["n_edges_P2"] in doc
        and r["paths_total_P2"] in doc, str(dict(r)))

print("\n[10] 错误表述不得残留")
for pat in ("两组基线的崩溃样本都混有", "只有 aflnet 半侧干净；",
            "在控制执行量后消失", "chatafl 半侧的覆盖率优势不成立",
            "0.5 h 时点为**统计持平**"):
    chk(f"无残留: {pat}", pat not in doc)
# 点时刻口径只允许出现在「修订沿革」与明确标注为对账用途的附表段落中，
# 且每一处都必须自我声明为非论断口径（不得被误读为本文表格口径）。
legacy = [ln for ln in doc.splitlines() if "abs(rel_hours" in ln]
bad = [ln for ln in legacy
       if not ("v7 终稿再次统一" in ln or "对账" in ln or "逐格一致" in ln)]
chk("点时刻口径每处均自我声明为非论断口径（修订沿革 / 对账附表）",
    not bad, f"命中 {len(legacy)} 处，未声明 {len(bad)} 处")
# 且 §6 主表必须是区间池化口径
chk("§6 主表为区间池化口径",
    "## 6. 时序覆盖率（区间池化口径）" in doc
    and "| group | fuzzer | 0-0.5h | 0.5-1h | 1-2h | 2-4h | 4-6h | 6-8h | "
        "8-12h | 12-18h | 18-24h |" in doc)

print("\n[11] (D) 并列披露与中介量限定")
for pat in ("中介量", "1.19", "1.78", "+4.263", "2.306", "-5.322", "0.852",
            "0.78", "0.86", "exec_timeout: 1000", "861"):
    chk(f"含 (D) 要素: {pat}", pat in doc)
chk("(D) 归因纪律段落存在", "不足以单独作为" in doc and "中介量" in doc)

print("\n[12] n_edges 中间态标注")
chk("n_edges 中间态标注存在",
    "+4/-2/-1/-1/+28" in doc and "中间态" in doc and "不是 24 h 终态" in doc)

print("\n[13] 区间池化目标序列在文中")
chk("aflnet 区间池化序列逐格一致",
    "| aflnet | -0.355 | +0.279 | +0.420 | +0.533 | +0.555 | +0.573 | "
    "+0.568 | +0.581 | +0.549 |" in doc)

print("\n" + "=" * 52)
print("总判定:", "全部通过" if not failures else f"{len(failures)} 项未通过")
for f in failures:
    print("  -", f)
sys.exit(0 if not failures else 1)
