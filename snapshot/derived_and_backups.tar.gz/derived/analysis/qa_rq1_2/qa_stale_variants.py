#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA 终检二: 排查 RQ3 文档中残留的多个'中间态变体'数字, 并核对记录 §7 表。"""
from __future__ import annotations

import os
import statistics
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")
TZ8 = timezone(timedelta(hours=8))


def parse_plot(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) <= 12:
                continue
            rows.append(p)
    return rows


def pf(s):
    return float(s.strip().rstrip("%"))


D = {}
for g in ("seed_reuse", "protorag"):
    for f in ("chatafl", "aflnet"):
        for r in range(1, 6):
            rows = parse_plot(os.path.join(RAW, f"{g}_{f}_r{r}.plot_data"))
            D[(g, f, r)] = {"rows": rows, "t0": int(float(rows[0][0]))}

all_ts = sorted({int(float(p[0])) for v in D.values() for p in v["rows"]})


def state_at(ts):
    out = {}
    for k, d in D.items():
        sel = None
        for p in d["rows"]:
            if int(float(p[0])) <= ts:
                sel = p
            else:
                break
        if sel is None:
            sel = d["rows"][0]
        out[k] = {
            "cvg": pf(sel[6]),
            "crash": int(float(sel[7])),
            "paths": int(float(sel[3])),
            "n_edges": int(float(sel[12])),
        }
    return out


def nedges_diff(st, f):
    return [st[("protorag", f, r)]["n_edges"] - st[("seed_reuse", f, r)]["n_edges"]
            for r in range(1, 6)]


def cov_diff(st, f):
    return [round(st[("protorag", f, r)]["cvg"] - st[("seed_reuse", f, r)]["cvg"], 6)
            for r in range(1, 6)]


VARIANTS = [
    ("+4/-2/-1/-1/+28 (QA验收报告:513, 主理人口头)", [4, -2, -1, -1, 28]),
    ("+1/-2/-1/-1/+28 (技术方案:1254,1726)", [1, -2, -1, -1, 28]),
]

print("=" * 96)
print("A. RQ3 文档中 n_edges 差值'变体'溯源 —— 哪个是 24h 终态?")
print("=" * 96)
for label, seq in VARIANTS:
    for f in ("aflnet", "chatafl"):
        hit = []
        for ts in all_ts:
            if nedges_diff(state_at(ts), f) == seq:
                hit.append(ts)
        term = nedges_diff(state_at(all_ts[-1]), f)
        print(f"\n  变体「{label}」 fuzzer={f}")
        if hit:
            print(f"    命中 {len(hit)} 个时刻, 窗口 "
                  f"{datetime.fromtimestamp(hit[0], TZ8):%m-%d %H:%M} ~ "
                  f"{datetime.fromtimestamp(hit[-1], TZ8):%m-%d %H:%M}")
        else:
            print("    ★ 任何时刻均不命中")
        print(f"    24h 终态实测 = {term}")

print()
print("=" * 96)
print("B. RQ3 文档中覆盖率反超区间'变体'溯源")
print("=" * 96)
for label, lo, hi, mean in (("+0.37~+0.69 (技术方案:2104)", 0.37, 0.69, None),
                             ("+0.21~+0.66 (主理人口头)", 0.21, 0.66, 0.52)):
    for f in ("aflnet", "chatafl"):
        hit = []
        for ts in all_ts:
            d = cov_diff(state_at(ts), f)
            if abs(min(d) - lo) < 0.005 and abs(max(d) - hi) < 0.005:
                hit.append(ts)
        term = cov_diff(state_at(all_ts[-1]), f)
        print(f"\n  变体「{label}」 fuzzer={f}")
        if hit:
            print(f"    命中 {len(hit)} 个时刻, 窗口 "
                  f"{datetime.fromtimestamp(hit[0], TZ8):%m-%d %H:%M} ~ "
                  f"{datetime.fromtimestamp(hit[-1], TZ8):%m-%d %H:%M}")
        else:
            print("    ★ 任何时刻均不命中")
        print(f"    24h 终态实测 = {term}  "
              f"min={min(term):+.2f} max={max(term):+.2f} "
              f"mean={statistics.fmean(term):+.4f}")

print()
print("=" * 96)
print("C. 记录 §7 表 (中间态) 与我方 10-24 20:00 绝对边界快照的差异")
print("=" * 96)
YEAR = datetime.fromtimestamp(D[("seed_reuse", "aflnet", 1)]["t0"], TZ8).year
CUT = datetime(YEAR, 10, 24, 20, 0, 0, tzinfo=TZ8).timestamp()
st_abs = state_at(CUT)
st_rel = {}
for k, d in D.items():
    sel = [p for p in d["rows"] if (int(float(p[0])) - d["t0"]) / 3600.0 <= 8.98]
    p = sel[-1] if sel else d["rows"][0]
    st_rel[k] = {"cvg": pf(p[6]), "paths": int(float(p[3]))}

REC = {  # 记录 §7 表声称的中间态值
    ("seed_reuse", "aflnet", 1): (9.83, 1323), ("seed_reuse", "aflnet", 2): (9.77, 1257),
    ("seed_reuse", "aflnet", 3): (9.88, 1406), ("seed_reuse", "aflnet", 4): (9.74, 1365),
    ("seed_reuse", "aflnet", 5): (9.88, 1439), ("seed_reuse", "chatafl", 1): (10.01, 1235),
    ("seed_reuse", "chatafl", 2): (9.90, 1234), ("seed_reuse", "chatafl", 3): (9.92, 1198),
    ("seed_reuse", "chatafl", 4): (9.82, 1183), ("seed_reuse", "chatafl", 5): (9.90, 1247),
    ("protorag", "aflnet", 1): (10.21, 1118), ("protorag", "aflnet", 2): (10.44, 1267),
    ("protorag", "aflnet", 3): (10.29, 1263), ("protorag", "aflnet", 4): (10.43, 1303),
    ("protorag", "aflnet", 5): (10.51, 1255), ("protorag", "chatafl", 1): (10.36, 2249),
    ("protorag", "chatafl", 2): (10.35, 2288), ("protorag", "chatafl", 3): (10.27, 2172),
    ("protorag", "chatafl", 4): (10.32, 2257), ("protorag", "chatafl", 5): (10.48, 2281),
}
print(f"{'container':<26}{'rec_cvg':>9}{'abs_cvg':>9}{'d':>8}"
      f"{'rec_paths':>11}{'abs_paths':>11}{'d':>7}")
maxcd = 0.0
maxpd = 0
for g in ("seed_reuse", "protorag"):
    for f in ("chatafl", "aflnet"):
        for r in range(1, 6):
            rc, rp = REC[(g, f, r)]
            ac = st_abs[(g, f, r)]["cvg"]
            ap = st_abs[(g, f, r)]["paths"]
            maxcd = max(maxcd, abs(rc - ac))
            maxpd = max(maxpd, abs(rp - ap))
            print(f"{g+'/'+f+'/r'+str(r):<26}{rc:>9.2f}{ac:>9.2f}{rc-ac:>+8.2f}"
                  f"{rp:>11}{ap:>11}{rp-ap:>+7}")
print(f"\n  覆盖率最大偏差 = {maxcd:.2f} pp ; 路径数最大偏差 = {maxpd}")
print("  (记录 §7 用的是 rel_hours<=8.98 口径, 与绝对 20:00 边界差 ~2-4 分钟, "
      "路径数差属正常采样时刻差)")

print()
print("=" * 96)
print("D. 中间态'崩溃 8 个全在 seed_reuse_aflnet' 的可复现性最终裁定")
print("=" * 96)
st_cut = state_at(CUT)
print(f"  在 10-24 20:00 绝对边界: 全 20 容器崩溃合计 = {sum(v['crash'] for v in st_cut.values())}")
print(f"    崩溃明细 = { {('%s_%s_r%d'%k): v['crash'] for k,v in st_cut.items() if v['crash']>0} }")
print(f"  -> 记录 §7 '中间态全部 20 个容器崩溃数为 0: True' = "
      f"{'✔ 属实' if sum(v['crash'] for v in st_cut.values())==0 else '✘ 不符'}")
print()
print("  'r1=7, r3=1 (合计 8, 全在 seed_reuse_aflnet)' 组合:")
hit = []
for ts in all_ts:
    st = state_at(ts)
    c = {k: v["crash"] for k, v in st.items() if v["crash"] > 0}
    if c == {("seed_reuse", "aflnet", 1): 7, ("seed_reuse", "aflnet", 3): 1}:
        hit.append(ts)
if hit:
    print(f"    成立窗口 {datetime.fromtimestamp(hit[0], TZ8):%m-%d %H:%M} ~ "
          f"{datetime.fromtimestamp(hit[-1], TZ8):%m-%d %H:%M} (持续 "
          f"{(hit[-1]-hit[0])/3600:.2f}h)")
    print(f"    ★ 起点晚于 20:00 边界 "
          f"{(hit[0]-CUT)/60:.0f} 分钟 -> 该组合是 20:00 **之后** 才成立的中间态")
    ts = hit[0]
    st = state_at(ts)
    gm = {}
    for g in ("seed_reuse", "protorag"):
        for f in ("chatafl", "aflnet"):
            gm[f"{g}/{f}"] = statistics.fmean([st[(g, f, r)]["cvg"] for r in range(1, 6)])
    print(f"    该时刻 4 组覆盖率均值: "
          + ", ".join(f"{k}={v:.4f}%" for k, v in gm.items()))
    print(f"    round2dp -> "
          + ", ".join(f"{k}={round(v,2):.2f}" for k, v in gm.items()))
    print(f"    主理人给的中间态覆盖率: seed/chat 9.91, seed/afln 9.82, "
          f"prot/chat 10.36, prot/afln 10.38")
    print(f"    => 与主理人覆盖率{'一致' if (round(gm['seed_reuse/chatafl'],2)==9.91 and round(gm['seed_reuse/aflnet'],2)==9.82 and round(gm['protorag/chatafl'],2)==10.36 and round(gm['protorag/aflnet'],2)==10.38) else '不完全一致'}；"
          f"但崩溃组合在此刻{'成立' if hit else '不成立'} —— "
          f"两者在**同一时刻**{'能同时成立' if hit else '★不能同时成立★'}")
else:
    print("    ★ 任何时刻都不成立")
