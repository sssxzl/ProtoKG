#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA: docx 当前版 vs 回填前备份 逐单元格 diff —— 证明只有表4 数据区被改动。"""
from __future__ import annotations

import os
import sys

import docx

CUR = r"E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx"
BAKS = [
    r"E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx.bak_20261025_124744",
    r"E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx.bak_20261025_124817",
]


def cell_text(cell):
    return " ".join(p.text.strip() for p in cell.paragraphs if p.text.strip()).strip()


def grid(doc):
    return [[[cell_text(c) for c in r.cells] for r in t.rows] for t in doc.tables]


def paras(doc):
    return [p.text for p in doc.paragraphs]


def main():
    cur = docx.Document(CUR)
    cg = grid(cur)
    cp = paras(cur)
    print(f"当前版: tables={len(cg)}  paragraphs={len(cp)}\n")

    for bak in BAKS:
        if not os.path.exists(bak):
            print(f"--- 备份不存在: {bak}")
            continue
        b = docx.Document(bak)
        bg = grid(b)
        bp = paras(b)
        print("=" * 88)
        print(f"备份: {os.path.basename(bak)}   tables={len(bg)}  paragraphs={len(bp)}")
        print("=" * 88)

        # 段落 diff
        if len(bp) != len(cp):
            print(f"  ★ 段落数变化: {len(bp)} -> {len(cp)}")
        pdiff = [
            (i, bp[i], cp[i]) for i in range(min(len(bp), len(cp))) if bp[i] != cp[i]
        ]
        print(f"  段落差异数 = {len(pdiff)}")
        for i, a, c in pdiff[:10]:
            print(f"    para[{i}]: '{a[:70]}' -> '{c[:70]}'")

        # 表格数
        print(f"  tables 数: {len(bg)} -> {len(cg)}  "
              f"{'OK' if len(bg) == len(cg) else '★FAIL★'}")

        changed_tables = []
        for i in range(min(len(bg), len(cg))):
            b_rows, c_rows = bg[i], cg[i]
            if len(b_rows) != len(c_rows) or len(b_rows[0]) != len(c_rows[0]):
                changed_tables.append((i, "SHAPE_CHANGE",
                                       (len(b_rows), len(b_rows[0])),
                                       (len(c_rows), len(c_rows[0]))))
                continue
            cells_changed = []
            for ri, (br, cr) in enumerate(zip(b_rows, c_rows)):
                for ci, (bc, cc) in enumerate(zip(br, cr)):
                    if bc != cc:
                        cells_changed.append((ri, ci, bc, cc))
            if cells_changed:
                changed_tables.append((i, "CELLS", cells_changed, None))

        print(f"  内容发生变化的表: {[x[0] for x in changed_tables]}")
        for ti, kind, payload, extra in changed_tables:
            print(f"    tables[{ti}] {kind}")
            if kind == "SHAPE_CHANGE":
                print(f"      形状 {payload} -> {extra}")
            else:
                for ri, ci, bc, cc in payload:
                    print(f"      r{ri}c{ci}: '{bc}'  ->  '{cc}'")

        # 其它表是否仍为"仅标签列有值、其余全空"
        print("\n  --- 邻近表 (5/6/7) 数据列是否仍为空 ---")
        for ti in (5, 6, 7):
            rows = cg[ti]
            datane = [
                (ri, ci, v) for ri, row in enumerate(rows)
                for ci, v in enumerate(row) if ri > 0 and ci >= 2 and v.strip()
            ]
            labne = [
                (ri, ci, v) for ri, row in enumerate(rows)
                for ci, v in enumerate(row) if ri > 0 and ci < 2 and v.strip()
            ]
            print(f"    tables[{ti}]: 数据列(col2..col8)非空={len(datane)} "
                  f"{'★FAIL 应全空' if datane else 'OK'}   "
                  f"标签列(col0,col1)非空={len(labne)} (模板固有)")
            if datane:
                print(f"      ★ {datane[:10]}")
        print()


if __name__ == "__main__":
    sys.exit(main())
