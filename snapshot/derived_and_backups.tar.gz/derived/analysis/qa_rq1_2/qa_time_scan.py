#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA: 反扫绝对时刻, 定位主理人 '10-24 20:00 中间态' 快照的真实时刻并验证其全部数字。
   同时验证本地 timeseries.csv 与 VM 原始 plot_data 是否一致。
"""
from __future__ import annotations

import csv
import os
import statistics
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")
CSV_DIR = os.path.join(os.path.dirname(HERE), "data", "rq1_2")
TZ8 = timezone(timedelta(hours=8))
GROUPS = ("seed_reuse", "protorag")
FUZZERS = ("chatafl", "aflnet")
REPS = (1, 2, 3, 4, 5)


def parse_plot(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) <= 12:
                continue
            rows.append(p)
    return rows


def parse_stats(path):
    out = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if ":" in line:
                k, _, v = line.partition(":")
                out[k.strip()] = v.strip()
    return out


def pct(s):
    return float(s.strip().rstrip("%"))


D = {}
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            tag = f"{g}_{f}_r{r}"
            rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
            D[(g, f, r)] = {"rows": rows, "fs": parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats")),
                           "t0": int(float(rows[0][0]))}

YEAR = datetime.fromtimestamp(D[("seed_reuse", "aflnet", 1)]["t0"], TZ8).year


def state_at(ts):
    """返回绝对时刻 ts 时各容器状态 (取 <= ts 的最后一行)。"""
    out = {}
    for k, d in D.items():
        sel = None
        for p in d["rows"]:
            if int(float(p[0])) <= ts:
                sel = p
            else:
                break
        if sel is None:
            sel = d["rows"][0]
        out[k] = {
            "cvg": pct(sel[6]), "crashes": int(float(sel[7])),
            "hangs": int(float(sel[8])), "paths": int(float(sel[3])),
            "n_states": int(float(sel[11])), "n_edges": int(float(sel[12])),
        }
    return out


def group_means(st, field):
    return {(g, f): statistics.fmean([st[(g, f, r)][field] for r in REPS])
            for g in GROUPS for f in FUZZERS}


# ---- 候选时刻集合: 所有容器 plot_data 采样的并集 (分钟粒度) ----
all_ts = sorted({int(float(p[0])) for d in D.values() for p in d["rows"]})

TARGET_CVG = {("seed_reuse", "chatafl"): 9.91, ("seed_reuse", "aflnet"): 9.82,
              ("protorag", "chatafl"): 10.36, ("protorag", "aflnet"): 10.38}
TARGET_CRASH = {("seed_reuse", "aflnet", 1): 7, ("seed_reuse", "aflnet", 3): 1}

print("=" * 92)
print("A. 反扫: 找出同时满足 [4 组覆盖均值] + [崩溃 r1=7, r3=1 且其余为 0] 的时刻窗口")
print("=" * 92)
hits = []
for ts in all_ts:
    st = state_at(ts)
    gm = group_means(st, "cvg")
    ok_cvg = all(abs(gm[k] - v) < 0.005 for k, v in TARGET_CVG.items())
    crash = {k: v["crashes"] for k, v in st.items() if v["crashes"] > 0}
    ok_crash = crash == TARGET_CRASH
    if ok_cvg and ok_crash:
        hits.append((ts, gm, crash))
if hits:
    lo, hi = hits[0][0], hits[-1][0]
    print(f"  命中 {len(hits)} 个采样时刻")
    print(f"  窗口: {datetime.fromtimestamp(lo, TZ8):%Y-%m-%d %H:%M}  ~  "
          f"{datetime.fromtimestamp(hi, TZ8):%Y-%m-%d %H:%M}  (UTC+8)")
    print(f"  持续 {(hi-lo)/3600:.2f} 小时")
    # n_edges 差值在该窗口内是否稳定
    ne_sets = set()
    for ts, _, _ in hits:
        st = state_at(ts)
        for f in FUZZERS:
            d = [st[("protorag", f, r)]["n_edges"] - st[("seed_reuse", f, r)]["n_edges"]
                 for r in REPS]
            ne_sets.add((f, tuple(d)))
    for f, d in sorted(ne_sets):
        print(f"  窗口内 {f} n_edges 差值集合 = {list(d)}")
else:
    print("  ★ 未找到同时满足的窗口")
    # 放宽: 分别看
    print("\n  放宽诊断:")
    cvghits = []
    crhits = []
    for ts in all_ts:
        st = state_at(ts)
        gm = group_means(st, "cvg")
        if all(abs(gm[k] - v) < 0.005 for k, v in TARGET_CVG.items()):
            cvghits.append(ts)
        crash = {k: v["crashes"] for k, v in st.items() if v["crashes"] > 0}
        if crash == TARGET_CRASH:
            crhits.append(ts)
    if cvghits:
        print(f"    覆盖 4 组均值同时匹配: {len(cvghits)} 个时刻, "
              f"{datetime.fromtimestamp(cvghits[0], TZ8):%m-%d %H:%M} ~ "
              f"{datetime.fromtimestamp(cvghits[-1], TZ8):%m-%d %H:%M}")
    if crhits:
        print(f"    崩溃 r1=7/r3=1 匹配: {len(crhits)} 个时刻, "
              f"{datetime.fromtimestamp(crhits[0], TZ8):%m-%d %H:%M} ~ "
              f"{datetime.fromtimestamp(crhits[-1], TZ8):%m-%d %H:%M}")
    else:
        print("    ★ 崩溃 r1=7/r3=1 组合在任何时刻都不成立 —— 实际崩溃演变见下")

print()
print("=" * 92)
print("B. 崩溃计数的完整时间演变 (绝对时刻 -> 各容器累计)")
print("=" * 92)
prev = {}
changes = []
for ts in all_ts:
    st = state_at(ts)
    cur = {k: v["crashes"] for k, v in st.items()}
    if cur != prev:
        changes.append((ts, dict(cur)))
        prev = cur
for ts, cur in changes:
    nz = {k: v for k, v in cur.items() if v > 0}
    print(f"  {datetime.fromtimestamp(ts, TZ8):%m-%d %H:%M}  合计={sum(cur.values()):>3}  "
          f"{ {f'{g[:4]}/{f[:4]}/r{r}': n for (g, f, r), n in nz.items()} }")

print()
print("=" * 92)
print("C. 本地 timeseries.csv vs VM 原始 plot_data 一致性校验")
print("=" * 92)
ts_csv = {}
with open(os.path.join(CSV_DIR, "rq1_2_timeseries.csv"), "r", encoding="utf-8-sig",
          newline="") as fh:
    for row in csv.DictReader(fh):
        ts_csv.setdefault((row["group"], row["fuzzer"], int(row["rep"])), []).append(
            (float(row["rel_hours"]), float(row["bitmap_cvg"]), int(row["paths_total"]))
        )
for k in ts_csv:
    ts_csv[k].sort()

print(f"{'container':<28}{'csv_rows':>10}{'raw_rows':>10}{'relh_max_csv':>14}"
      f"{'relh_max_raw':>14}{'cvg_last_csv':>14}{'cvg_last_raw':>14}{'paths_csv':>11}{'paths_raw':>11}")
all_ok = True
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            csvr = ts_csv[(g, f, r)]
            rawr = D[(g, f, r)]["rows"]
            raw_rel = [(int(float(p[0])) - D[(g, f, r)]["t0"]) / 3600.0 for p in rawr]
            raw_cvg = pct(rawr[-1][6])
            raw_paths = int(float(rawr[-1][3]))
            # 末尾对齐 (CSV 可能少最后一帧)
            n = min(len(csvr), len(rawr))
            cvg_d = max(abs(csvr[-1][1] - pct(rawr[-1][6])), abs(csvr[-1][1] - pct(rawr[-2][6])))
            paths_d = abs(csvr[-1][2] - raw_paths)
            ok = cvg_d < 1e-9 and paths_d == 0
            all_ok &= ok
            print(f"{g+'/'+f+'/r'+str(r):<28}{len(csvr):>10}{len(rawr):>10}"
                  f"{csvr[-1][0]:>14.4f}{raw_rel[-1]:>14.4f}"
                  f"{csvr[-1][1]:>14.2f}{raw_cvg:>14.2f}"
                  f"{csvr[-1][2]:>11}{raw_paths:>11}  {'OK' if ok else '★diff'}")
print(f"  timeseries.csv 末帧与 plot_data 一致: {all_ok}")

print()
print("  --- timeseries.csv 逐行抽样比对 (每容器 5 个等距点) ---")
maxdev = 0.0
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            csvr = ts_csv[(g, f, r)]
            rawr = D[(g, f, r)]["rows"]
            raw_rel = [(int(float(p[0])) - D[(g, f, r)]["t0"]) / 3600.0 for p in rawr]
            for idx in (0, len(csvr) // 4, len(csvr) // 2, 3 * len(csvr) // 4, len(csvr) - 1):
                if idx >= len(csvr):
                    continue
                rel, cvg, pth = csvr[idx]
                # 找最近 raw 行
                j = min(range(len(raw_rel)), key=lambda i: abs(raw_rel[i] - rel))
                d1 = abs(cvg - pct(rawr[j][6]))
                d2 = abs(pth - int(float(rawr[j][3])))
                maxdev = max(maxdev, d1)
                if d1 > 1e-9 or d2 != 0:
                    print(f"    ★ {g}/{f}/r{r} idx={idx} rel={rel:.4f}: "
                          f"csv cvg={cvg} paths={pth} vs raw cvg={pct(rawr[j][6])} "
                          f"paths={int(float(rawr[j][3]))}")
print(f"  抽样最大 cvg 偏差 = {maxdev}  "
      f"{'→ timeseries.csv 与原始 plot_data 一致' if maxdev == 0 else '→ 存在偏差'}")
