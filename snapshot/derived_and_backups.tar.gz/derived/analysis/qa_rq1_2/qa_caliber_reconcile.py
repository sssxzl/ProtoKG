#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA 口径对齐复核: 把 §5.1/§5.2 统一到记录 v6 的权威口径 (区间桶 [lo,hi), 跨rep池化),
   并做多口径敏感性对照。用于修正 QA 报告 §5 的内部矛盾。"""
from __future__ import annotations

import csv
import os
import statistics

HERE = os.path.dirname(os.path.abspath(__file__))
CSV_DIR = os.path.join(os.path.dirname(HERE), "data", "rq1_2")
RAW = os.path.join(HERE, "raw")

EDGES = [(0, 0.5), (0.5, 1), (1, 2), (2, 4), (4, 6), (6, 8), (8, 12), (12, 18), (18, 24)]
GROUPS = ("seed_reuse", "protorag")
FUZZERS = ("chatafl", "aflnet")
REPS = (1, 2, 3, 4, 5)


def load_csv_series():
    """rel_hours 已 4 位小数 (采集脚本写出精度)。"""
    out = {}
    with open(os.path.join(CSV_DIR, "rq1_2_timeseries.csv"), "r",
              encoding="utf-8-sig", newline="") as fh:
        for row in csv.DictReader(fh):
            k = (row["group"], row["fuzzer"], int(row["rep"]))
            out.setdefault(k, []).append(
                (float(row["rel_hours"]), float(row["bitmap_cvg"])))
    for k in out:
        out[k].sort()
    return out


def load_raw_series():
    """rel_hours 未舍入 (直接从 plot_data 重算)。"""
    def pp(p):
        r = []
        with open(p, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                x = [i.strip() for i in line.split(",")]
                if len(x) <= 12:
                    continue
                r.append(x)
        return r

    out = {}
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                rows = pp(os.path.join(RAW, f"{g}_{f}_r{r}.plot_data"))
                t0 = int(float(rows[0][0]))
                out[(g, f, r)] = [
                    ((int(float(x[0])) - t0) / 3600.0,
                     float(x[6].strip().rstrip("%"))) for x in rows]
    return out


def interval_pooled(series, lo, hi):
    """区间桶 [lo,hi) 跨rep池化均值。"""
    vals = [c for k, v in series.items()
            for rel, c in v if lo <= rel < hi]
    return statistics.mean(vals) if vals else None


def interval_perrep(series, lo, hi):
    """区间桶 [lo,hi) 先按rep求均值, 再跨rep配对。"""
    per = {}
    for (g, f, r), v in series.items():
        vals = [c for rel, c in v if lo <= rel < hi]
        if vals:
            per[(g, f, r)] = statistics.mean(vals)
    return per


def report(series, label):
    print("=" * 96)
    print(f"口径源: {label}")
    print("=" * 96)
    pooled = {}
    per = {}
    print("\n--- 区间桶池化均值 (%) ---")
    print("%-10s %14s %14s %14s %14s" % ("区间", "seed/aflnet", "seed/chatafl",
                                          "prot/aflnet", "prot/chatafl"))
    for lo, hi in EDGES:
        line = "%-10s" % ("%g-%gh" % (lo, hi))
        for g in GROUPS:
            for f in FUZZERS:
                m = interval_pooled(series, lo, hi)
                pooled[(lo, hi, g, f)] = m
                line += "%14s" % (("%.3f" % m) if m is not None else "NA")
        print(line)

    print("\n--- 反超差值 (区间池化, pp) ---")
    print("%-10s %16s %16s" % ("区间", "aflnet", "chatafl"))
    for lo, hi in EDGES:
        line = "%-10s" % ("%g-%gh" % (lo, hi))
        for f in FUZZERS:
            d = pooled[(lo, hi, "protorag", f)] - pooled[(lo, hi, "seed_reuse", f)]
            line += "%+16.4f" % d
        print(line)

    print("\n--- 逐 rep 配对差值 + win rate (先按rep求均值再跨rep配对) ---")
    for f in FUZZERS:
        print(f"  --- {f} ---")
        for lo, hi in EDGES:
            pr = interval_perrep(series, lo, hi)
            diffs = []
            for r in REPS:
                a, b = pr.get(("protorag", f, r)), pr.get(("seed_reuse", f, r))
                if a is not None and b is not None:
                    diffs.append(round(a - b, 3))
            win = sum(1 for x in diffs if x > 0)
            print(f"    {lo:g}-{hi:g}h  per_rep={diffs}  win={win}/{len(diffs)}  "
                  f"mean={statistics.fmean(diffs):+.4f}" if diffs else "    NA")
    return pooled, per


def main():
    csv_series = load_csv_series()
    raw_series = load_raw_series()

    pooled_csv, per_csv = report(csv_series, "rq1_2_timeseries.csv (rel_hours 4位小数)")
    print()
    pooled_raw, per_raw = report(raw_series, "VM 原始 plot_data (rel_hours 未舍入)")

    print()
    print("=" * 96)
    print("池化均值: CSV(4dp) vs 原始(未舍入) 逐格差")
    print("=" * 96)
    md = 0.0
    for lo, hi in EDGES:
        for g in GROUPS:
            for f in FUZZERS:
                md = max(md, abs(pooled_csv[(lo, hi, g, f)]
                                 - pooled_raw[(lo, hi, g, f)]))
    print(f"  最大差 = {md:.6f} pp")

    print()
    print("=" * 96)
    print("★ 对照记录 v6 §6 表格 (记录声称: 0-0.5h seed/afln 9.302, seed/chat 9.407, "
          "prot/afln 8.946, prot/chat 9.775)")
    print("=" * 96)
    rec = {(0, 0.5, "seed_reuse", "aflnet"): 9.302,
           (0, 0.5, "seed_reuse", "chatafl"): 9.407,
           (0, 0.5, "protorag", "aflnet"): 8.946,
           (0, 0.5, "protorag", "chatafl"): 9.775,
           (18, 24, "seed_reuse", "aflnet"): 9.964,
           (18, 24, "seed_reuse", "chatafl"): 9.956,
           (18, 24, "protorag", "aflnet"): 10.513,
           (18, 24, "protorag", "chatafl"): 10.474}
    for src, pool in (("CSV(4dp)", pooled_csv), ("原始(未舍入)", pooled_raw)):
        errs = [abs(pool[k] - v) for k, v in rec.items()]
        print(f"  {src:<14} 与记录最大差 = {max(errs):.4f} pp  平均 = "
              f"{statistics.fmean(errs):.4f} pp")

    print()
    print("  记录 §6.1 声称 aflnet 0-0.5h 逐 rep: "
          "-0.291, -0.348, -0.407, -0.669, -0.042 (0/5)")
    for src, per in (("CSV(4dp)", per_csv), ("原始(未舍入)", per_raw)):
        pr = per
        diffs = [round(pr[("protorag", "aflnet", r)] - pr[("seed_reuse", "aflnet", r)], 3)
                 for r in REPS
                 if ("protorag", "aflnet", r) in pr and ("seed_reuse", "aflnet", r) in pr]
        print(f"  {src:<14} 实测 per_rep={diffs}  win="
              f"{sum(1 for x in diffs if x>0)}/5")

    print()
    print("=" * 96)
    print("★ 记录 §6.1 声称 18-24h 逐 rep: +0.332, +0.643, +0.518, +0.636, +0.653 (5/5)")
    print("=" * 96)
    for src, per in (("CSV(4dp)", per_csv), ("原始(未舍入)", per_raw)):
        pr = per
        diffs = [round(pr[("protorag", "aflnet", r)] - pr[("seed_reuse", "aflnet", r)], 3)
                 for r in REPS
                 if ("protorag", "aflnet", r) in pr and ("seed_reuse", "aflnet", r) in pr]
        print(f"  {src:<14} 实测 per_rep={diffs}  win="
              f"{sum(1 for x in diffs if x>0)}/5")

    print()
    print("=" * 96)
    print("口径敏感性: 同一批数据 4 种取点方式在 aflnet 0-0.5h 的结论")
    print("=" * 96)

    def point_variants(series):
        h = 0.5
        # (a) 区间池化
        a = interval_pooled(series, 0, 0.5)
        b = interval_pooled(series, 0, h + 0.2) if False else None
        # (b) 点桶 ±0.2h 池化 (采集脚本口径, 但 h=0.5 时窗口是 [0.3,0.7))
        vals = [c for v in series.values() for rel, c in v if abs(rel - h) < 0.2]
        c = statistics.mean(vals) if vals else None
        # (c) 桶内首个采样点
        firsts, lasts = [], []
        for k, v in series.items():
            sel = [(rel, cv) for rel, cv in v if 0 <= rel < 0.5]
            if sel:
                firsts.append(sel[0][1])
                lasts.append(sel[-1][1])
        return (a, c, statistics.mean(firsts) if firsts else None,
                statistics.mean(lasts) if lasts else None)

    for src, series in (("CSV(4dp)", csv_series), ("原始(未舍入)", raw_series)):
        a, c, f_, l_ = point_variants(series)
        # 对 seed/protorag 分别算差值需要分组, 这里重算
        def d_of(fn):
            sv, pv = [], []
            for (g, f, r), v in series.items():
                sel = [(rel, cv) for rel, cv in v if 0 <= rel < 0.5]
                if not sel:
                    continue
                val = fn(sel)
                (pv if g == "protorag" else sv).append(val)
            return statistics.mean(pv) - statistics.mean(sv)

        d_interval = (interval_pooled({k: v for k, v in series.items()
                                        if k[0] == "protorag"}, 0, 0.5)
                      - interval_pooled({k: v for k, v in series.items()
                                         if k[0] == "seed_reuse"}, 0, 0.5))
        d_first = d_of(lambda sel: sel[0][1])
        d_last = d_of(lambda sel: sel[-1][1])
        d_nearest = None
        for g, f, r, v in series.items():
            pass
        print(f"  [{src}] 区间[0,0.5)池化 Δ={d_interval:+.4f}   "
              f"桶内首个 Δ={d_first:+.4f}   桶内最后 Δ={d_last:+.4f}")


if __name__ == "__main__":
    main()
