#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA 终检:
   (1) 精确定位主理人 n_edges 序列 [+4,-2,-1,-1,+28] 的来源时刻窗口
   (2) 覆盖率反超 '5/5 逐rep +0.21~+0.66pp 均值+0.52' 核实
   (3) 反超是保持还是扩大 (时序)
   (4) 崩溃分布迁移
"""
from __future__ import annotations

import csv
import os
import statistics
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")
CSV_DIR = os.path.join(os.path.dirname(HERE), "data", "rq1_2")
TZ8 = timezone(timedelta(hours=8))
GROUPS = ("seed_reuse", "protorag")
FUZZERS = ("chatafl", "aflnet")
REPS = (1, 2, 3, 4, 5)


def parse_plot(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) <= 12:
                continue
            rows.append(p)
    return rows


def parse_stats(path):
    out = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if ":" in line:
                k, _, v = line.partition(":")
                out[k.strip()] = v.strip()
    return out


def pct(s):
    return float(s.strip().rstrip("%"))


D = {}
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            tag = f"{g}_{f}_r{r}"
            rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
            D[(g, f, r)] = {"rows": rows,
                           "fs": parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats")),
                           "t0": int(float(rows[0][0]))}

YEAR = datetime.fromtimestamp(D[("seed_reuse", "aflnet", 1)]["t0"], TZ8).year

print("=" * 96)
print("(1) 精确定位: 主理人 n_edges 序列 [+4,-2,-1,-1,+28] 的来源时刻")
print("=" * 96)
all_ts = sorted({int(float(p[0])) for d in D.values() for p in d["rows"]})


def state_at(ts):
    out = {}
    for k, d in D.items():
        sel = None
        for p in d["rows"]:
            if int(float(p[0])) <= ts:
                sel = p
            else:
                break
        if sel is None:
            sel = d["rows"][0]
        out[k] = {"cvg": pct(sel[6]), "crashes": int(float(sel[7])),
                  "n_edges": int(float(sel[12])), "n_states": int(float(sel[11]))}
    return out


CLAIM = [4, -2, -1, -1, 28]
for f in FUZZERS:
    hit = []
    for ts in all_ts:
        st = state_at(ts)
        d = [st[("protorag", f, r)]["n_edges"] - st[("seed_reuse", f, r)]["n_edges"]
             for r in REPS]
        if d == CLAIM:
            hit.append(ts)
    # 终态
    se = [int(float(D[("seed_reuse", f, r)]["rows"][-1][12])) for r in REPS]
    pe = [int(float(D[("protorag", f, r)]["rows"][-1][12])) for r in REPS]
    fin = [p - s for p, s in zip(pe, se)]
    print(f"\n  fuzzer = {f}")
    print(f"    主理人序列 {CLAIM}: "
          + (f"命中 {len(hit)} 个时刻, 窗口 "
             f"{datetime.fromtimestamp(hit[0], TZ8):%m-%d %H:%M} ~ "
             f"{datetime.fromtimestamp(hit[-1], TZ8):%m-%d %H:%M}"
             if hit else "★任何时刻均不命中"))
    if hit:
        st = state_at(hit[0])
        print(f"      该时刻 seed_reuse n_edges = "
              f"{[st[('seed_reuse', f, r)]['n_edges'] for r in REPS]}")
        print(f"      该时刻 protorag   n_edges = "
              f"{[st[('protorag', f, r)]['n_edges'] for r in REPS]}")
    print(f"    ★ 终态(24h) 实测序列 = {fin}  "
          f"正 {sum(1 for x in fin if x>0)}/5 负 {sum(1 for x in fin if x<0)}/5  "
          f"均值={statistics.fmean(fin):+.2f} sd={statistics.stdev(fin):.2f}")
    print(f"      -> 与主理人序列一致? {'是' if fin == CLAIM else '否 ★'}")

print()
print("=" * 96)
print("(2) 覆盖率反超逐 rep 核实 —— 主理人: 'aflnet 5/5 逐rep反超 +0.21~+0.66pp, 均值 +0.52'")
print("=" * 96)
for f in FUZZERS:
    se = [pct(D[("seed_reuse", f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
    pe = [pct(D[("protorag", f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
    d = [round(p - s, 6) for p, s in zip(pe, se)]
    print(f"  {f}: 终态 fuzzer_stats bitmap_cvg")
    print(f"    seed_reuse = {se}")
    print(f"    protorag   = {pe}")
    print(f"    差值 pp    = {['%+.2f' % x for x in d]}")
    print(f"    min={min(d):+.2f}  max={max(d):+.2f}  mean={statistics.fmean(d):+.4f}  "
          f"sd={statistics.stdev(d):.4f}  win={sum(1 for x in d if x>0)}/5")
    print(f"    主理人称 '5/5 逐rep反超, +0.21~+0.66pp, 均值约+0.52pp'")

print()
print("  --- 用 timeseries.csv 24h 桶 (同一口径) 复核 ---")
ts_csv = {}
with open(os.path.join(CSV_DIR, "rq1_2_timeseries.csv"), "r", encoding="utf-8-sig",
          newline="") as fh:
    for row in csv.DictReader(fh):
        ts_csv.setdefault((row["group"], row["fuzzer"], int(row["rep"])), []).append(
            (float(row["rel_hours"]), float(row["bitmap_cvg"])))
for k in ts_csv:
    ts_csv[k].sort()


def ts_at(g, f, r, h, tol=0.2):
    for rel, cvg in ts_csv[(g, f, r)]:
        if abs(rel - h) <= tol:
            return cvg
    return None


for f in FUZZERS:
    se = [ts_at("seed_reuse", f, r, 24.0) for r in REPS]
    pe = [ts_at("protorag", f, r, 24.0) for r in REPS]
    if all(v is not None for v in se + pe):
        d = [round(p - s, 6) for p, s in zip(pe, se)]
        print(f"  {f} @24h桶: seed={se} protorag={pe}")
        print(f"    差值 = {['%+.2f' % x for x in d]}  min={min(d):+.2f} max={max(d):+.2f} "
              f"mean={statistics.fmean(d):+.4f} win={sum(1 for x in d if x>0)}/5")

print()
print("=" * 96)
print("(3) 反超时序: 是保持还是扩大 (逐桶, protorag - seed_reuse 覆盖率 pp)")
print("=" * 96)
BUCKETS = [0.5, 1, 2, 4, 6, 8, 12, 18, 24]
print(f"{'bucket':<9}{'chatafl_mean':>14}{'chatafl_win':>13}{'aflnet_mean':>14}{'aflnet_win':>12}")
for b in BUCKETS:
    line = f"{str(b)+'h':<9}"
    for f in FUZZERS:
        pro, base = [], []
        for r in REPS:
            pv = ts_at("protorag", f, r, b)
            bv = ts_at("seed_reuse", f, r, b)
            if pv is not None and bv is not None:
                pro.append(pv)
                base.append(bv)
        if pro and base:
            d = [p - s for p, s in zip(pro, base)]
            line += (f"{statistics.fmean(d):>+14.4f}"
                     f"{str(sum(1 for x in d if x>0))+'/5':>13}")
        else:
            line += f"{'NA':>14}{'NA':>13}"
    print(line)

print()
print("  --- 保持/扩大判定 ---")
for f in FUZZERS:
    seq = []
    for b in BUCKETS:
        pro, base = [], []
        for r in REPS:
            pv = ts_at("protorag", f, r, b)
            bv = ts_at("seed_reuse", f, r, b)
            if pv is not None and bv is not None:
                pro.append(pv)
                base.append(bv)
        if pro and base:
            d = [p - s for p, s in zip(pro, base)]
            seq.append((b, statistics.fmean(d), sum(1 for x in d if x > 0)))
    always_pos = all(w == 5 for _, _, w in seq)
    first = seq[0][1]
    last = seq[-1][1]
    peak = max(seq, key=lambda x: x[1])
    print(f"  {f}: 全部桶 win=5/5? {always_pos}   "
          f"1h/0.5h={first:+.4f} -> 24h={last:+.4f} (净变化 {last-first:+.4f}pp)  "
          f"峰值 {peak[1]:+.4f}pp @ {peak[0]}h")

print()
print("=" * 96)
print("(4) 崩溃分布: 中间态 -> 终态 迁移")
print("=" * 96)
CUT = datetime(YEAR, 10, 24, 20, 0, 0, tzinfo=TZ8).timestamp()
st_cut = state_at(CUT)
print(f"  中间态边界 10-24 20:00 (UTC+8 {YEAR})")
print(f"  {'container':<28}{'mid_crash':>11}{'final_crash':>13}{'delta':>8}")
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            m = st_cut[(g, f, r)]["crashes"]
            fi = int(D[(g, f, r)]["fs"]["unique_crashes"])
            print(f"  {g+'/'+f+'/r'+str(r):<28}{m:>11}{fi:>13}{fi-m:>+8}")
mid_tot = sum(st_cut[k]["crashes"] for k in st_cut)
fin_tot = sum(int(D[k]["fs"]["unique_crashes"]) for k in D)
print(f"  {'合计':<28}{mid_tot:>11}{fin_tot:>13}{fin_tot-mid_tot:>+8}")

print()
print("  --- 主理人称中间态 '崩溃 8 个全在 seed_reuse_aflnet (r1=7, r3=1)' ---")
# 该崩溃组合的最早成立时刻
for ts in all_ts:
    st = state_at(ts)
    crash = {k: v["crashes"] for k, v in st.items() if v["crashes"] > 0}
    if crash == {("seed_reuse", "aflnet", 1): 7, ("seed_reuse", "aflnet", 3): 1}:
        print(f"    崩溃组合 'r1=7, r3=1 全在 seed_reuse_aflnet' 最早成立于 "
              f"{datetime.fromtimestamp(ts, TZ8):%Y-%m-%d %H:%M} (UTC+8)")
        # 该时刻的 4 组覆盖均值
        for g in GROUPS:
            for f in FUZZERS:
                m = statistics.fmean([st[(g, f, r)]["cvg"] for r in REPS])
                print(f"      {g:<11}{f:<8} 该时刻覆盖均值 = {m:.4f}%")
        break
else:
    print("    ★ 该崩溃组合在任何时刻都不成立")

print()
print("  --- 崩溃组合 r1=7,r3=1 的持续窗口 & 覆盖均值是否同时吻合 ---")
first_ts = None
last_ts = None
for ts in all_ts:
    st = state_at(ts)
    crash = {k: v["crashes"] for k, v in st.items() if v["crashes"] > 0}
    if crash == {("seed_reuse", "aflnet", 1): 7, ("seed_reuse", "aflnet", 3): 1}:
        if first_ts is None:
            first_ts = ts
        last_ts = ts
if first_ts:
    print(f"    窗口: {datetime.fromtimestamp(first_ts, TZ8):%m-%d %H:%M} ~ "
          f"{datetime.fromtimestamp(last_ts, TZ8):%m-%d %H:%M}  "
          f"持续 {(last_ts-first_ts)/3600:.2f}h")
    st = state_at(first_ts)
    for g in GROUPS:
        for f in FUZZERS:
            m = statistics.fmean([st[(g, f, r)]["cvg"] for r in REPS])
            ref = {("seed_reuse", "chatafl"): 9.91, ("seed_reuse", "aflnet"): 9.82,
                   ("protorag", "chatafl"): 10.36, ("protorag", "aflnet"): 10.38}[(g, f)]
            print(f"      {g:<11}{f:<8} 崩溃窗口内覆盖均值={m:.4f}%  主理人中间态={ref:.2f}%  "
                  f"Δ={m-ref:+.4f}pp")

print()
print("=" * 96)
print("(5) '以更少路径拿更高覆盖' —— aflnet 侧数字")
print("=" * 96)
for f in FUZZERS:
    sp = [int(D[("seed_reuse", f, r)]["fs"]["paths_total"]) for r in REPS]
    pp = [int(D[("protorag", f, r)]["fs"]["paths_total"]) for r in REPS]
    se = [int(D[("seed_reuse", f, r)]["fs"]["execs_done"]) for r in REPS]
    pe = [int(D[("protorag", f, r)]["fs"]["execs_done"]) for r in REPS]
    sc = [pct(D[("seed_reuse", f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
    pc = [pct(D[("protorag", f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
    print(f"  --- {f} ---")
    print(f"    paths  seed_reuse={sp} 均值={statistics.fmean(sp):.1f}")
    print(f"           protorag  ={pp} 均值={statistics.fmean(pp):.1f}  "
          f"Δ均值={statistics.fmean(pp)-statistics.fmean(sp):+.1f}  "
          f"protorag 更少 {sum(1 for a,b in zip(pp,sp) if a<b)}/5")
    print(f"    execs  seed_reuse 均值={statistics.fmean(se):.0f}  "
          f"protorag 均值={statistics.fmean(pe):.0f}  "
          f"Δ均值={statistics.fmean(pe)-statistics.fmean(se):+.0f}  "
          f"protorag 更少 {sum(1 for a,b in zip(pe,se) if a<b)}/5")
    print(f"    cvg    seed_reuse 均值={statistics.fmean(sc):.3f}%  "
          f"protorag 均值={statistics.fmean(pc):.3f}%  "
          f"Δ={statistics.fmean(pc)-statistics.fmean(sc):+.4f}pp  "
          f"protorag 更高 {sum(1 for a,b in zip(pc,sc) if a>b)}/5")
    print(f"    => '更少路径拿更高覆盖' 成立? "
          f"{statistics.fmean(pp) < statistics.fmean(sp) and statistics.fmean(pc) > statistics.fmean(sc)}")
