#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA 独立重算脚本 (RQ1.2 / Live555).

直接从 VM 原始数据 (plot_data + fuzzer_stats) 独立重算，
与本地 CSV / docx 回填结果比对。不引用上游任何结论。

数据源: ../qa_rq1_2/raw/{group}_{fuzzer}_r{rep}.{plot_data,fuzzer_stats}
输出:   qa_rq1_2_recomputed.json  + 控制台报告
"""
from __future__ import annotations

import csv
import json
import os
import statistics
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")
CSV_DIR = os.path.join(os.path.dirname(HERE), "data", "rq1_2")

GROUPS = ("seed_reuse", "protorag")
FUZZERS = ("chatafl", "aflnet")
REPS = (1, 2, 3, 4, 5)

# plot_data 0-based 列定义 (依据 chatafl/AFL plot_data 格式)
COL_UNIX_TIME = 0
COL_PATHS_TOTAL = 3
COL_BITMAP_CVG = 6
COL_UNIQUE_CRASHES = 7
COL_UNIQUE_HANGS = 8
COL_N_STATES = 11
COL_N_EDGES = 12

# docx 表4 行序 (summary.csv docx_row 2..5)
DOCX_ROW_ORDER = [
    ("seed_reuse", "chatafl"),
    ("seed_reuse", "aflnet"),
    ("protorag", "chatafl"),
    ("protorag", "aflnet"),
]


# --------------------------------------------------------------------------
# 原始数据解析
# --------------------------------------------------------------------------
def parse_plot_data(path):
    """解析 plot_data -> list[dict]。跳过 '#' 注释行。"""
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) <= COL_N_EDGES:
                continue
            rows.append(parts)
    return rows


def parse_fuzzer_stats(path):
    """解析 fuzzer_stats 'key : value' 格式。"""
    out = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if ":" not in line:
                continue
            k, _, v = line.partition(":")
            out[k.strip()] = v.strip()
    return out


def pct_to_float(s):
    s = (s or "").strip().rstrip("%")
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def recompute_container(group, fuzzer, rep):
    """单容器独立重算。"""
    tag = f"{group}_{fuzzer}_r{rep}"
    pd_path = os.path.join(RAW, f"{tag}.plot_data")
    fs_path = os.path.join(RAW, f"{tag}.fuzzer_stats")
    rows = parse_plot_data(pd_path)
    fs = parse_fuzzer_stats(fs_path)

    if not rows:
        raise RuntimeError(f"{tag}: empty plot_data")

    first = rows[0]
    last = rows[-1]

    t0 = int(float(first[COL_UNIX_TIME]))

    # --- P1: plot_data 首行 n_states / n_edges ---
    p1_states = int(float(first[COL_N_STATES]))
    p1_edges = int(float(first[COL_N_EDGES]))

    # --- P2: plot_data 末行 + fuzzer_stats ---
    p2_states = int(float(last[COL_N_STATES]))
    p2_edges = int(float(last[COL_N_EDGES]))
    bitmap_cvg_plot = pct_to_float(last[COL_BITMAP_CVG])
    bitmap_cvg_stats = pct_to_float(fs.get("bitmap_cvg", ""))

    unique_crashes = int(float(fs.get("unique_crashes", "0")))
    unique_hangs = int(float(fs.get("unique_hangs", "0")))
    paths_total = int(float(fs.get("paths_total", "0")))
    execs_done = int(float(fs.get("execs_done", "0")))

    # 交叉校验: plot_data 末行的 crashes/hangs/paths 应与 fuzzer_stats 一致
    xcheck = {
        "plot_last_paths_total": int(float(last[COL_PATHS_TOTAL])),
        "plot_last_crashes": int(float(last[COL_UNIQUE_CRASHES])),
        "plot_last_hangs": int(float(last[COL_UNIQUE_HANGS])),
        "stats_paths_total": paths_total,
        "stats_crashes": unique_crashes,
        "stats_hangs": unique_hangs,
        "bitmap_plot": bitmap_cvg_plot,
        "bitmap_stats": bitmap_cvg_stats,
        "plot_last_time": int(float(last[COL_UNIX_TIME])),
        "stats_last_update": int(float(fs.get("last_update", "0"))),
        "stats_start_time": int(float(fs.get("start_time", "0"))),
        "n_plot_rows": len(rows),
    }
    xcheck["paths_match"] = xcheck["plot_last_paths_total"] == paths_total
    xcheck["crashes_match"] = xcheck["plot_last_crashes"] == unique_crashes
    xcheck["hangs_match"] = xcheck["plot_last_hangs"] == unique_hangs
    xcheck["bitmap_match"] = (
        bitmap_cvg_plot is not None
        and bitmap_cvg_stats is not None
        and abs(bitmap_cvg_plot - bitmap_cvg_stats) < 1e-9
    )

    # --- 首次崩溃相对时刻 (小时) ---
    first_crash_rel_h = None
    for r in rows:
        if int(float(r[COL_UNIQUE_CRASHES])) > 0:
            first_crash_rel_h = (int(float(r[COL_UNIX_TIME])) - t0) / 3600.0
            break

    # --- 崩溃首次出现序列 (逐次) ---
    crash_events = []
    prev = 0
    for r in rows:
        c = int(float(r[COL_UNIQUE_CRASHES]))
        if c > prev:
            crash_events.append(
                {
                    "rel_h": round((int(float(r[COL_UNIX_TIME])) - t0) / 3600.0, 4),
                    "cum_crashes": c,
                    "delta": c - prev,
                }
            )
            prev = c

    # --- 时序 (rel_hours, bitmap_cvg, paths_total) ---
    series = []
    for r in rows:
        series.append(
            {
                "rel_h": (int(float(r[COL_UNIX_TIME])) - t0) / 3600.0,
                "cvg": pct_to_float(r[COL_BITMAP_CVG]),
                "paths": int(float(r[COL_PATHS_TOTAL])),
                "crashes": int(float(r[COL_UNIQUE_CRASHES])),
                "hangs": int(float(r[COL_UNIQUE_HANGS])),
            }
        )

    return {
        "container": f"rq2_{tag}",
        "group": group,
        "fuzzer": fuzzer,
        "rep": rep,
        "p1_states": p1_states,
        "p1_edges": p1_edges,
        "p2_states": p2_states,
        "p2_edges": p2_edges,
        "bitmap_cvg": bitmap_cvg_stats if bitmap_cvg_stats is not None else bitmap_cvg_plot,
        "bitmap_cvg_plot": bitmap_cvg_plot,
        "bitmap_cvg_stats": bitmap_cvg_stats,
        "unique_crashes": unique_crashes,
        "unique_hangs": unique_hangs,
        "paths_total": paths_total,
        "execs_done": execs_done,
        "first_crash_rel_h": first_crash_rel_h,
        "crash_events": crash_events,
        "xcheck": xcheck,
        "series": series,
    }


# --------------------------------------------------------------------------
# 聚合
# --------------------------------------------------------------------------
def agg_mean(vals):
    return sum(vals) / len(vals)


def build_summary(containers):
    """按 (group,fuzzer) 求 5 rep 均值 -> docx 表4 口径。"""
    out = OrderedDict()
    for group, fuzzer in DOCX_ROW_ORDER:
        rows = [
            c for c in containers if c["group"] == group and c["fuzzer"] == fuzzer
        ]
        assert len(rows) == 5, (group, fuzzer, len(rows))
        out[(group, fuzzer)] = {
            "n_states_P1": agg_mean([r["p1_states"] for r in rows]),
            "n_states_P2": agg_mean([r["p2_states"] for r in rows]),
            "n_edges_P1": agg_mean([r["p1_edges"] for r in rows]),
            "n_edges_P2": agg_mean([r["p2_edges"] for r in rows]),
            "bitmap_cvg_P2": agg_mean([r["bitmap_cvg"] for r in rows]),
            "unique_crashes_P2": agg_mean([r["unique_crashes"] for r in rows]),
            "paths_total_P2": agg_mean([r["paths_total"] for r in rows]),
            "execs_done_P2": agg_mean([r["execs_done"] for r in rows]),
            "unique_hangs_P2": agg_mean([r["unique_hangs"] for r in rows]),
            "_per_rep": {
                "n_states_P1": [r["p1_states"] for r in rows],
                "n_states_P2": [r["p2_states"] for r in rows],
                "n_edges_P1": [r["p1_edges"] for r in rows],
                "n_edges_P2": [r["p2_edges"] for r in rows],
                "bitmap_cvg_P2": [r["bitmap_cvg"] for r in rows],
                "unique_crashes_P2": [r["unique_crashes"] for r in rows],
                "paths_total_P2": [r["paths_total"] for r in rows],
                "execs_done_P2": [r["execs_done"] for r in rows],
            },
        }
    return out


def paired_stats(diff):
    """配对差值统计。diff: list of floats (protorag - seed_reuse), 5 个。"""
    n = len(diff)
    mean = statistics.fmean(diff)
    sd = statistics.stdev(diff) if n > 1 else 0.0
    wins = sum(1 for d in diff if d > 0)
    losses = sum(1 for d in diff if d < 0)
    ties = sum(1 for d in diff if d == 0)
    return {
        "diffs": diff,
        "mean": mean,
        "sd": sd,
        "sem": sd / (n ** 0.5) if n else 0.0,
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "win_rate": wins / n if n else 0.0,
        "min": min(diff),
        "max": max(diff),
    }


# --------------------------------------------------------------------------
# 载入本地 CSV (用于比对)
# --------------------------------------------------------------------------
def load_csv_rows(name):
    path = os.path.join(CSV_DIR, name)
    with open(path, "r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def num(s):
    s = (s or "").strip()
    if s.endswith("%"):
        s = s[:-1]
    try:
        return float(s)
    except ValueError:
        return None


# --------------------------------------------------------------------------
def main():
    containers = []
    for group in GROUPS:
        for fuzzer in FUZZERS:
            for rep in REPS:
                containers.append(recompute_container(group, fuzzer, rep))

    summary = build_summary(containers)

    report = OrderedDict()
    report["containers"] = [
        {k: v for k, v in c.items() if k != "series"} for c in containers
    ]
    report["summary"] = {
        f"{g}|{f}": v for (g, f), v in summary.items()
    }

    # ---------------- CSV 逐格比对 ----------------
    csv_cmp = OrderedDict()

    # P1
    p1_csv = {(r["group"], int(r["rep"]), r["fuzzer"]): r for r in load_csv_rows("rq1_2_p1.csv")}
    p1_diffs = []
    for c in containers:
        key = (c["group"], c["rep"], c["fuzzer"])
        row = p1_csv.get(key)
        if row is None:
            p1_diffs.append((key, "MISSING_ROW", None, None))
            continue
        exp_s, exp_e = num(row["n_states"]), num(row["n_edges"])
        if exp_s != c["p1_states"] or exp_e != c["p1_edges"]:
            p1_diffs.append(
                (key, "MISMATCH", (exp_s, exp_e), (c["p1_states"], c["p1_edges"]))
            )
    csv_cmp["p1"] = {
        "rows_csv": len(p1_csv),
        "rows_recomputed": len(containers),
        "mismatches": p1_diffs,
        "ok": not p1_diffs and len(p1_csv) == 20,
    }

    # P2
    p2_csv = {(r["group"], int(r["rep"]), r["fuzzer"]): r for r in load_csv_rows("rq1_2_p2.csv")}
    p2_diffs = []
    for c in containers:
        key = (c["group"], c["rep"], c["fuzzer"])
        row = p2_csv.get(key)
        if row is None:
            p2_diffs.append((key, "MISSING_ROW", None, None))
            continue
        pairs = [
            ("n_states", num(row["n_states"]), c["p2_states"]),
            ("n_edges", num(row["n_edges"]), c["p2_edges"]),
            ("bitmap_cvg", num(row["bitmap_cvg"]), c["bitmap_cvg"]),
            ("unique_crashes", num(row["unique_crashes"]), c["unique_crashes"]),
            ("unique_hangs", num(row["unique_hangs"]), c["unique_hangs"]),
            ("paths_total", num(row["paths_total"]), c["paths_total"]),
            ("execs_done", num(row["execs_done"]), c["execs_done"]),
        ]
        bad = [(f, e, a) for f, e, a in pairs if abs((e or 0) - (a or 0)) > 1e-9]
        if bad:
            p2_diffs.append((key, "MISMATCH", bad, None))
    csv_cmp["p2"] = {
        "rows_csv": len(p2_csv),
        "rows_recomputed": len(containers),
        "mismatches": p2_diffs,
        "ok": not p2_diffs and len(p2_csv) == 20,
    }

    # summary
    sum_csv = load_csv_rows("rq1_2_summary.csv")
    sum_diffs = []
    for row in sum_csv:
        drow = int(row["docx_row"])
        group, fuzzer = DOCX_ROW_ORDER[drow - 2]
        mine = summary[(group, fuzzer)]
        pairs = [
            ("n_states_P1", num(row["n_states_P1"]), mine["n_states_P1"]),
            ("n_states_P2", num(row["n_states_P2"]), mine["n_states_P2"]),
            ("n_edges_P1", num(row["n_edges_P1"]), mine["n_edges_P1"]),
            ("n_edges_P2", num(row["n_edges_P2"]), mine["n_edges_P2"]),
            ("bitmap_cvg_P2", num(row["bitmap_cvg_P2"]), mine["bitmap_cvg_P2"]),
            ("unique_crashes_P2", num(row["unique_crashes_P2"]), mine["unique_crashes_P2"]),
            ("paths_total_P2", num(row["paths_total_P2"]), mine["paths_total_P2"]),
        ]
        bad = []
        for f, e, a in pairs:
            if e is None:
                bad.append((f, "NON_NUMERIC", a))
            elif abs(e - a) > 5e-4:  # 汇总 CSV 保留 2 位小数
                bad.append((f, e, round(a, 6)))
        if bad:
            sum_diffs.append((drow, group, fuzzer, bad))
    csv_cmp["summary"] = {
        "rows_csv": len(sum_csv),
        "mismatches": sum_diffs,
        "ok": not sum_diffs and len(sum_csv) == 4,
    }
    report["csv_comparison"] = csv_cmp

    # ---------------- 反超 / 配对差值 ----------------
    pairs_report = OrderedDict()

    # 覆盖率反超 (protorag - seed_reuse), 按 fuzzer 分开
    for fuzzer in FUZZERS:
        base = summary[("seed_reuse", fuzzer)]["_per_rep"]
        pro = summary[("protorag", fuzzer)]["_per_rep"]
        cov_diff = [
            round(p - b, 6)
            for p, b in zip(pro["bitmap_cvg_P2"], base["bitmap_cvg_P2"])
        ]
        pairs_report[f"coverage_{fuzzer}"] = paired_stats(cov_diff)

    # n_edges 逐 rep 差值 (protorag - seed_reuse), 按 fuzzer 分开
    for fuzzer in FUZZERS:
        base = summary[("seed_reuse", fuzzer)]["_per_rep"]
        pro = summary[("protorag", fuzzer)]["_per_rep"]
        e2_diff = [p - b for p, b in zip(pro["n_edges_P2"], base["n_edges_P2"])]
        pairs_report[f"nedges_P2_{fuzzer}"] = paired_stats(e2_diff)
        e1_diff = [p - b for p, b in zip(pro["n_edges_P1"], base["n_edges_P1"])]
        pairs_report[f"nedges_P1_{fuzzer}"] = paired_stats(e1_diff)

    # 其它指标的配对差值 (protorag - seed_reuse)
    for fuzzer in FUZZERS:
        base = summary[("seed_reuse", fuzzer)]["_per_rep"]
        pro = summary[("protorag", fuzzer)]["_per_rep"]
        for metric in ("n_states_P1", "n_states_P2", "paths_total_P2", "execs_done_P2"):
            d = [p - b for p, b in zip(pro[metric], base[metric])]
            pairs_report[f"{metric}_{fuzzer}"] = paired_stats([float(x) for x in d])

    report["paired"] = pairs_report

    # ---------------- 时序分桶 ----------------
    BUCKETS = [0.5, 1, 2, 4, 6, 8, 12, 18, 24]
    TOL = 0.2

    def bucket_value(series, key):
        """在 series 中找 rel_h 落在 bucket±tol 的点, 取时间最接近 bucket 的值。"""
        best = None
        best_d = None
        for s in series:
            d = abs(s["rel_h"] - bucket_value.bucket)
            if d <= TOL and (best_d is None or d < best_d):
                best_d = d
                best = s
        if best is None:
            return None
        return best[key]

    bucket_value.bucket = None

    ts = OrderedDict()
    for group in GROUPS:
        for fuzzer in FUZZERS:
            for b in BUCKETS:
                bucket_value.bucket = b
                vals = []
                for rep in REPS:
                    c = next(
                        x for x in containers
                        if x["group"] == group and x["fuzzer"] == fuzzer and x["rep"] == rep
                    )
                    v = bucket_value(c["series"], "cvg")
                    if v is not None:
                        vals.append(v)
                ts[f"{group}|{fuzzer}|{b}h"] = {
                    "n": len(vals),
                    "mean": round(statistics.fmean(vals), 4) if vals else None,
                    "vals": vals,
                }

    # 反超差值时序 (protorag - seed_reuse), 同 fuzzer
    ts_delta = OrderedDict()
    for fuzzer in FUZZERS:
        for b in BUCKETS:
            bucket_value.bucket = b
            pro_v, base_v = [], []
            for rep in REPS:
                for grp, acc in (("protorag", pro_v), ("seed_reuse", base_v)):
                    c = next(
                        x for x in containers
                        if x["group"] == grp and x["fuzzer"] == fuzzer and x["rep"] == rep
                    )
                    v = bucket_value(c["series"], "cvg")
                    if v is not None:
                        acc.append(v)
            if pro_v and base_v:
                d = [p - s for p, s in zip(pro_v, base_v)]
                ts_delta[f"{fuzzer}|{b}h"] = {
                    "n": len(d),
                    "mean": round(statistics.fmean(d), 4),
                    "per_rep": [round(x, 4) for x in d],
                    "win": sum(1 for x in d if x > 0),
                }
            else:
                ts_delta[f"{fuzzer}|{b}h"] = {"n": 0, "mean": None, "per_rep": [], "win": 0}

    report["timeseries_buckets"] = ts
    report["timeseries_delta"] = ts_delta

    # 崩溃/挂起分布
    report["crash_hang_dist"] = [
        {
            "container": c["container"],
            "group": c["group"],
            "fuzzer": c["fuzzer"],
            "rep": c["rep"],
            "first_crash_rel_h": c["first_crash_rel_h"],
            "unique_crashes": c["unique_crashes"],
            "unique_hangs": c["unique_hangs"],
            "paths_total": c["paths_total"],
            "execs_done": c["execs_done"],
            "crash_events": c["crash_events"],
        }
        for c in containers
    ]

    # ---------------- 输出 ----------------
    out_path = os.path.join(HERE, "qa_rq1_2_recomputed.json")
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=1, default=str)

    # ---------------- 控制台报告 ----------------
    print("=" * 78)
    print("QA 独立重算报告 (来源: VM /home/zxy/rq2_out 原始 plot_data + fuzzer_stats)")
    print("=" * 78)

    print("\n### A. 逐容器重算结果")
    hdr = (
        f"{'container':<30}{'n_s(P1)':>8}{'n_e(P1)':>8}{'n_s(P2)':>8}{'n_e(P2)':>8}"
        f"{'cvg%':>8}{'crash':>7}{'hang':>6}{'paths':>8}{'execs':>10}{'1stCrash_h':>12}"
    )
    print(hdr)
    for c in containers:
        fc = c["first_crash_rel_h"]
        fcs = f"{fc:.4f}" if fc is not None else "-"
        print(
            f"{c['container']:<30}{c['p1_states']:>8}{c['p1_edges']:>8}"
            f"{c['p2_states']:>8}{c['p2_edges']:>8}{c['bitmap_cvg']:>8.2f}"
            f"{c['unique_crashes']:>7}{c['unique_hangs']:>6}{c['paths_total']:>8}"
            f"{c['execs_done']:>10}{fcs:>12}"
        )

    print("\n### B. 内部一致性交叉校验 (plot_data 末行 vs fuzzer_stats)")
    xbad = [c["container"] for c in containers if not (
        c["xcheck"]["paths_match"] and c["xcheck"]["crashes_match"]
        and c["xcheck"]["hangs_match"] and c["xcheck"]["bitmap_match"]
    )]
    print(f"20 个容器全部一致: {not xbad}" + (f"  异常: {xbad}" if xbad else ""))

    print("\n### C. 独立重算 vs 本地 CSV 逐格比对")
    for k in ("p1", "p2", "summary"):
        c = csv_cmp[k]
        print(f"  {k:<8} rows_csv={c['rows_csv']:<3} rows_recomputed=20  "
              f"mismatches={len(c['mismatches'])}  -> {'一致 OK' if c['ok'] else '不一致 FAIL'}")
        for m in c["mismatches"]:
            print(f"      MISMATCH: {m}")

    print("\n### D. 聚合表 (5 rep 均值, 我方独立重算)")
    print(f"{'row':<26}{'n_sP1':>8}{'n_sP2':>8}{'n_eP1':>8}{'n_eP2':>8}"
          f"{'cvg%':>9}{'crash':>8}{'paths':>8}{'execs':>10}")
    for i, (g, f) in enumerate(DOCX_ROW_ORDER):
        m = summary[(g, f)]
        print(f"{g+'/'+f:<26}{m['n_states_P1']:>8.1f}{m['n_states_P2']:>8.1f}"
              f"{m['n_edges_P1']:>8.1f}{m['n_edges_P2']:>8.1f}"
              f"{m['bitmap_cvg_P2']:>9.2f}{m['unique_crashes_P2']:>8.2f}"
              f"{m['paths_total_P2']:>8.1f}{m['execs_done_P2']:>10.0f}")

    print("\n### E. 配对差值 (protorag - seed_reuse, 同 fuzzer 同 rep)")
    for name, st in pairs_report.items():
        dstr = ", ".join(f"{d:+.4f}" for d in st["diffs"])
        print(f"  {name:<26} diffs=[{dstr}]  mean={st['mean']:+.4f} sd={st['sd']:.4f} "
              f"win={st['wins']}/5 loss={st['losses']}/5 tie={st['ties']}/5 "
              f"win_rate={st['win_rate']*100:.0f}%")

    print("\n### F. 时序覆盖率分桶 (5 rep 均值, ±0.2h)")
    print(f"{'bucket':<8}" + "".join(f"{g[:4]+'/'+f[:4]:>16}" for g in GROUPS for f in FUZZERS))
    for b in BUCKETS:
        line = f"{str(b)+'h':<8}"
        for g in GROUPS:
            for f in FUZZERS:
                v = ts[f"{g}|{f}|{b}h"]["mean"]
                line += f"{(f'{v:.3f}' if v is not None else 'NA'):>16}"
        print(line)

    print("\n### G. 反超差值时序 (protorag - seed_reuse 覆盖率, pp)")
    print(f"{'bucket':<8}{'chatafl_mean':>16}{'chatafl_win':>14}{'aflnet_mean':>16}{'aflnet_win':>14}")
    for b in BUCKETS:
        c = ts_delta[f"chatafl|{b}h"]
        a = ts_delta[f"aflnet|{b}h"]
        print(f"{str(b)+'h':<8}{c['mean']:>16.4f}{str(c['win'])+'/5':>14}"
              f"{a['mean']:>16.4f}{str(a['win'])+'/5':>14}")

    print(f"\n写入: {out_path}")


if __name__ == "__main__":
    main()
