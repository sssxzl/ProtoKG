#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA 深度分析: 汇总表舍入复核 / 20h 中间态反推 / 崩溃绝对时间线 /
   aflnet-vs-chatafl 逐 rep 对比 / 路径-覆盖权衡。"""
from __future__ import annotations

import json
import os
import statistics
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")

GROUPS = ("seed_reuse", "protorag")
FUZZERS = ("chatafl", "aflnet")
REPS = (1, 2, 3, 4, 5)
TZ8 = timezone(timedelta(hours=8))


def parse_plot(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) <= 12:
                continue
            rows.append(p)
    return rows


def parse_stats(path):
    out = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if ":" in line:
                k, _, v = line.partition(":")
                out[k.strip()] = v.strip()
    return out


def pct(s):
    return float(s.strip().rstrip("%"))


def load_all():
    data = {}
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                tag = f"{g}_{f}_r{r}"
                rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
                fs = parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats"))
                t0 = int(float(rows[0][0]))
                data[(g, f, r)] = {
                    "rows": rows,
                    "fs": fs,
                    "t0": t0,
                    "tlast": int(float(rows[-1][0])),
                }
    return data


def at_rel(rows, t0, target_h, tol=0.2):
    """取 rel_h 距 target_h 最近且在 tol 内的行。"""
    best, bd = None, None
    for p in rows:
        rel = (int(float(p[0])) - t0) / 3600.0
        d = abs(rel - target_h)
        if d <= tol and (bd is None or d < bd):
            bd, best = d, p
    return best


def edges_at(d, target_h):
    p = at_rel(d["rows"], d["t0"], target_h)
    return None if p is None else int(float(p[12]))


def cvg_at(d, target_h):
    p = at_rel(d["rows"], d["t0"], target_h)
    return None if p is None else pct(p[6])


def main():
    D = load_all()

    print("=" * 90)
    print("1. 汇总表舍入口径复核 (summary.csv 是 5 rep 均值, 保留 0/2 位小数)")
    print("=" * 90)
    agg = {}
    for g in GROUPS:
        for f in FUZZERS:
            rs = [D[(g, f, r)] for r in REPS]
            agg[(g, f)] = {
                "n_sP1": statistics.fmean([int(float(x["rows"][0][11])) for x in rs]),
                "n_sP2": statistics.fmean([int(float(x["rows"][-1][11])) for x in rs]),
                "n_eP1": statistics.fmean([int(float(x["rows"][0][12])) for x in rs]),
                "n_eP2": statistics.fmean([int(float(x["rows"][-1][12])) for x in rs]),
                "cvg": statistics.fmean([pct(x["fs"]["bitmap_cvg"]) for x in rs]),
                "crash": statistics.fmean([int(x["fs"]["unique_crashes"]) for x in rs]),
                "paths": statistics.fmean([int(x["fs"]["paths_total"]) for x in rs]),
                "execs": statistics.fmean([int(x["fs"]["execs_done"]) for x in rs]),
            }
    csv_expect = {
        ("seed_reuse", "chatafl"): dict(n_sP1=11.4, n_sP2=14.0, n_eP1=42.4, n_eP2=128.8,
                                        cvg=9.98, crash=5.40, paths=1436),
        ("seed_reuse", "aflnet"): dict(n_sP1=6.6, n_sP2=12.6, n_eP1=8.8, n_eP2=104.2,
                                       cvg=9.99, crash=9.40, paths=1610),
        ("protorag", "chatafl"): dict(n_sP1=13.0, n_sP2=14.0, n_eP1=76.4, n_eP2=137.8,
                                      cvg=10.48, crash=0.20, paths=2501),
        ("protorag", "aflnet"): dict(n_sP1=8.4, n_sP2=13.6, n_eP1=22.4, n_eP2=117.2,
                                     cvg=10.52, crash=0.00, paths=1495),
    }
    allok = True
    for k, exp in csv_expect.items():
        mine = agg[k]
        for field, label in (("n_sP1", "n_states_P1"), ("n_sP2", "n_states_P2"),
                             ("n_eP1", "n_edges_P1"), ("n_eP2", "n_edges_P2"),
                             ("cvg", "bitmap_cvg_P2"), ("crash", "unique_crashes_P2"),
                             ("paths", "paths_total_P2")):
            e = exp[field]
            a = mine[field]
            # CSV 用 1 位小数 (统计量) / 0 位 (计数) / 2 位 (百分比)
            dp = 2 if field == "cvg" else (0 if field in ("crash", "paths") else 1)
            rounded = round(a + 1e-12, dp)
            ok = abs(rounded - e) < 1e-9
            allok &= ok
            if not ok:
                print(f"  MISMATCH {k} {label}: csv={e} recomputed={a:.6f} -> round({dp})={rounded}")
    print(f"  summary.csv 4 行 x 7 列 = 28 格，按各自舍入口径全部一致: {allok}")

    print()
    print("=" * 90)
    print("2. 终态 n_edges(P2) 逐 rep 差值 —— 核实主理人 'aflnet +4/-2/-1/-1/+28, 2/5 为正'")
    print("=" * 90)
    for f in FUZZERS:
        se = [int(float(D[("seed_reuse", f, r)]["rows"][-1][12])) for r in REPS]
        pe = [int(float(D[("protorag", f, r)]["rows"][-1][12])) for r in REPS]
        diff = [p - s for p, s in zip(pe, se)]
        print(f"  {f}: seed_reuse={se}  protorag={pe}")
        print(f"        逐 rep 差值 = {['%+d' % x for x in diff]}  "
              f"正 {sum(1 for x in diff if x>0)}/5, 负 {sum(1 for x in diff if x<0)}/5, "
              f"均值={statistics.fmean(diff):+.2f} sd={statistics.stdev(diff):.2f}")

    print()
    print("  --- 反推: 20h 时刻的 n_edges, 检验主理人数字是否来自中间态 ---")
    for f in FUZZERS:
        se = [edges_at(D[("seed_reuse", f, r)], 20.0) for r in REPS]
        pe = [edges_at(D[("protorag", f, r)], 20.0) for r in REPS]
        if all(v is not None for v in se + pe):
            diff = [p - s for p, s in zip(pe, se)]
            print(f"  {f} @20h: seed_reuse={se}  protorag={pe}")
            print(f"        差值 = {['%+d' % x for x in diff]}  "
                  f"正 {sum(1 for x in diff if x>0)}/5 负 {sum(1 for x in diff if x<0)}/5")

    print()
    print("  --- 主理人给出的序列 (+4/-2/-1/-1/+28, 2/5 正) 与实测终态序列对比 ---")
    main_claim = [+4, -2, -1, -1, +28]
    for f in FUZZERS:
        se = [int(float(D[("seed_reuse", f, r)]["rows"][-1][12])) for r in REPS]
        pe = [int(float(D[("protorag", f, r)]["rows"][-1][12])) for r in REPS]
        diff = [p - s for p, s in zip(pe, se)]
        print(f"  {f}: 终态实测={diff}   主理人={main_claim}   "
              f"{'一致' if diff == main_claim else '★不一致★'}")

    print()
    print("=" * 90)
    print("3. 覆盖率反超逐 rep 核实 (终态, protorag - seed_reuse)")
    print("=" * 90)
    for f in FUZZERS:
        se = [pct(D[("seed_reuse", f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
        pe = [pct(D[("protorag", f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
        diff = [round(p - s, 6) for p, s in zip(pe, se)]
        print(f"  {f}: seed_reuse={se}  protorag={pe}")
        print(f"        差值 pp = {['%+.2f' % x for x in diff]}  "
              f"min={min(diff):+.2f} max={max(diff):+.2f} "
              f"均值={statistics.fmean(diff):+.4f} sd={statistics.stdev(diff):.4f} "
              f"win={sum(1 for x in diff if x>0)}/5")

    print()
    print("=" * 90)
    print("4. 崩溃绝对时间线 (定位 10-24 20:00 中间态边界)")
    print("=" * 90)
    print("  各容器启动时间 (fuzzer_stats.start_time) 与末次更新:")
    st_times = []
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                d = D[(g, f, r)]
                st = int(d["fs"]["start_time"])
                lu = int(d["fs"]["last_update"])
                st_times.append((st, lu, g, f, r))
    st_times.sort()
    for st, lu, g, f, r in st_times:
        print(f"    {g:<11}{f:<8}r{r}  start={datetime.fromtimestamp(st, TZ8):%m-%d %H:%M} "
              f"last_update={datetime.fromtimestamp(lu, TZ8):%m-%d %H:%M} "
              f"dur={(lu-st)/3600:.2f}h")

    print()
    print("  首次崩溃绝对时刻:")
    crash_rows = []
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                d = D[(g, f, r)]
                t0 = d["t0"]
                fc = None
                for p in d["rows"]:
                    if int(float(p[7])) > 0:
                        fc = int(float(p[0]))
                        break
                if fc is not None:
                    crash_rows.append((fc, g, f, r, (fc - t0) / 3600.0))
                else:
                    crash_rows.append((None, g, f, r, None))
    for fc, g, f, r, rel in crash_rows:
        if fc is None:
            print(f"    {g:<11}{f:<8}r{r}  无崩溃")
        else:
            print(f"    {g:<11}{f:<8}r{r}  first_crash={datetime.fromtimestamp(fc, TZ8):%m-%d %H:%M} "
                  f"(rel {rel:.4f}h)")

    print()
    print("  每个崩溃事件的增量时刻 (cum_crashes 上升点):")
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                d = D[(g, f, r)]
                t0 = d["t0"]
                prev = 0
                evs = []
                for p in d["rows"]:
                    c = int(float(p[7]))
                    if c > prev:
                        evs.append((datetime.fromtimestamp(int(float(p[0])), TZ8).strftime(
                            "%m-%d %H:%M"), c - prev, c))
                        prev = c
                if evs:
                    s = ", ".join(f"{t}(+{dl}->{cum})" for t, dl, cum in evs)
                    print(f"    {g:<11}{f:<8}r{r}  {s}")

    print()
    print("=" * 90)
    print("5. 中间态 (10-24 20:00) 反推: 该时刻之前的崩溃累计数")
    print("=" * 90)
    # 10-24 20:00 (UTC+8) 边界
    cutoff = datetime(2025, 10, 24, 20, 0, 0, tzinfo=TZ8).timestamp()
    print(f"  边界时刻 10-24 20:00 (UTC+8) = unix {cutoff:.0f}")
    tot_before, tot_after = 0, 0
    per = {}
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                d = D[(g, f, r)]
                c_before = 0
                for p in d["rows"]:
                    if int(float(p[0])) <= cutoff and int(float(p[7])) > c_before:
                        c_before = int(float(p[7]))
                c_final = int(d["fs"]["unique_crashes"])
                per[(g, f, r)] = (c_before, c_final)
                tot_before += c_before
                tot_after += c_final
    print(f"  各容器 (边界前累计 -> 终态):")
    for (g, f, r), (b, fi) in per.items():
        if fi > 0 or b > 0:
            print(f"    {g:<11}{f:<8}r{r}  {b:>3} -> {fi:>3}   (+{fi-b})")
    print(f"  合计: 边界前 {tot_before} 个 -> 终态 {tot_after} 个")

    print()
    print("=" * 90)
    print("6. 中间态与终态的覆盖率 (逐 rep, 定位 10-24 20:00 采样点)")
    print("=" * 90)
    for g in GROUPS:
        for f in FUZZERS:
            for r in REPS:
                d = D[(g, f, r)]
                # 找到最接近 10-24 20:00 的采样点
                best, bd = None, None
                for p in d["rows"]:
                    diff = abs(int(float(p[0])) - cutoff)
                    if bd is None or diff < bd:
                        bd, best = diff, p
                rel = (int(float(best[0])) - d["t0"]) / 3600.0
                print(f"    {g:<11}{f:<8}r{r}  mid_cvg={pct(best[6]):.2f}% "
                      f"(rel {rel:.2f}h, 偏离边界 {bd/60:.1f}min)  "
                      f"final_cvg={pct(d['fs']['bitmap_cvg']):.2f}%")

    print()
    print("  中间态分组均值 vs 终态分组均值 (与主理人给的中间态数字核对):")
    mid_ref = {("protorag", "chatafl"): 10.36, ("protorag", "aflnet"): 10.38,
               ("seed_reuse", "chatafl"): 9.91, ("seed_reuse", "aflnet"): 9.82}
    for g in GROUPS:
        for f in FUZZERS:
            vals = []
            for r in REPS:
                d = D[(g, f, r)]
                best, bd = None, None
                for p in d["rows"]:
                    diff = abs(int(float(p[0])) - cutoff)
                    if bd is None or diff < bd:
                        bd, best = diff, p
                vals.append(pct(best[6]))
            m = statistics.fmean(vals)
            fin = agg[(g, f)]["cvg"]
            ref = mid_ref[(g, f)]
            print(f"    {g:<11}{f:<8}  mid_recomputed={m:.3f}%  (主理人中间态={ref:.2f}%)  "
                  f"final={fin:.3f}%  Δfinal-mid={fin-m:+.3f}pp  Δfinal-主理人={fin-ref:+.3f}pp")

    print()
    print("  protorag 内部 aflnet-vs-chatafl (中间态 vs 终态):")
    for label, getter in (("mid", lambda g, f, r: _mid_cvg(D, g, f, r, cutoff)),
                           ("final", lambda g, f, r: pct(D[(g, f, r)]["fs"]["bitmap_cvg"]))):
        cs = [getter("protorag", "chatafl", r) for r in REPS]
        af = [getter("protorag", "aflnet", r) for r in REPS]
        df = [round(a - c, 6) for a, c in zip(af, cs)]
        print(f"    {label:<6} chatafl={['%.2f'%x for x in cs]}  aflnet={['%.2f'%x for x in af]}")
        print(f"           aflnet-chatafl 差值 pp = {['%+.2f'%x for x in df]}  "
              f"aflnet 胜 {sum(1 for x in df if x>0)}/5  均值={statistics.fmean(df):+.4f}pp")

    print()
    print("=" * 90)
    print("7. '以更少路径拿更高覆盖' 核实 (aflnet 侧)")
    print("=" * 90)
    for f in FUZZERS:
        print(f"  --- {f} ---")
        for metric, getter in (
            ("paths_total", lambda d: int(d["fs"]["paths_total"])),
            ("execs_done", lambda d: int(d["fs"]["execs_done"])),
            ("bitmap_cvg%", lambda d: pct(d["fs"]["bitmap_cvg"])),
            ("n_edges(P2)", lambda d: int(float(d["rows"][-1][12]))),
            ("n_states(P2)", lambda d: int(float(d["rows"][-1][11]))),
        ):
            sv = [getter(D[("seed_reuse", f, r)]) for r in REPS]
            pv = [getter(D[("protorag", f, r)]) for r in REPS]
            diff = [p - s for p, s in zip(pv, sv)]
            lower_wins = sum(1 for x in diff if x < 0)
            print(f"    {metric:<13} seed={sv} protorag={pv}")
            print(f"    {'':<13} Δ={['%+g'%x for x in diff]}  "
                  f"protorag 更低 {lower_wins}/5  均值Δ={statistics.fmean(diff):+.2f}")

    print()
    print("=" * 90)
    print("8. 崩溃总量与结构 (终态)")
    print("=" * 90)
    tot = 0
    for g in GROUPS:
        for f in FUZZERS:
            s = sum(int(D[(g, f, r)]["fs"]["unique_crashes"]) for r in REPS)
            tot += s
            print(f"    {g:<11}{f:<8} 崩溃合计 {s}")
    print(f"    总计 {tot}")
    print("  挂起 unique_hangs 合计 (chatafl 侧):")
    for g in GROUPS:
        for f in FUZZERS:
            s = sum(int(D[(g, f, r)]["fs"]["unique_hangs"]) for r in REPS)
            if s:
                print(f"    {g:<11}{f:<8} 挂起合计 {s}")


def _mid_cvg(D, g, f, r, cutoff):
    d = D[(g, f, r)]
    best, bd = None, None
    for p in d["rows"]:
        diff = abs(int(float(p[0])) - cutoff)
        if bd is None or diff < bd:
            bd, best = diff, p
    return pct(best[6])


if __name__ == "__main__":
    main()
