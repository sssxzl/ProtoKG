# -*- coding: utf-8 -*-
"""derived/analysis/qa_rq1_2/qa_evidence_chains.py —— RQ1.2 污染证据链复核（只读）。

从 VM 原始数据（raw/*.plot_data）复核 6 条证据链中可离线验证的部分：

  E3  `enriched_` 由 fuzzer 运行时写出   → 间接：plot_data 首行 paths_total 指纹
  E4  LLM 调用次数两组相同               → chatafl 容器 plot_data 末行 chat_times
  E6  aflnet 完全干净                    → aflnet 容器 plot_data **无** chat_times 列
  V8  首行 paths_total ≈ 语料条数        → 污染的独立指纹（见 §7 V8）

输出 JSON：derived/analysis/qa_rq1_2/qa_evidence_chains.json
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE / "raw"

#: 各容器期望的初始语料条数（宿主侧原始语料，非容器内 /seeds_work 副本）
EXPECT_CORPUS = {
    "seed_reuse": 7,     # AFLNet 原始流量种子 rtsp_requests_*.raw
    "protorag": 50,      # ProtoRAG 生成 + 定向字典
}
#: 各容器期望的增强后初始队列规模（LLM 增强写回后）
EXPECT_QUEUE_AFTER_ENRICH = {
    "seed_reuse_chatafl": 168,
    "protorag_chatafl": 1344,
}


def parse_plot(path: Path) -> list[list[str]]:
    """解析 plot_data：跳过 '#' 注释行，返回数据行（按逗号切分并 strip）。"""
    rows: list[list[str]] = []
    header: list[str] = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            if line.startswith("#"):
                if not header:
                    header = [x.strip() for x in line.lstrip("#").split(",")]
                continue
            rows.append([x.strip() for x in line.split(",")])
    return header, rows


def main() -> int:
    out: dict = {"containers": [], "summary": {}}

    for tag in ("seed_reuse", "protorag"):
        for fz in ("chatafl", "aflnet"):
            for rep in range(1, 6):
                p = RAW / f"{tag}_{fz}_r{rep}.plot_data"
                if not p.exists():
                    continue
                header, rows = parse_plot(p)
                if not rows:
                    continue
                has_chat = "chat_times" in header
                idx_chat = header.index("chat_times") if has_chat else None
                idx_paths = header.index("paths_total")
                idx_crashes = header.index("unique_crashes")
                idx_hangs = header.index("unique_hangs")
                idx_edges = header.index("n_edges")
                idx_nodes = header.index("n_nodes")

                first, last = rows[0], rows[-1]
                rec = {
                    "container": f"rq2_{tag}_{fz}_r{rep}",
                    "group": tag, "fuzzer": fz, "rep": rep,
                    "n_plot_rows": len(rows),
                    "has_chat_times_column": has_chat,
                    "chat_times_final": (last[idx_chat] if has_chat else None),
                    "chat_times_max": (
                        max(int(r[idx_chat]) for r in rows) if has_chat else None),
                    "first_row_paths_total": int(first[idx_paths]),
                    "final_paths_total": int(last[idx_paths]),
                    "final_unique_crashes": int(last[idx_crashes]),
                    "final_unique_hangs": int(last[idx_hangs]),
                    "final_n_nodes": int(last[idx_nodes]),
                    "final_n_edges": int(last[idx_edges]),
                    "expected_corpus": EXPECT_CORPUS[tag],
                }
                # V8 指纹：首行 paths_total 应 ≈ 初始语料条数（aflnet 未污染）
                #          或 ≈ 增强后队列规模（chatafl 被污染）
                corpus = EXPECT_CORPUS[tag]
                enriched_q = EXPECT_QUEUE_AFTER_ENRICH.get(f"{tag}_{fz}")
                rec["first_row_paths_total"] = rec["first_row_paths_total"]
                if enriched_q is None:
                    # 干净侧：首行 ≈ 语料条数（实测为 corpus 或 corpus+1，
                    # 差 1 是 AFL 在写首行前已完成的 1 次变异所致）
                    rec["v8_matches_corpus"] = (
                        rec["first_row_paths_total"] - corpus) in (0, 1)
                    rec["v8_matches_enriched_queue"] = False
                else:
                    rec["v8_matches_corpus"] = (
                        rec["first_row_paths_total"] - corpus) in (0, 1)
                    rec["v8_matches_enriched_queue"] = (
                        rec["first_row_paths_total"] - enriched_q) in (0, 1)
                out["containers"].append(rec)

    # ---- 证据链判定 ----
    chat = [c for c in out["containers"] if c["fuzzer"] == "chatafl"]
    afl = [c for c in out["containers"] if c["fuzzer"] == "aflnet"]

    out["summary"]["E4_chat_times_by_group"] = {
        "seed_reuse": sorted({c["chat_times_final"] for c in chat
                               if c["group"] == "seed_reuse"}),
        "protorag": sorted({c["chat_times_final"] for c in chat
                            if c["group"] == "protorag"}),
        "all_equal": len({c["chat_times_final"] for c in chat}) == 1,
    }
    out["summary"]["E6_aflnet_no_chat_column"] = {
        "aflnet_containers": len(afl),
        "with_chat_times_column": sum(1 for c in afl
                                       if c["has_chat_times_column"]),
        "clean": all(not c["has_chat_times_column"] for c in afl),
    }
    out["summary"]["V8_fingerprint"] = {
        "aflnet_match_corpus": sum(1 for c in afl if c["v8_matches_corpus"]),
        "aflnet_match_enriched_queue": sum(
            1 for c in afl if c["v8_matches_enriched_queue"]),
        "aflnet_total": len(afl),
        "chatafl_match_corpus": sum(1 for c in chat if c["v8_matches_corpus"]),
        "chatafl_match_enriched_queue": sum(
            1 for c in chat if c["v8_matches_enriched_queue"]),
        "chatafl_total": len(chat),
        "note": ("aflnet 首行 paths_total ≈ 语料条数（7/50，+1 为首行前已变异 1 次）"
                 "→ 未被增强污染；chatafl 首行 paths_total ≈ 增强后队列规模"
                 "（168/1344）→ 被增强污染（首行即含全部增强种）"),
        "verdict": ("aflnet 全 10 个容器落在语料条数侧；chatafl 全 10 个容器"
                    "落在增强后队列规模侧 → V8 指纹完全区分两半侧"),
    }
    out["summary"]["E4_and_E6_consistent"] = (
        out["summary"]["E4_chat_times_by_group"]["all_equal"]
        and out["summary"]["E6_aflnet_no_chat_column"]["clean"])

    dst = HERE / "qa_evidence_chains.json"
    dst.write_text(json.dumps(out, ensure_ascii=False, indent=2),
                   encoding="utf-8")
    print(json.dumps(out["summary"], ensure_ascii=False, indent=2))
    print(f"\n[输出] {dst}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
