#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA: 10-24 20:00 中间态快照复现 (年份纠正为 VM 实际年份) + n_edges 逐 rep 溯源。"""
from __future__ import annotations

import os
import statistics
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")
TZ8 = timezone(timedelta(hours=8))
GROUPS = ("seed_reuse", "protorag")
FUZZERS = ("chatafl", "aflnet")
REPS = (1, 2, 3, 4, 5)


def parse_plot(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) <= 12:
                continue
            rows.append(p)
    return rows


def parse_stats(path):
    out = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if ":" in line:
                k, _, v = line.partition(":")
                out[k.strip()] = v.strip()
    return out


def pct(s):
    return float(s.strip().rstrip("%"))


D = {}
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            tag = f"{g}_{f}_r{r}"
            rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
            fs = parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats"))
            D[(g, f, r)] = {"rows": rows, "fs": fs,
                           "t0": int(float(rows[0][0])),
                           "tstart": int(fs["start_time"])}

# ---- 确定 VM 实际年份 ----
any_start = D[("seed_reuse", "aflnet", 1)]["tstart"]
YEAR = datetime.fromtimestamp(any_start, TZ8).year
print(f"VM 实际年份 (由 fuzzer_stats.start_time 推得) = {YEAR}")
print(f"  seed_reuse_aflnet_r1 start_time = "
      f"{datetime.fromtimestamp(any_start, TZ8):%Y-%m-%d %H:%M} (UTC+8)")

CUT = datetime(YEAR, 10, 24, 20, 0, 0, tzinfo=TZ8).timestamp()
print(f"中间态边界 10-24 20:00 (UTC+8, {YEAR}) = unix {CUT:.0f}\n")


def snapshot(cut_ts):
    """在给定绝对时刻取每个容器的采样点 (取 <= cut 的最后一行)。"""
    out = {}
    for k, d in D.items():
        sel = None
        for p in d["rows"]:
            if int(float(p[0])) <= cut_ts:
                sel = p
            else:
                break
        if sel is None:
            sel = d["rows"][0]
        out[k] = {
            "cvg": pct(sel[6]),
            "crashes": int(float(sel[7])),
            "hangs": int(float(sel[8])),
            "paths": int(float(sel[3])),
            "n_states": int(float(sel[11])),
            "n_edges": int(float(sel[12])),
            "ts": int(float(sel[0])),
            "rel_h": (int(float(sel[0])) - d["t0"]) / 3600.0,
        }
    return out


snap = snapshot(CUT)

print("=" * 92)
print("A. 中间态 (10-24 20:00) 逐容器快照")
print("=" * 92)
print(f"{'container':<30}{'rel_h':>8}{'cvg%':>8}{'crash':>7}{'hang':>6}"
      f"{'paths':>8}{'n_s':>6}{'n_e':>6}")
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            s = snap[(g, f, r)]
            print(f"{g+'/'+f+'/r'+str(r):<30}{s['rel_h']:>8.2f}{s['cvg']:>8.2f}"
                  f"{s['crashes']:>7}{s['hangs']:>6}{s['paths']:>8}"
                  f"{s['n_states']:>6}{s['n_edges']:>6}")

print()
print("=" * 92)
print("B. 中间态分组均值 vs 主理人给的中间态数字")
print("=" * 92)
ref = {("protorag", "chatafl"): 10.36, ("protorag", "aflnet"): 10.38,
       ("seed_reuse", "chatafl"): 9.91, ("seed_reuse", "aflnet"): 9.82}
for g in GROUPS:
    for f in FUZZERS:
        vals = [snap[(g, f, r)]["cvg"] for r in REPS]
        m = statistics.fmean(vals)
        fin = statistics.fmean([pct(D[(g, f, r)]["fs"]["bitmap_cvg"]) for r in REPS])
        print(f"  {g:<11}{f:<8} mid={m:.4f}%  (主理人中间态={ref[(g,f)]:.2f}%)  "
              f"Δ(mid-主理人)={m-ref[(g,f)]:+.4f}pp   final={fin:.4f}%  "
              f"Δ(final-mid)={fin-m:+.4f}pp")

print()
print("=" * 92)
print("C. 中间态崩溃分布 (验证 '崩溃 8 个全在 seed_reuse_aflnet, r1=7, r3=1')")
print("=" * 92)
tot = 0
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            c = snap[(g, f, r)]["crashes"]
            if c:
                print(f"    {g:<11}{f:<8}r{r}  {c}")
            tot += c
print(f"    中间态崩溃合计 = {tot}")

print()
print("=" * 92)
print("D. n_edges 溯源: 中间态逐 rep 差值 (检验主理人 '+4/-2/-1/-1/+28, 2/5 为正')")
print("=" * 92)
for f in FUZZERS:
    se = [snap[("seed_reuse", f, r)]["n_edges"] for r in REPS]
    pe = [snap[("protorag", f, r)]["n_edges"] for r in REPS]
    diff = [p - s for p, s in zip(pe, se)]
    print(f"  {f} @中间态: seed_reuse={se} protorag={pe}")
    print(f"       差值 = {['%+d' % x for x in diff]}  正 {sum(1 for x in diff if x>0)}/5 "
          f"负 {sum(1 for x in diff if x<0)}/5")
print()
print("  对照: 终态 n_edges(P2) 差值")
for f in FUZZERS:
    se = [int(float(D[("seed_reuse", f, r)]["rows"][-1][12])) for r in REPS]
    pe = [int(float(D[("protorag", f, r)]["rows"][-1][12])) for r in REPS]
    diff = [p - s for p, s in zip(pe, se)]
    print(f"  {f} @终态: seed_reuse={se} protorag={pe}")
    print(f"       差值 = {['%+d' % x for x in diff]}  正 {sum(1 for x in diff if x>0)}/5 "
          f"负 {sum(1 for x in diff if x<0)}/5")

print()
print("  --- 穷举: 主理人序列 [+4,-2,-1,-1,+28] 能否由任何 (时刻, fuzzer, 指标) 复现? ---")
claim = [4, -2, -1, -1, 28]
targets = {"n_edges": 12, "n_states": 11, "paths_total": 3}
found = []
for fname, col in targets.items():
    for hh in [x * 0.5 for x in range(0, 49)]:
        for f in FUZZERS:
            se, pe = [], []
            ok = True
            for r in REPS:
                d = D[("seed_reuse", f, r)]
                best = None
                for p in d["rows"]:
                    rel = (int(float(p[0])) - d["t0"]) / 3600.0
                    if abs(rel - hh) <= 0.2:
                        best = p
                        break
                if best is None:
                    ok = False
                    break
                se.append(int(float(best[col])))
                d = D[("protorag", f, r)]
                best = None
                for p in d["rows"]:
                    rel = (int(float(p[0])) - d["t0"]) / 3600.0
                    if abs(rel - hh) <= 0.2:
                        best = p
                        break
                if best is None:
                    ok = False
                    break
                pe.append(int(float(best[col])))
            if not ok:
                continue
            diff = [p - s for p, s in zip(pe, se)]
            if diff == claim:
                found.append((fname, f, hh, diff))
            # 也检查 seed - protorag 方向
            diff2 = [-x for x in diff]
            if diff2 == claim:
                found.append((fname, f, hh, diff2, "REVERSED"))
if found:
    for x in found:
        print(f"    命中: {x}")
else:
    print("    ★ 在全部 (指标 x fuzzer x 0.5h 步长时间桶) 组合中均未复现主理人序列 "
          "[+4,-2,-1,-1,+28]")

print()
print("=" * 92)
print("E. 中间态 protorag 侧 aflnet-vs-chatafl 覆盖对比 (主理人: 10.36 vs 10.38)")
print("=" * 92)
cs = [snap[("protorag", "chatafl", r)]["cvg"] for r in REPS]
af = [snap[("protorag", "aflnet", r)]["cvg"] for r in REPS]
df = [round(a - c, 6) for a, c in zip(af, cs)]
print(f"  中间态 chatafl = {['%.2f' % x for x in cs]}  均值 {statistics.fmean(cs):.4f}%")
print(f"  中间态 aflnet  = {['%.2f' % x for x in af]}  均值 {statistics.fmean(af):.4f}%")
print(f"  aflnet-chatafl 逐 rep = {['%+.2f' % x for x in df]}  "
      f"aflnet 胜 {sum(1 for x in df if x>0)}/5  均值 {statistics.fmean(df):+.4f}pp")
print()
cs = [pct(D[("protorag", "chatafl", r)]["fs"]["bitmap_cvg"]) for r in REPS]
af = [pct(D[("protorag", "aflnet", r)]["fs"]["bitmap_cvg"]) for r in REPS]
df = [round(a - c, 6) for a, c in zip(af, cs)]
print(f"  终态   chatafl = {['%.2f' % x for x in cs]}  均值 {statistics.fmean(cs):.4f}%")
print(f"  终态   aflnet  = {['%.2f' % x for x in af]}  均值 {statistics.fmean(af):.4f}%")
print(f"  aflnet-chatafl 逐 rep = {['%+.2f' % x for x in df]}  "
      f"aflnet 胜 {sum(1 for x in df if x>0)}/5  均值 {statistics.fmean(df):+.4f}pp")

print()
print("=" * 92)
print("F. 中间态 -> 终态 逐 rep 覆盖率变化 (各组)")
print("=" * 92)
for g in GROUPS:
    for f in FUZZERS:
        mid = [snap[(g, f, r)]["cvg"] for r in REPS]
        fin = [pct(D[(g, f, r)]["fs"]["bitmap_cvg"]) for r in REPS]
        d = [round(b - a, 4) for a, b in zip(mid, fin)]
        print(f"  {g:<11}{f:<8} mid={['%.2f'%x for x in mid]} "
              f"final={['%.2f'%x for x in fin]}")
        print(f"  {'':<11}{'':<8} Δ  = {['%+.2f'%x for x in d]}  "
              f"均值Δ={statistics.fmean(d):+.4f}pp")

print()
print("=" * 92)
print("G. 中间态 -> 终态 崩溃变化 (逐容器)")
print("=" * 92)
for g in GROUPS:
    for f in FUZZERS:
        for r in REPS:
            m = snap[(g, f, r)]["crashes"]
            fi = int(D[(g, f, r)]["fs"]["unique_crashes"])
            if m or fi:
                print(f"    {g:<11}{f:<8}r{r}  中间态 {m:>3} -> 终态 {fi:>3}  (+{fi-m})")
