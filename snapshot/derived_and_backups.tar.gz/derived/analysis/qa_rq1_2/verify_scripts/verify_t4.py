# -*- coding: utf-8 -*-
"""独立回读校验：docx 表4 (Live555) 回填结果。

不依赖 edsdk，直接用 python-docx 读磁盘上的真实文件，逐格比对 summary.csv。
"""
import csv
import sys

import docx

DOCX = r'E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx'
SUMMARY = r'E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2/rq1_2_summary.csv'

# summary.csv 列 -> 表4 列(1-based)
COLMAP = [
    (3, 'n_states_P1'),
    (4, 'n_states_P2'),
    (5, 'n_edges_P1'),
    (6, 'n_edges_P2'),
    (7, 'bitmap_cvg_P2'),
    (8, 'unique_crashes_P2'),
    (9, 'paths_total_P2'),
]
# summary.csv 行 -> 表4 行(1-based)：docx_row 字段就是表4 行号
ROW_FIELD = 'docx_row'

HEADER_EXPECT = ['种子来源', 'Fuzzer选择', 'n_states\n(P1)', 'n_states\n(P2)',
                 'n_edges(P1)', 'n_edges(P2)', '分支覆盖%\n(P2)', '崩溃数\n(P2)',
                 '路径数\n(P2)']
SRC_EXPECT = {2: 'AFLNet 原始种子（in-rtsp）', 3: 'AFLNet 原始种子（in-rtsp）',
              4: 'ProtoRAG（实验组）', 5: 'ProtoRAG（实验组）'}
FUZ_EXPECT = {2: 'Chatafl', 3: 'aflnet', 4: 'Chatafl', 5: 'aflnet'}

ok = True


def fail(msg):
    global ok
    ok = False
    print('  [FAIL] ' + msg)


def okp(msg):
    print('  [OK]   ' + msg)


# ---- 读 summary.csv ----
with open(SUMMARY, encoding='utf-8-sig') as f:
    rows = list(csv.DictReader(f))
summary = {int(r[ROW_FIELD]): r for r in rows}
print('summary.csv 读入行数:', len(summary), 'docx_row:', sorted(summary))
print()

d = docx.Document(DOCX)
tables = d.tables
print('=' * 88)
print('1) 文档整体')
print('=' * 88)
print('  tables 总数:', len(tables))
if len(tables) == 22:
    okp('tables 总数 == 22')
else:
    fail('tables 总数 == 22  (实际 %d)' % len(tables))

# ---- 表4 结构与内容 ----
print()
print('=' * 88)
print('2) tables[4] (Live555) 逐格校验')
print('=' * 88)
t4 = tables[4]
print('  row_count=%d  col_count=%d' % (len(t4.rows), len(t4.columns)))
if len(t4.rows) == 5 and len(t4.columns) == 9:
    okp('结构 5x9')
else:
    fail('结构应为 5x9')

print()
print('  --- 表头行 (row1) 文字未变校验 ---')
hdr = [c.text for c in t4.rows[0].cells]
for i, (got, exp) in enumerate(zip(hdr, HEADER_EXPECT), start=1):
    if got == exp:
        okp('col%d 表头 == %r' % (i, got))
    else:
        fail('col%d 表头 期望 %r 实际 %r' % (i, exp, got))

print()
print('  --- col1/col2 (种子来源 / Fuzzer选择) 未变校验 ---')
for r in (2, 3, 4, 5):
    cells = [c.text for c in t4.rows[r - 1].cells]
    if cells[0] == SRC_EXPECT[r]:
        okp('row%d col1 种子来源 == %r' % (r, cells[0]))
    else:
        fail('row%d col1 期望 %r 实际 %r' % (r, SRC_EXPECT[r], cells[0]))
    if cells[1] == FUZ_EXPECT[r]:
        okp('row%d col2 Fuzzer == %r' % (r, cells[1]))
    else:
        fail('row%d col2 期望 %r 实际 %r' % (r, FUZ_EXPECT[r], cells[1]))

print()
print('  --- col3..col9 数值 vs summary.csv ---')
nchecked = 0
for r in (2, 3, 4, 5):
    cells = [c.text for c in t4.rows[r - 1].cells]
    s = summary[r]
    for col, field in COLMAP:
        got = cells[col - 1]
        exp = s[field]
        nchecked += 1
        if got == exp:
            okp('row%d col%d %-18s == %r' % (r, col, field, got))
        else:
            fail('row%d col%d %-18s 期望 %r 实际 %r' % (r, col, field, exp, got))
print()
print('  共比对数据格: %d (期望 28)' % nchecked)
if nchecked == 28:
    okp('写入格数 == 28')
else:
    fail('写入格数应为 28，实际 %d' % nchecked)

# ---- 相邻表未受影响 ----
print()
print('=' * 88)
print('3) 邻近同结构表 tables[5]/[6]/[7] 未被改动（应仍为全空数据区）')
print('=' * 88)
NEIGH = {5: 'BFTPD', 6: 'Exim', 7: 'Kamailio'}
for idx, name in NEIGH.items():
    tt = tables[idx]
    rows_txt = [[c.text for c in row.cells] for row in tt.rows]
    hdr_txt = rows_txt[0]
    body_empty = True
    for row in rows_txt[1:]:
        for j, v in enumerate(row):
            if j < 2:
                continue  # col1/col2 是标签（种子来源/Fuzzer），可能有值
            if v.strip() != '':
                body_empty = False
    if len(rows_txt) == 5 and len(hdr_txt) == 9:
        okp('tables[%d] (%s) 结构 5x9 未变，表头 col1=%r col2=%r'
            % (idx, name, hdr_txt[0], hdr_txt[1]))
    else:
        fail('tables[%d] (%s) 结构变了: %dx%d' % (idx, name, len(rows_txt), len(hdr_txt)))
    if body_empty:
        okp('tables[%d] (%s) col3..col9 仍全空 → 未被误写' % (idx, name))
    else:
        fail('tables[%d] (%s) col3..col9 非空！内容: %s'
             % (idx, name, [row[2:] for row in rows_txt[1:]]))

# ---- Live555 章节归属复核 ----
print()
print('=' * 88)
print('4) tables[4] 归属 Live555 章节复核（表前段落）')
print('=' * 88)
# 遍历 body，找 tables[4] 之前最近的含 'Live555' 的段落
body = d.element.body
paras_seen = []
tbl_index = -1
target_para = None
for child in body.iterchildren():
    tag = child.tag.split('}')[-1]
    if tag == 'p':
        txt = ''.join(n.text or '' for n in child.iter() if n.tag.endswith('}t'))
        if txt.strip():
            paras_seen.append(txt.strip())
    elif tag == 'tbl':
        tbl_index += 1
        if tbl_index == 4:
            target_para = paras_seen[-1] if paras_seen else ''
            break
print('  tables[4] 之前最近的非空段落: %r' % target_para)
if target_para and ('Live555' in target_para or 'RTSP' in target_para):
    okp('tables[4] 前段落含 Live555/RTSP → 归属正确')
else:
    fail('tables[4] 前段落未含 Live555/RTSP')
print()
print('  上下文最近 6 个非空段落:')
for p in paras_seen[-6:]:
    print('    -', p[:100])

print()
print('=' * 88)
print('5) tables[4] 全 5 行最终内容')
print('=' * 88)
for i, row in enumerate(t4.rows):
    print('  row%d: %s' % (i + 1, [c.text for c in row.cells]))

print()
print('=' * 88)
print('RESULT: %s' % ('PASS —— 全部校验通过' if ok else 'FAIL —— 存在不符项'))
print('=' * 88)
sys.exit(0 if ok else 1)
