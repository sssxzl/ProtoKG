# -*- coding: utf-8 -*-
"""QA 清单 E-1..E-8 返工验收：逐处核对当前文件状态。

判定标准：
  E-1/E-2/E-3/E-4/E-5/E-6 → 文档中必须出现终态序列，且**不得**再出现中间态序列
  E-7/E-8 → docstring 必须标为「合成示例」，断言必须未变
另加全局扫描：任何文件里不得残留中间态特征串。
"""
import os
import re
import sys

ROOT = r'E:/科研/想法idea/rag-chatafl'
fails = []


def chk(cond, msg):
    print(('[OK]   ' if cond else '[FAIL] ') + msg)
    if not cond:
        fails.append(msg)


def read(rel):
    p = os.path.join(ROOT, rel)
    with open(p, encoding='utf-8', errors='replace') as f:
        return f.read()


# 中间态特征串（应全部消失）
STALE_PATTERNS = [
    (r'\+4\s*/\s*-2\s*/\s*-1\s*/\s*-1\s*/\s*\+28', '+4/-2/-1/-1/+28 序列'),
    (r'\+4/−2/−1/−1/\+28', '+4/−2/−1/−1/+28 序列（Unicode 斜杠）'),
    (r'\+1\s*/\s*-2\s*/\s*-1\s*/\s*-1\s*/\s*\+28', '+1/-2/-1/-1/+28 序列'),
    (r'\+1/−2/−1/−1/\+28', '+1/−2/−1/−1/+28 序列（Unicode 斜杠）'),
    (r'2/5\s*为正', '「2/5 为正」'),
    (r'均值\s*\+?5\.6', '均值 +5.6'),
    (r'\+0\.37\s*/\s*\+0\.69\s*/\s*\+0\.44', '+0.37/+0.69/+0.44 覆盖序列'),
    (r'\+0\.37／\+0\.69／\+0\.44', '+0.37／+0.69／+0.44 覆盖序列（全角）'),
    (r'\+0\.37\s*\+\+?\s*\+0\.69', '+0.37++0.69 变体'),
]
# 终态序列（应存在）
FINAL_PATTERNS = [
    (r'−4\s*/\s*\+10\s*/\s*\+5\s*/\s*\+25\s*/\s*\+29', '终态 n_edges 序列（Unicode）'),
    (r'-4\s*/\s*\+10\s*/\s*\+5\s*/\s*\+25\s*/\s*\+29', '终态 n_edges 序列（ASCII）'),
    (r'\+0\.20\s*/\s*\+0\.63\s*/\s*\+0\.52\s*/\s*\+0\.63\s*/\s*\+0\.67', '终态覆盖序列'),
    (r'13\.00', '终态 n_edges 均值 +13.00'),
]

TARGETS = [
    'local/RQ3_QA验收报告_20261024.md',
    'local/RQ3_技术方案_20261024.md',
    'scripts/rq3_stats.py',
    'tests/fused/test_rq3_metrics.py',
]

# ★ 代码文件（.py）里，合成示例序列是**必须保留**的 ——
#   tests/fused/test_rq3_metrics.py 的断言直接依赖 paired_win_rate([4,-2,-1,-1,28])，
#   删掉该序列就无从验证。文档文件（.md）里则必须清零。
DOC_TARGETS = [t for t in TARGETS if t.endswith('.md')]
CODE_TARGETS = [t for t in TARGETS if t.endswith('.py')]

print('=' * 92)
print('1) 全局扫描：中间态特征串是否已彻底清除')
print('=' * 92)
print('  【文档类】中间态串必须为 0 —— 文档不得引用中间态数字作为结论')
for rel in DOC_TARGETS:
    txt = read(rel)
    hits = []
    for pat, name in STALE_PATTERNS:
        for m in re.finditer(pat, txt):
            line = txt[:m.start()].count('\n') + 1
            hits.append('%s @L%d' % (name, line))
    if hits:
        print('  [FAIL] %s 残留 %d 处:' % (rel, len(hits)))
        for h in hits:
            print('           ' + h)
        fails.append('%s 残留中间态串 %s' % (rel, hits))
    else:
        print('  [OK]   %s 无中间态特征串' % rel)

print()
print('  【代码类】合成示例串允许存在，但必须紧邻「合成示例」标注')
for rel in CODE_TARGETS:
    txt = read(rel)
    for pat, name in STALE_PATTERNS:
        for m in re.finditer(pat, txt):
            line = txt[:m.start()].count('\n') + 1
            # 取所在 docstring 段落（往回找到最近的 """ 或 def）
            head = txt[:m.start()]
            seg_start = max(head.rfind('"""'), head.rfind("'''"))
            seg = txt[seg_start:m.end() + 400] if seg_start >= 0 else txt[max(0, m.start() - 400):m.end() + 400]
            labeled = '合成示例' in seg
            ctx = seg[max(0, seg.find(name) - 60):seg.find(name) + 120].replace('\n', ' ')
            print('  [%s] %s @L%d  %s' % ('OK  ' if labeled else 'FAIL', rel, line, name))
            print('         上下文: ...%s...' % ctx[:170])
            if not labeled:
                fails.append('%s L%d 合成示例串缺少「合成示例」标注' % (rel, line))

print()
print('=' * 92)
print('2) 终态数值是否已就位')
print('=' * 92)
for rel in TARGETS:
    txt = read(rel)
    present = [name for pat, name in FINAL_PATTERNS if re.search(pat, txt)]
    if present:
        print('  [OK]   %-42s 命中终态: %s' % (rel, '; '.join(present)))
    else:
        print('  [  -  ] %-42s 无终态数值命中（可能本就不含，属正常）' % rel)

print()
print('=' * 92)
print('3) 逐项验收 E-1 .. E-8')
print('=' * 92)
qa = read('local/RQ3_QA验收报告_20261024.md')
tech = read('local/RQ3_技术方案_20261024.md')
stats_py = read('scripts/rq3_stats.py')
test_py = read('tests/fused/test_rq3_metrics.py')

# E-1 QA报告 513 附近：aflnet n_edges 终态
m = re.search(r'n_edges[^\n]*?aflnet[^\n]*?(−4|-4)[^\n]*?(\+10)[^\n]*?(\+5)[^\n]*?(\+25)[^\n]*?(\+29)[^\n]*?4/5', qa)
chk(m is not None, 'E-1 QA报告含 aflnet 终态 n_edges 序列 + 4/5')
chk('4/5 为正' in qa or '4/5' in qa, 'E-1 QA报告含 4/5 表述')
chk(not re.search(r'\+4\s*/\s*-2\s*/\s*-1\s*/\s*-1\s*/\s*\+28', qa), 'E-1 QA报告已无 +4/-2/-1/-1/+28')

# E-2 R-8
chk(re.search(r'R-8[^\n]*?4/5', qa) is not None, 'E-2 R-8 行含 4/5')
chk(re.search(r'R-8[^\n]*?2/5', qa) is None, 'E-2 R-8 行已无 2/5')

# E-3 技术方案 1246 附近：主理人指示段
chk(re.search(r'−4\s*/\s*\+10\s*/\s*\+5\s*/\s*\+25\s*/\s*\+29', tech) is not None,
    'E-3 技术方案含终态 n_edges 序列')
chk(not re.search(r'\+4\s*/\s*-2\s*/\s*-1\s*/\s*-1\s*/\s*\+28', tech), 'E-3 技术方案已无旧序列')

# E-4 / E-5 三处自相矛盾
for pat, label in [(r'均值\s*\+?5\.6', '均值 +5.6'), (r'2/5\s*为正', '「2/5 为正」')]:
    chk(re.search(pat, tech) is None, 'E-4/E-5 技术方案已无「%s」' % label)
chk(re.search(r'n_edges[^\n]*?4/5[^\n]*?1 个负值', tech) is not None or
    re.search(r'4/5[^\n]*?有 1 个负值', tech) is not None,
    'E-4/E-5 技术方案用「4/5 为正但 r1 为负」的自洽表述')

# E-6 A55
chk(re.search(r'A55[^\n]*\+0\.20/\+0\.63/\+0\.52/\+0\.63/\+0\.67', tech) is not None,
    'E-6 A55 行覆盖已改为终态序列')
chk(re.search(r'A55[^\n]*−4/\+10/\+5/\+25/\+29', tech) is not None,
    'E-6 A55 行 n_edges 已改为终态序列')

# E-7 docstring
m7 = re.search(r'paired_win_rate[\s\S]{0,600}?合成示例', stats_py)
chk(m7 is not None, 'E-7 rq3_stats.py docstring 已标「合成示例」')
chk('主理人实证' not in stats_py[stats_py.find('def paired_win_rate'):stats_py.find('def paired_win_rate') + 800],
    'E-7 rq3_stats.py 该函数 docstring 已无「主理人实证」')

# E-8 docstring + 断言
i = test_py.find('def test_paired_win_rate_outlier_dominates_mean')
seg = test_py[i:i + 900] if i >= 0 else ''
chk('合成示例' in seg, 'E-8 测试 docstring 已标「合成示例」')
chk('胜率仅 2/5' in seg or '胜率仅 **2/5**' in seg, 'E-8 docstring 已改为「胜率仅 2/5」')
chk('主理人实证' not in seg, 'E-8 docstring 已无「主理人实证」')
# 断言必须未变
chk('assert wr["wins"] == 2' in seg, 'E-8 断言 wins == 2 未变')
chk('win_rate"] == pytest.approx(0.4)' in seg, 'E-8 断言 win_rate == 0.4 未变')
chk('mean_diff"] == pytest.approx(5.6)' in seg, 'E-8 断言 mean_diff == 5.6 未变')

print()
print('=' * 92)
print('4) 断言自洽性核对：合成示例 [4,-2,-1,-1,28] 的真实统计量')
print('=' * 92)
d = [4, -2, -1, -1, 28]
w = sum(1 for x in d if x > 0)
import statistics
print('  序列 %s' % d)
print('  wins = %d  → 胜率 %d/5 = %.1f  （docstring 应写 2/5，与断言 wins==2 / 0.4 一致）'
      % (w, w, w / 5))
print('  mean = %.1f  sd = %.2f' % (statistics.mean(d), statistics.stdev(d)))
chk(w == 2, '合成示例胜率实为 2/5（与断言一致）')
chk(abs(statistics.mean(d) - 5.6) < 1e-9, '合成示例均值实为 +5.6（与断言一致）')

print()
print('=' * 92)
print('RESULT: %s' % ('PASS —— E-1..E-8 全部返工到位' if not fails else 'FAIL —— %d 项未过' % len(fails)))
for f in fails:
    print('   - ' + f)
print('=' * 92)
sys.exit(0 if not fails else 1)
