# -*- coding: utf-8 -*-
"""终稿回归校验：把 v7 主记录的关键数值与源 CSV / 我实测的裁决数据逐项对账。

源：
  derived/analysis/data/rq1_2/rq1_2_summary.csv        （docx 表4 同源）
  derived/analysis/data/rq1_2/rq1_2_p2.csv              （终态逐容器）
  derived/analysis/data/rq1_2/rq1_2_norm_matched.csv    （等执行预算，我的裁决）
  derived/analysis/data/rq1_2/rq1_2_ttt.csv             （时间-阈值，我的裁决）
  derived/analysis/data/rq1_2/rq1_2_crash_lineage.csv   （崩溃血缘，我的裁决）
"""
import csv
import os
import re
import statistics
import sys

LOCAL = r'E:/科研/想法idea/rag-chatafl/local'
DATA = r'E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2'
REC = os.path.join(LOCAL, 'RQ1_2_Live555实验记录.md')

fails = []


def chk(cond, msg):
    print(('[OK]   ' if cond else '[FAIL] ') + msg)
    if not cond:
        fails.append(msg)


def load(name, base=DATA):
    with open(os.path.join(base, name), encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


rec = open(REC, encoding='utf-8').read()
rec_nb = rec.replace('**', '')   # 去粗体

sm = load('rq1_2_summary.csv')
p2 = load('rq1_2_p2.csv')
matched = load('rq1_2_norm_matched.csv')
ttt = load('rq1_2_ttt.csv')
lineage = load('rq1_2_crash_lineage.csv')

print('=' * 92)
print('1) §2 四行 == summary.csv（逐格字符串相等）')
print('=' * 92)
COLS = ['n_states_P1', 'n_states_P2', 'n_edges_P1', 'n_edges_P2',
        'bitmap_cvg_P2', 'unique_crashes_P2', 'paths_total_P2']
for r in sm:
    row = int(float(r['docx_row']))
    seq = ' | '.join(str(r[c]).strip() for c in COLS)
    chk(('| %d |' % row) in rec_nb, 'row%d 存在' % row)
    chk(seq in rec_nb, 'row%d 七值按序连续: %s' % (row, seq))

print()
print('=' * 92)
print('2) §3.4 等执行预算表 == 我实测的 rq1_2_norm_matched.csv')
print('=' * 92)
for r in matched:
    fz, rep = r['fuzzer'], int(r['rep'])
    diff = float(r['diff_pp'])
    raw = float(r['raw_diff_pp'])
    # 文档若采用 AFL 报告的 2 位小数采样值（cov_sr=9.87）而非我的线性插值（9.8647），
    # diff 会相差 0.005pp（aflnet r4）—— 两种写法都接受。
    cands = ['%+.2f' % diff, '%+.3f' % diff, '%+.2f' % raw]
    hit = any(c in rec_nb for c in cands)
    chk(hit, '%s r%d diff=%+.3f (raw %+.3f) 出现在文档' % (fz, rep, diff, raw))
# 汇总均值
for fz in ('chatafl', 'aflnet'):
    ds = [float(r['diff_pp']) for r in matched if r['fuzzer'] == fz]
    w = sum(1 for d in ds if d > 0)
    m = statistics.mean(ds)
    print('  我的数据: %s mean %+.3f win %d/5' % (fz, m, w))
    chk(('%+.2f' % m) in rec_nb or ('%.2f' % m) in rec_nb,
        '%s 等预算均值 %+.2f 出现在文档' % (fz, m))
    chk(w == 5, '%s 等预算 win 5/5' % fz)

print()
print('=' * 92)
print('3) §3.5 时间-阈值 == 我实测的 rq1_2_ttt.csv')
print('=' * 92)
for r in ttt:
    fz, thr, rep = r['fuzzer'], float(r['threshold']), int(r['rep'])
    tpr = r['t_protorag_h']
    tsr = r['t_seed_reuse_h']
    if tpr:
        # 文档应含 protorag 的到达时刻（1~2 位小数）
        cands = ['%.1f' % float(tpr), '%.2f' % float(tpr),
                 '%.0f' % float(tpr)]
        chk(any(c in rec_nb for c in cands),
            '%s 门槛%.2f r%d protorag 到达 %sh 出现在文档' % (fz, thr, rep, tpr))
    if tsr:
        cands = ['%.1f' % float(tsr), '%.2f' % float(tsr), '%.0f' % float(tsr)]
        chk(any(c in rec_nb for c in cands),
            '%s 门槛%.2f r%d seed_reuse 到达 %sh 出现在文档' % (fz, thr, rep, tsr))

print()
print('=' * 92)
print('4) §5.5 崩溃散文核查 == 我实测的散文统计（75 样本 / 28 含 / 27 强）')
print('=' * 92)
chk('75' in rec_nb, '文档含样本总数 75')
chk('28' in rec_nb, '文档含含散文数 28')
chk('27' in rec_nb, '文档含强散文数 27')

print()
print('=' * 92)
print('5) 崩溃血缘（新增硬证据）是否已进文档')
print('=' * 92)
enr = sum(int(r['n_crashes']) for r in lineage if r['category'] == 'enriched')
pln = sum(int(r['n_crashes']) for r in lineage if r['category'] == 'plain')
tot_crashes = sum(int(float(r['final_unique_crashes'])) for r in load('rq1_2_extra_crashdist.csv'))
print('  我的血缘数据: enriched=%d plain=%d 总计=%d' % (enr, pln, enr + pln))
# 血缘必须 100% 覆盖全部崩溃（每个崩溃样本都能溯源到根种子）
chk(enr + pln == tot_crashes,
    '血缘覆盖全部崩溃 %d/%d (enriched=%d, plain=%d)' % (enr + pln, tot_crashes, enr, pln))
chk(enr == 27, '其中 LLM 富集产物崩溃 = 27 (chatafl 半侧基线)')
chk(pln == 48, '其中原始种子崩溃 = 48 (aflnet 47 + 实验组 1)')
for key in ['enriched_', 'rtsp_requests_aac.raw', '25_DESCRIBE+TEARDOWN+OPTIONS+OPTIONS']:
    chk(key in rec_nb, '文档含血缘关键串: %r' % key)

print()
print('=' * 92)
print('6) ★ 全文不得残留已作废的「归一化后反转」结论')
print('=' * 92)
# 注意：这些串**允许**出现在「已作废 / 不再使用 / 不要用」这类否定语境中，
# 因为方法学纠错本身需要点明被否决的结论。判定标准 = 是否处于否定语境。
NEG_MARKERS = ['不再', '构造有偏', '作废', '不是有效', '不作为', '禁止',
                '不要用', '方法学提示', '方法学修正', '不能用于', '不具区分度']
STALE = [
    '归一化后结论发生反转',
    '归一化覆盖率 **0/5 全部落后**',
    '原始 5/5 优势在归一化后 0/5 反转',
    '每百万次执行的覆盖率',
    '归一化后 0/5 反转',
]
for s in STALE:
    n = 0
    bad_ctx = []
    for m in re.finditer(re.escape(s), rec_nb):
        n += 1
        ctx = rec_nb[max(0, m.start() - 300):m.end() + 300]
        if not any(k in ctx for k in NEG_MARKERS):
            bad_ctx.append(ctx[280:380].replace('\n', ' '))
    if bad_ctx:
        chk(False, '「%s」命中 %d 处，其中 %d 处不在否定语境: %s'
            % (s, n, len(bad_ctx), bad_ctx[0][:120]))
    else:
        chk(True, '「%s」命中 %d 处，全部处于否定/作废语境 ✅' % (s, n))
        for m in re.finditer(re.escape(s), rec_nb):
            ctx = rec_nb[max(0, m.start() - 120):m.end() + 120].replace('\n', ' ')
            print('      · ...%s...' % ctx[100:260])

print()
print('=' * 92)
print('7) §0 结论块与 §3.4/§3.5 的一致性（不得自相矛盾）')
print('=' * 92)
# §0 若提到 chatafl 降级，理由只能是「唯一变量不成立/污染」
m = re.search(r'## 0\.[\s\S]{0,3000}?(?=## 0\.1)', rec_nb)
if m:
    sec0 = m.group(0)
    print('  §0 长度 %d 字符' % len(sec0))
    chk('chatafl' in sec0, '§0 提及 chatafl 半侧')
    chk('污染' in sec0 or '唯一变量' in sec0, '§0 给出 chatafl 降级理由（污染/唯一变量）')
    # §0 里不得说「归一化口径下不可用」
    bad = [k for k in ['归一化口径', '无论原始口径'] if k in sec0]
    chk(not bad, '§0 未残留「归一化口径」类表述 (命中 %s)' % bad)

print()
print('=' * 92)
print('8) 结构性检查')
print('=' * 92)
chk('### 3.4 ★ 等执行预算覆盖率' in rec, '§3.4 标题已改为「等执行预算覆盖率」')
chk('### 3.5 ★ 时间-阈值口径' in rec, '§3.5 时间-阈值章节存在')
chk(rec_nb.count('## 8. 统计显著性与表述纪律') == 1, '§8 唯一')
chk('### 4.4' in rec, '§4.4 存在')
na = [l for l in rec.split('\n') if re.search(r'\|\s*NA\s*\|', l)]
chk(not na, '无 | NA | 残留行（%d 行）' % len(na))

print()
print('=' * 92)
print('RESULT: %s' % ('PASS —— 终稿与源数据一致' if not fails else 'FAIL —— %d 项' % len(fails)))
for f in fails:
    print('   - ' + f)
print('=' * 92)
sys.exit(0 if not fails else 1)
