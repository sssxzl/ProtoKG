# -*- coding: utf-8 -*-
"""全 22 张表快照：证明只动了 tables[4]，其余表原样未变。

方法：与 doc_list_tables 的 first_row_texts + python-docx 的每行内容一起打印，
标出哪些表含非空数据格。
"""
import json

import docx

DOCX = r'E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx'
TL = r'C:/Users/13594/WorkBuddy/2026-10-24-19-39-53/tl.json'

with open(TL, encoding='utf-8') as f:
    tl = json.load(f)
ts = tl['tables']

d = docx.Document(DOCX)
tables = d.tables

print('tables 总数:', len(tables), '| doc_list_tables 数量:', len(ts))
print()
print('%-5s %-10s %-6s %-6s  %s' % ('idx', 'table_id', 'rows', 'cols', '数据区(col3+)非空格数 / 首行'))
print('-' * 100)
data_tables = []
for i, t in enumerate(tables):
    tid = ts[i].get('table_id') if i < len(ts) else '?'
    rows = [[c.text for c in r.cells] for r in t.rows]
    hdr = rows[0] if rows else []
    ncols = len(hdr)
    nonempty = 0
    for row in rows[1:]:
        for v in row[2:]:
            if v.strip():
                nonempty += 1
    flag = ''
    if nonempty:
        data_tables.append((i, tid, nonempty))
        flag = '  <<< 有数据'
    print('%-5d %-10s %-6d %-6d  %d  %s%s' % (
        i, tid, len(rows), ncols, nonempty, ' | '.join(h.replace('\n', '/') for h in hdr[:3]), flag))

print()
print('=' * 100)
print('含非空数据格的表（应为且仅为 Live555 表4）：')
for i, tid, n in data_tables:
    print('  tables[%d]  table_id=%s  非空格数=%d' % (i, tid, n))
print()
if len(data_tables) == 1 and data_tables[0][0] == 4:
    print('RESULT: PASS —— 只有 tables[4] 含数据，其余 21 张表数据区全空（未被误写）')
else:
    print('RESULT: FAIL —— 含数据的表: %s' % [d_[0] for d_ in data_tables])

print()
print('=' * 100)
print('tables[5]/[6]/[7] 全行明细（BFTPD / Exim / Kamailio）：')
for i in (5, 6, 7):
    print('  --- tables[%d] (table_id=%s) ---' % (i, ts[i].get('table_id')))
    for r, row in enumerate(tables[i].rows):
        print('    row%d: %s' % (r + 1, [c.text for c in row.cells]))
