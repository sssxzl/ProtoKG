# -*- coding: utf-8 -*-
"""RQ1.2 实验记录所需的全部统计量（只读本地 CSV，不写文件）。

数据源：
  最终态  : E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2/
  中间态  : E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2_interim_20261024/
"""
import csv
import os
import statistics
from collections import defaultdict

FINAL = r'E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2'
INTERIM = r'E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2_interim_20261024'

NUMF = ('n_states', 'n_edges', 'bitmap_cvg', 'unique_crashes',
        'unique_hangs', 'paths_total', 'execs_done', 'rel_hours',
        'first_crash_rel_hours')


def load(path):
    out = []
    with open(path, encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            for k in NUMF:
                if k in r and r[k] is not None:
                    v = str(r[k]).strip().replace('%', '')
                    try:
                        r[k] = float(v)
                    except ValueError:
                        r[k] = None
            if 'rep' in r and r['rep'] is not None:
                try:
                    r['rep'] = int(str(r['rep']).strip())
                except ValueError:
                    pass
            out.append(r)
    return out


def stat(vals, fmt='{:.2f}'):
    vals = [v for v in vals if v is not None]
    if not vals:
        return ('NA', 'NA', 0)
    m = statistics.mean(vals)
    sd = statistics.stdev(vals) if len(vals) > 1 else 0.0
    return (fmt.format(m), fmt.format(sd), len(vals))


p1 = load(os.path.join(FINAL, 'rq1_2_p1.csv'))
p2 = load(os.path.join(FINAL, 'rq1_2_p2.csv'))
i1 = load(os.path.join(INTERIM, 'rq1_2_p1.csv'))
i2 = load(os.path.join(INTERIM, 'rq1_2_p2.csv'))
ts = load(os.path.join(FINAL, 'rq1_2_timeseries.csv'))

print('#' * 88)
print('# A. 中间态 vs 最终态（逐指标，同容器配对）')
print('#' * 88)
print('中间态目录 mtime: %s' % os.path.getmtime(INTERIM))
print()
KEYS = [('bitmap_cvg', '分支覆盖%(P2)'), ('n_states', 'n_states(P2)'),
        ('n_edges', 'n_edges(P2)'), ('paths_total', '路径数(P2)'),
        ('unique_crashes', '唯一崩溃数'), ('unique_hangs', '唯一挂起数'),
        ('execs_done', 'execs_done')]
for metric, label in KEYS:
    print('--- %s ---' % label)
    for g in ('seed_reuse', 'protorag'):
        for fz in ('chatafl', 'aflnet'):
            iv = [r[metric] for r in i2 if r['group'] == g and r['fuzzer'] == fz]
            fv = [r[metric] for r in p2 if r['group'] == g and r['fuzzer'] == fz]
            im, isd, _ = stat(iv, '{:.2f}')
            fm, fsd, _ = stat(fv, '{:.2f}')
            d = None
            if iv and fv and all(v is not None for v in iv) and all(v is not None for v in fv):
                d = statistics.mean(fv) - statistics.mean(iv)
            dstr = ('%+0.2f' % d) if d is not None else 'NA'
            print('  %-11s %-8s 中间态=%-9s 最终=%-9s Δ=%s' % (g, fz, im, fm, dstr))
    print()

print('#' * 88)
print('# B. 中间态崩溃数（逐容器，确认中间态崩溃是否全 0）')
print('#' * 88)
nz = [(r['group'], r['fuzzer'], r['rep'], r['unique_crashes'])
      for r in i2 if r['unique_crashes']]
print('中间态 unique_crashes != 0 的容器:', nz if nz else '无（全部为 0）')
nz_h = [(r['group'], r['fuzzer'], r['rep'], r['unique_hangs'])
        for r in i2 if r['unique_hangs']]
print('中间态 unique_hangs != 0 的容器:', nz_h if nz_h else '无（全部为 0）')
print()

print('#' * 88)
print('# C. 崩溃首现时刻（最终态）')
print('#' * 88)
cd = load(os.path.join(FINAL, 'rq1_2_extra_crashdist.csv'))
for r in cd:
    fh = r.get('first_crash_rel_hours')
    fh = 'never' if fh in (None, '') else '%.2fh' % float(fh)
    print('  %-28s 首现=%-8s 最终崩溃=%-5s 挂起=%-5s 路径=%-6s execs=%s'
          % (r['container'], fh, r['final_unique_crashes'],
             r['final_unique_hangs'], r['paths_total'], r['execs_done']))
print()

print('#' * 88)
print('# D. 时序覆盖率桶均值（最终态，5 rep 平均）')
print('#' * 88)
buckets = [0.5, 1, 2, 4, 6, 8, 12, 18, 24]
print('| group | fuzzer | ' + ' | '.join('%gh' % b for b in buckets) + ' |')
print('|---|---|' + '---|' * len(buckets))
for g in ('seed_reuse', 'protorag'):
    for fz in ('chatafl', 'aflnet'):
        cells = []
        for b in buckets:
            vals = [r['bitmap_cvg'] for r in ts
                    if r['group'] == g and r['fuzzer'] == fz and abs(r['rel_hours'] - b) < 0.2]
            cells.append('%.2f' % statistics.mean(vals) if vals else 'NA')
        print('| %s | %s | %s |' % (g, fz, ' | '.join(cells)))
print()

print('#' * 88)
print('# E. 时序 paths_total 桶均值')
print('#' * 88)
print('| group | fuzzer | ' + ' | '.join('%gh' % b for b in buckets) + ' |')
print('|---|---|' + '---|' * len(buckets))
for g in ('seed_reuse', 'protorag'):
    for fz in ('chatafl', 'aflnet'):
        cells = []
        for b in buckets:
            vals = [r['paths_total'] for r in ts
                    if r['group'] == g and r['fuzzer'] == fz and abs(r['rel_hours'] - b) < 0.2]
            cells.append('%.0f' % statistics.mean(vals) if vals else 'NA')
        print('| %s | %s | %s |' % (g, fz, ' | '.join(cells)))
print()

print('#' * 88)
print('# F. 反超核对（protorag - seed_reuse，同 fuzzer 同 rep 配对）')
print('#' * 88)
for metric, label, fmt in [('bitmap_cvg', '分支覆盖%(pp)', '{:+.2f}'),
                           ('n_edges', 'n_edges', '{:+.1f}'),
                           ('n_states', 'n_states', '{:+.1f}'),
                           ('paths_total', '路径数', '{:+.0f}'),
                           ('unique_crashes', '唯一崩溃数', '{:+.2f}'),
                           ('unique_hangs', '唯一挂起数', '{:+.0f}')]:
    print('--- %s ---' % label)
    for fz in ('chatafl', 'aflnet'):
        ds = []
        for rep in range(1, 6):
            a = [r for r in p2 if r['group'] == 'protorag' and r['fuzzer'] == fz and r['rep'] == rep]
            b = [r for r in p2 if r['group'] == 'seed_reuse' and r['fuzzer'] == fz and r['rep'] == rep]
            if a and b and a[0][metric] is not None and b[0][metric] is not None:
                ds.append(a[0][metric] - b[0][metric])
        wr = sum(1 for d in ds if d > 0)
        sd = statistics.stdev(ds) if len(ds) > 1 else 0.0
        mean = statistics.mean(ds) if ds else 0
        print('  %-8s win %d/%d  mean %s  sd %.2f  [%s]'
              % (fz, wr, len(ds), fmt.format(mean), sd,
                 ' '.join(fmt.format(d) for d in ds)))
    print()

print('#' * 88)
print('# G. 汇总表（最终态，与 docx 表4 一致）')
print('#' * 88)
ROWMAP = [(2, 'AFLNet 原始种子（in-rtsp）', 'Chatafl', 'seed_reuse', 'chatafl'),
          (3, 'AFLNet 原始种子（in-rtsp）', 'aflnet', 'seed_reuse', 'aflnet'),
          (4, 'ProtoRAG（实验组）', 'Chatafl', 'protorag', 'chatafl'),
          (5, 'ProtoRAG（实验组）', 'aflnet', 'protorag', 'aflnet')]
for row, src, fzl, g, fz in ROWMAP:
    r1 = [r for r in p1 if r['group'] == g and r['fuzzer'] == fz]
    r2 = [r for r in p2 if r['group'] == g and r['fuzzer'] == fz]
    def st(rows, k):
        v = [r[k] for r in rows if r[k] is not None]
        return (statistics.mean(v), statistics.stdev(v) if len(v) > 1 else 0.0)
    ns1, s1 = st(r1, 'n_states'); ne1, s2 = st(r1, 'n_edges')
    ns2, s3 = st(r2, 'n_states'); ne2, s4 = st(r2, 'n_edges')
    cg, s5 = st(r2, 'bitmap_cvg'); cr, s6 = st(r2, 'unique_crashes')
    pt, s7 = st(r2, 'paths_total')
    print('row%d %-24s %-8s | n_st(P1) %.1f±%.1f | n_st(P2) %.1f±%.1f | n_ed(P1) %.1f±%.1f | n_ed(P2) %.1f±%.1f | cvg %.2f±%.2f | crash %.2f±%.2f | paths %.0f±%.0f'
          % (row, src, fzl, ns1, s1, ns2, s3, ne1, s2, ne2, s4, cg, s5, cr, s6, pt, s7))
