# -*- coding: utf-8 -*-
"""跨文档一致性：主记录 v7 与 污染说明 v4（我维护）必须口径一致。

两份文档由不同人维护（final/v6 主记录、me 污染说明），最容易出现口径漂移。
本脚本逐项比对两份文档对同一事实的表述。
"""
import os
import re
import sys

LOCAL = r'E:/科研/想法idea/rag-chatafl/local'
REC = os.path.join(LOCAL, 'RQ1_2_Live555实验记录.md')
POL = os.path.join(LOCAL, 'RQ1_2_实验记录_污染说明.md')

fails = []


def chk(cond, msg):
    print(('[OK]   ' if cond else '[FAIL] ') + msg)
    if not cond:
        fails.append(msg)


rec = open(REC, encoding='utf-8').read().replace('**', '')
pol = open(POL, encoding='utf-8').read().replace('**', '')
both = {'主记录': rec, '污染说明': pol}

print('=' * 92)
print('1) 关键事实：两份文档必须给出一致的数值')
print('=' * 92)
FACTS = [
    ('等执行预算 chatafl 5/5 均值', '+0.48'),
    ('等执行预算 aflnet 5/5 均值', '+0.62'),
    ('崩溃总数', '75'),
    ('基线崩溃', '74'),
    ('chatafl 侧污染占比', '96%'),
    ('P1 队列 chatafl 侧', '1344'),
    ('P1 队列 seed_reuse chatafl', '168'),
    ('aflnet 队列 protorag', '51'),
    ('aflnet 队列 seed_reuse', '8'),
]
for label, needle in FACTS:
    inrec = needle in rec
    inpol = needle in pol
    mark = '✅' if (inrec and inpol) else ('⚠ ' if inrec else '❌')
    print('  %s %-34s 主记录=%-5s 污染说明=%-5s' % (mark, label, inrec, inpol))
    # 主记录必须有；污染说明是补充文档，允许缺
    if not inrec:
        fails.append('%s 主记录缺 %r' % (label, needle))
        chk(False, '%s 主记录缺 %r' % (label, needle))

print()
print('=' * 92)
print('2) 口径纪律：两份文档都不得出现「归一化后反转」类肯定表述')
print('=' * 92)
NEG = ['不再', '构造有偏', '作废', '不是有效', '不能用于', '不要用', '方法学']
for name, txt in both.items():
    for m in re.finditer(r'归一化后 0/5 反转|归一化后结论发生反转|归一化覆盖率 0/5', txt):
        ctx = txt[max(0, m.start() - 320):m.end() + 320]
        neg = any(k in ctx for k in NEG)
        chk(neg, '%s: 「%s」处于否定语境' % (name, m.group(0)))
        if not neg:
            print('        上下文: ...%s...' % ctx[280:420].replace('\n', ' '))

print()
print('=' * 92)
print('3) 降级理由一致性：chatafl 半侧降级只能因「污染/唯一变量不成立」')
print('=' * 92)
for name, txt in both.items():
    # 找 chatafl 降级相关段落
    segs = re.findall(r'[^\n]*chatafl[^\n]*降级[^\n]*', txt)
    hit = any(('污染' in s or '唯一变量' in s) for s in segs)
    if segs:
        chk(hit, '%s: chatafl 降级表述含「污染/唯一变量」（命中 %d 段）' % (name, len(segs)))
    else:
        print('  [  -  ] %s: 无「chatafl…降级」同句表述（可能跨行）' % name)

print()
print('=' * 92)
print('4) 表述红线一致性（三条红线应同时存在于两份文档）')
print('=' * 92)
RED_LINES = [
    ('不得声称「ProtoRAG 不会发现崩溃」', ['不会发现崩溃']),
    ('不得声称「稳定探索到更多状态机边」', ['稳定探索到更多']),
    ('不得把 chatafl 半侧数字当 ProtoRAG 有效性证据', ['chatafl 半侧', 'ProtoRAG 有效性', '更差']),
]
for label, keys in RED_LINES:
    for name, txt in both.items():
        hit = all(k in txt for k in keys)
        chk(hit, '%s: 红线「%s」存在' % (name, label))

print()
print('=' * 92)
print('5) 崩溃血缘拆解（enriched 27 / 原始 48）是否在主记录中')
print('=' * 92)
for k in ['enriched_', 'rtsp_requests_aac.raw', '25_DESCRIBE+TEARDOWN+OPTIONS+OPTIONS']:
    chk(k in rec, '主记录含血缘关键串 %r' % k)
# 数量表述
chk(re.search(r'27[^\n]{0,40}enriched|enriched[^\n]{0,40}27', rec) is not None,
    '主记录含「27 个 enriched 崩溃」的表述')

print()
print('=' * 92)
print('6) 挂起数字一致性（861 chatafl / 2 aflnet / 863 总计）')
print('=' * 92)
chk('863' in rec, '主记录含挂起总数 863')
chk('863' in pol, '污染说明含挂起总数 863')
for k in ['861', '430']:
    chk(k in pol or k in rec, '含挂起量级串 %r（861 或 430 倍）' % k)

print()
print('=' * 92)
print('RESULT: %s' % ('PASS —— 两份文档口径一致' if not fails else 'FAIL —— %d 项' % len(fails)))
for f in fails:
    print('   - ' + f)
print('=' * 92)
sys.exit(0 if not fails else 1)
