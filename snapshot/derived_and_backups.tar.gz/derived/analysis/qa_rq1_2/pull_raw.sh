#!/bin/bash
# QA independent raw pull: 20 containers, plot_data + fuzzer_stats
# Read-only from VM; writes into local qa cache.
set -u
SSH="ssh -o ConnectTimeout=20 -o StrictHostKeyChecking=no -i ~/.ssh/vm_ubuntu_zxy zxy@192.168.37.130"
BASE="/home/zxy/rq2_out"
OUT="E:/科研/想法idea/rag-chatafl/derived/analysis/qa_rq1_2/raw"
mkdir -p "$OUT"

for group in seed_reuse protorag; do
  for fuzzer in chatafl aflnet; do
    for rep in 1 2 3 4 5; do
      d="${BASE}/${group}_${fuzzer}/r${rep}"
      tag="${group}_${fuzzer}_r${rep}"
      $SSH "sudo -n cat ${d}/plot_data" > "${OUT}/${tag}.plot_data" 2>"${OUT}/${tag}.plot_data.err"
      $SSH "sudo -n cat ${d}/fuzzer_stats" > "${OUT}/${tag}.fuzzer_stats" 2>"${OUT}/${tag}.fuzzer_stats.err"
      echo "pulled $tag  plot_lines=$(wc -l < "${OUT}/${tag}.plot_data")  stats_lines=$(wc -l < "${OUT}/${tag}.fuzzer_stats")"
    done
  done
done
echo "PULL_DONE"
