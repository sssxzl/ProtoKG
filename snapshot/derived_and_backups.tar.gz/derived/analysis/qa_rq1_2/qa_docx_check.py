#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA: docx 表4 回填验收 (只读)。"""
from __future__ import annotations

import os
import sys

import docx

DOCX = r"E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx"
CSV_SUMMARY = r"E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2/rq1_2_summary.csv"

EXPECTED_HEADER = [
    "种子来源", "Fuzzer选择", "n_states(P1)", "n_states(P2)", "n_edges(P1)",
    "n_edges(P2)", "分支覆盖%(P2)", "崩溃数(P2)", "路径数(P2)",
]


def cell_text(cell):
    return " ".join(p.text.strip() for p in cell.paragraphs if p.text.strip()).strip()


def main():
    d = docx.Document(DOCX)
    tables = d.tables
    print(f"文档 tables 总数 = {len(tables)}  (期望 22)  "
          f"{'OK' if len(tables) == 22 else '★FAIL★'}")

    # 定位 Live555 表: 表前段落含「Live555」
    target_idx = None
    for i, t in enumerate(tables):
        # 找该表前最近的非空段落
        # python-docx 没有直接的 body 顺序, 用 XML 迭代
        pass

    # 用 body 顺序遍历, 找表格前最近的段落文本
    from docx.oxml.ns import qn
    body = d.element.body
    prev_paras = []
    table_seq = []
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            texts = "".join(n.text or "" for n in child.iter(qn("w:t")))
            prev_paras.append(texts.strip())
            prev_paras = prev_paras[-6:]
        elif child.tag == qn("w:tbl"):
            table_seq.append((child, list(prev_paras)))

    print(f"按文档流共遇到 {len(table_seq)} 个表格\n")
    live_idx = None
    for i, (xml, paras) in enumerate(table_seq):
        ctx = " / ".join([p for p in paras if p][-3:])
        marker = "  <<< Live555 候选" if "Live555" in ctx else ""
        print(f"  tables[{i}]  上下文: {ctx[:110]}{marker}")
        if "Live555" in ctx and live_idx is None:
            live_idx = i

    if live_idx is None:
        print("\n★ 未找到 Live555 表")
        return 1

    print(f"\n==> Live555 表 = tables[{live_idx}]")
    t = tables[live_idx]
    print(f"    尺寸: {len(t.rows)} 行 x {len(t.columns)} 列 "
          f"(期望 5 x 9)  {'OK' if (len(t.rows), len(t.columns)) == (5, 9) else '★FAIL★'}")

    grid = []
    for r in t.rows:
        grid.append([cell_text(c) for c in r.cells])

    print("\n--- 表4 完整内容 ---")
    for i, row in enumerate(grid):
        tag = "表头" if i == 0 else f"数据行{i}"
        print(f"  [{i}] ({tag}): {row}")

    print("\n--- 表头逐格核对 ---")
    hdr_ok = True
    for j, exp in enumerate(EXPECTED_HEADER):
        got = grid[0][j] if j < len(grid[0]) else "<缺列>"
        ok = exp in got
        hdr_ok &= ok
        print(f"  col{j}: 期望含 '{exp}'  实际 '{got}'  {'OK' if ok else '★FAIL★'}")
    print(f"  表头 9 格全部未变: {hdr_ok}")

    # summary.csv
    import csv
    with open(CSV_SUMMARY, "r", encoding="utf-8-sig", newline="") as fh:
        srows = list(csv.DictReader(fh))
    print("\n--- 数据行 col3..col9 vs summary.csv 逐格核对 ---")
    all_ok = True
    for k, sr in enumerate(srows):
        drow = int(sr["docx_row"])
        row_idx = k + 1
        if row_idx >= len(grid):
            print(f"  行 {row_idx}: 缺失")
            all_ok = False
            continue
        got = grid[row_idx]
        checks = [
            ("col1 seed_source", sr["seed_source"], got[0]),
            ("col2 fuzzer", sr["fuzzer"], got[1]),
            ("col3 n_states_P1", sr["n_states_P1"], got[2]),
            ("col4 n_states_P2", sr["n_states_P2"], got[3]),
            ("col5 n_edges_P1", sr["n_edges_P1"], got[4]),
            ("col6 n_edges_P2", sr["n_edges_P2"], got[5]),
            ("col7 bitmap_cvg_P2", sr["bitmap_cvg_P2"], got[6]),
            ("col8 unique_crashes_P2", sr["unique_crashes_P2"], got[7]),
            ("col9 paths_total_P2", sr["paths_total_P2"], got[8]),
        ]
        print(f"  数据行{row_idx} (docx_row={drow}, {sr['seed_source']} / {sr['fuzzer']}):")
        for name, exp, act in checks:
            # 数值规范化比较
            def norm(x):
                return x.replace(" ", "").replace("　", "")

            e, a = norm(exp), norm(act)
            if e == a:
                mark = "OK"
            else:
                try:
                    ef = float(exp.rstrip("%"))
                    af = float(act.rstrip("%"))
                    mark = "OK(数值等)" if abs(ef - af) < 1e-9 else "★FAIL★"
                except ValueError:
                    mark = "★FAIL★"
            if mark.startswith("★"):
                all_ok = False
            print(f"      {name:<22} csv='{exp}'  docx='{act}'  {mark}")

    print(f"\n  col1..col9 全部一致: {all_ok}")

    print("\n--- 其它表误改检查 ---")
    for i in range(len(tables)):
        if i == live_idx:
            continue
        tt = tables[i]
        cells = [[cell_text(c) for c in r.cells] for r in tt.rows]
        nonempty = [
            (ri, ci, v)
            for ri, row in enumerate(cells)
            for ci, v in enumerate(row)
            if v.strip()
        ]
        # 表头行不算数据
        hdr_cells = len(cells[0]) if cells else 0
        data_nonempty = [x for x in nonempty if not (x[0] == 0)]
        tag = ""
        if i in (5, 6, 7):
            tag = " (BFTPD/Exim/Kamailio 同结构表) 应全空"
        print(f"  tables[{i}]: {len(tt.rows)}行x{len(tt.columns)}列  "
              f"非空单元格={len(nonempty)}  表头后非空={len(data_nonempty)}{tag}")
        if i in (5, 6, 7) and data_nonempty:
            print(f"      ★ 数据区存在非空内容: {data_nonempty[:12]}")
        if i >= 8 and data_nonempty:
            print(f"      ★ 数据区存在非空内容: {data_nonempty[:12]}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
