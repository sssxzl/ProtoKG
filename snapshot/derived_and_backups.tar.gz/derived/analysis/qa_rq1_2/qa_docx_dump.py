#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA: docx 表格结构全量清点 (只读) —— 定位 Live555 表并核对回填。"""
from __future__ import annotations

import csv
import sys

import docx
from docx.oxml.ns import qn

DOCX = r"E:/科研/想法idea/rag-chatafl/local/实验方案_详细版.docx"
CSV_SUMMARY = r"E:/科研/想法idea/rag-chatafl/derived/analysis/data/rq1_2/rq1_2_summary.csv"

EXPECTED_HEADER = [
    "种子来源", "Fuzzer选择", "n_states(P1)", "n_states(P2)", "n_edges(P1)",
    "n_edges(P2)", "分支覆盖%(P2)", "崩溃数(P2)", "路径数(P2)",
]


def cell_text(cell):
    return " ".join(p.text.strip() for p in cell.paragraphs if p.text.strip()).strip()


def norm(s):
    """归一化: 去掉所有空白 (含换行/全角空格), 便于比对。"""
    return "".join((s or "").split()).replace("　", "")


def main():
    d = docx.Document(DOCX)
    tables = d.tables
    print(f"tables 总数 = {len(tables)} (期望 22) -> "
          f"{'OK' if len(tables) == 22 else '★FAIL★'}\n")

    # 逐表打印尺寸 + 表头首格
    print("--- 全量表结构 ---")
    for i, t in enumerate(tables):
        rows = len(t.rows)
        cols = len(t.columns)
        hdr = [cell_text(c) for c in t.rows[0].cells] if rows else []
        print(f"  tables[{i:>2}]  {rows}行 x {cols}列  表头={hdr}")

    # 文档流中每个表格紧邻的前置段落
    body = d.element.body
    seq = []
    last_paras = []
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            txt = "".join(n.text or "" for n in child.iter(qn("w:t"))).strip()
            if txt:
                last_paras.append(txt)
                last_paras = last_paras[-4:]
        elif child.tag == qn("w:tbl"):
            seq.append(list(last_paras))

    print("\n--- 每个表格的直接前置段落 (最后 2 个非空) ---")
    for i, paras in enumerate(seq):
        print(f"  tables[{i:>2}] <- {paras[-2:] if paras else []}")

    # 定位 Live555: 9 列 且 表头含 'n_states(P1)'
    target = None
    for i, t in enumerate(tables):
        if len(t.columns) == 9:
            hdr = norm(" ".join(cell_text(c) for c in t.rows[0].cells))
            if "n_states(P1)" in hdr and "分支覆盖" in hdr:
                target = i
                break

    print()
    if target is None:
        print("★ 未定位到 Live555 表 (9 列 + n_states(P1) 表头)")
        return 1

    print(f"==> Live555 表 = tables[{target}]")
    t = tables[target]
    print(f"    {len(t.rows)} 行 x {len(t.columns)} 列  "
          f"{'OK' if (len(t.rows), len(t.columns)) == (5, 9) else '★FAIL★'}")

    grid = [[cell_text(c) for c in r.cells] for r in t.rows]
    print("\n--- 表4 完整内容 ---")
    for i, row in enumerate(grid):
        print(f"  [{i}]: {row}")

    print("\n--- 表头逐格核对 (空白归一化后) ---")
    hdr_ok = True
    for j, exp in enumerate(EXPECTED_HEADER):
        got = grid[0][j] if j < len(grid[0]) else "<缺列>"
        ok = exp in norm(got)
        hdr_ok &= ok
        print(f"  col{j}: 期望含 '{exp}'  实际 '{got}'  {'OK' if ok else '★FAIL★'}")
    print(f"  表头 9 格全部未变: {hdr_ok}")

    with open(CSV_SUMMARY, "r", encoding="utf-8-sig", newline="") as fh:
        srows = list(csv.DictReader(fh))

    print("\n--- 数据行 col1..col9 vs summary.csv 逐格核对 ---")
    all_ok = True
    for k, sr in enumerate(srows):
        ri = k + 1
        got = grid[ri] if ri < len(grid) else []
        print(f"  数据行{ri} (docx_row={sr['docx_row']}, {sr['seed_source']} / {sr['fuzzer']}):")
        checks = [
            ("col1 seed_source", sr["seed_source"], got[0] if len(got) > 0 else ""),
            ("col2 fuzzer", sr["fuzzer"], got[1] if len(got) > 1 else ""),
            ("col3 n_states_P1", sr["n_states_P1"], got[2] if len(got) > 2 else ""),
            ("col4 n_states_P2", sr["n_states_P2"], got[3] if len(got) > 3 else ""),
            ("col5 n_edges_P1", sr["n_edges_P1"], got[4] if len(got) > 4 else ""),
            ("col6 n_edges_P2", sr["n_edges_P2"], got[5] if len(got) > 5 else ""),
            ("col7 bitmap_cvg_P2", sr["bitmap_cvg_P2"], got[6] if len(got) > 6 else ""),
            ("col8 unique_crashes_P2", sr["unique_crashes_P2"], got[7] if len(got) > 7 else ""),
            ("col9 paths_total_P2", sr["paths_total_P2"], got[8] if len(got) > 8 else ""),
        ]
        for name, exp, act in checks:
            e = exp.replace(" ", "").replace("　", "")
            a = act.replace(" ", "").replace("　", "")
            if e == a:
                mark = "OK"
            else:
                try:
                    mark = "OK(数值等)" if abs(float(exp.rstrip("%")) -
                                             float(act.rstrip("%"))) < 1e-9 else "★FAIL★"
                except ValueError:
                    mark = "★FAIL★"
            if mark.startswith("★"):
                all_ok = False
            print(f"      {name:<22} csv='{exp}'  docx='{act}'  {mark}")
    print(f"\n  col1..col9 全部一致: {all_ok}")

    print("\n--- 其它表误改检查 (表头行以外是否有数据) ---")
    for i, tt in enumerate(tables):
        if i == target:
            continue
        cells = [[cell_text(c) for c in r.cells] for r in tt.rows]
        data_ne = [(ri, ci, v) for ri, row in enumerate(cells)
                   for ci, v in enumerate(row) if ri > 0 and v.strip()]
        tag = ""
        if i in (5, 6, 7):
            tag = "  <- BFTPD/Exim/Kamailio 同结构表，应全空"
        print(f"  tables[{i:>2}]: {len(tt.rows)}行x{len(tt.columns)}列  "
              f"表头后非空单元格={len(data_ne)}{tag}")
        if data_ne:
            print(f"      ★ 非空: {data_ne[:14]}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
