#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""QA: P1 语义验证 —— plot_data 首行 paths_total 是否等于初始种子数。"""
from __future__ import annotations

import os

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "raw")
CSV_DIR = os.path.join(os.path.dirname(HERE), "data", "rq1_2")


def parse_plot(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) <= 12:
                continue
            rows.append(p)
    return rows


def parse_stats(path):
    out = {}
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if ":" in line:
                k, _, v = line.partition(":")
                out[k.strip()] = v.strip()
    return out


import csv
prov = {}
with open(os.path.join(CSV_DIR, "rq1_2_extra_seedprovenance.csv"), "r",
          encoding="utf-8-sig", newline="") as fh:
    for row in csv.DictReader(fh):
        prov[(row["group"], row["fuzzer"], int(row["rep"]))] = row

lin = {}
with open(os.path.join(CSV_DIR, "rq1_2_extra_lineage.csv"), "r",
          encoding="utf-8-sig", newline="") as fh:
    for row in csv.DictReader(fh):
        lin[(row["group"], row["fuzzer"], int(row["rep"]))] = row

print("=" * 96)
print("P1 语义验证: plot_data 首行 paths_total vs 种子来源清单 orig_seeds")
print("=" * 96)
print(f"{'container':<28}{'P1_paths':>10}{'orig_seeds':>12}{'match':>8}"
      f"{'P1_cvg':>9}{'P1_n_s':>8}{'P1_n_e':>8}")
ok_all = True
for g in ("seed_reuse", "protorag"):
    for f in ("chatafl", "aflnet"):
        for r in (1, 2, 3, 4, 5):
            tag = f"{g}_{f}_r{r}"
            rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
            fs = parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats"))
            first = rows[0]
            p1_paths = int(float(first[3]))
            orig = int(prov[(g, f, r)]["orig_seeds"])
            m = p1_paths == orig
            ok_all &= m
            print(f"{tag:<28}{p1_paths:>10}{orig:>12}{'OK' if m else '★DIFF':>8}"
                  f"{first[6]:>9}{first[11]:>8}{first[12]:>8}")
print(f"\n  首行 paths_total == 初始种子数 (20/20): {ok_all}")
print("  => 确认 P1 采样点 = plot_data 首行 (初始种子执行完/dry-run 结束时刻)")

print()
print("=" * 96)
print("P2 语义验证: plot_data 末行 == fuzzer_stats 终态 (paths/crashes/hangs/cvg)")
print("=" * 96)
print(f"{'container':<28}{'paths_pd':>10}{'paths_fs':>10}{'crash_pd':>10}{'crash_fs':>10}"
      f"{'hang_pd':>9}{'hang_fs':>9}{'cvg_pd':>9}{'cvg_fs':>9}{'dur_h':>8}")
for g in ("seed_reuse", "protorag"):
    for f in ("chatafl", "aflnet"):
        for r in (1, 2, 3, 4, 5):
            tag = f"{g}_{f}_r{r}"
            rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
            fs = parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats"))
            last = rows[-1]
            dur = (int(float(last[0])) - int(float(rows[0][0]))) / 3600.0
            print(f"{tag:<28}"
                  f"{int(float(last[3])):>10}{int(fs['paths_total']):>10}"
                  f"{int(float(last[7])):>10}{int(fs['unique_crashes']):>10}"
                  f"{int(float(last[8])):>9}{int(fs['unique_hangs']):>9}"
                  f"{last[6]:>9}{fs['bitmap_cvg']:>9}{dur:>8.2f}")

print()
print("=" * 96)
print("execs_done 口径验证: fuzzer_stats.execs_done vs plot_data 末行 cycles_done")
print("=" * 96)
print("  (plot_data 第 0 列是 unix_time, 不是 execs; execs 只能来自 fuzzer_stats)")
for g in ("seed_reuse", "protorag"):
    for f in ("chatafl", "aflnet"):
        for r in (1, 2, 3, 4, 5):
            tag = f"{g}_{f}_r{r}"
            rows = parse_plot(os.path.join(RAW, f"{tag}.plot_data"))
            fs = parse_stats(os.path.join(RAW, f"{tag}.fuzzer_stats"))
            print(f"    {tag:<28} execs_done={int(fs['execs_done']):>9}  "
                  f"cycles_done={fs['cycles_done']:>6}  "
                  f"execs_per_sec={fs['execs_per_sec']:>7}  "
                  f"(若误用 col0 当 execs, 首行 unix_time={rows[0][0]} 明显不符)")
