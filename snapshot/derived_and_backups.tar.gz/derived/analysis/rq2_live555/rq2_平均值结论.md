# Live555 RQ2 种子有效性实验 — P2 采样平均值结论（24h）

生成时间：2026-10-22（P2 采样，24h 结束后）

## 平均数据（4 组 × 5 重复，跳过 NA / no_*）

| 组 | n_states(P1) | n_states(P2) | n_edges(P1) | n_edges(P2) | 分支覆盖%(P2) | 崩溃数(P2) | 路径数(P2) |
|---|---|---|---|---|---|---|---|
| Seed Reuse × Chatafl | 12 | 14 | 51 | 134 | 10.10% | 2 | 1460 |
| Seed Reuse × aflnet | 9 | 13 | 35 | 107 | 9.96% | 15 | 1674 |
| ProtoRAG × Chatafl | 8 | 11 | 52 | 77 | 10.35% | 7 | 1893 |
| ProtoRAG × aflnet | 8 | 10 | 30 | 75 | 10.26% | 10 | 1288 |

注：AFLNet 原始种子（in-rtsp）与 Seed Reuse 视为同一批，共用 seed_reuse 数据。

## 结论（ProtoRAG 组 vs Seed Reuse 组）

**Chatafl fuzzer 下：**
- n_states：ProtoRAG 8 → 11（P1→P2 增 3）vs Seed Reuse 12 → 14（增 2）；P1 时 ProtoRAG 状态数略少，P2 收敛后仍略少。
- n_edges：ProtoRAG 52 → 77 vs Seed Reuse 51 → 134。P1 相当（52 vs 51），但 P2 状态机边数 Seed Reuse 显著更多（134 vs 77）。
- 分支覆盖%：ProtoRAG 10.35% **略高于** Seed Reuse 10.10%。
- 崩溃数：ProtoRAG 7 vs Seed Reuse 2，ProtoRAG 崩溃更多（但 Seed Reuse aflnet 达 15）。
- 路径数：ProtoRAG 1893 **高于** Seed Reuse 1460。

**aflnet fuzzer 下：**
- n_states：ProtoRAG 8 → 10 vs Seed Reuse 9 → 13。
- n_edges：ProtoRAG 30 → 75 vs Seed Reuse 35 → 107。
- 分支覆盖%：ProtoRAG 10.26% **高于** Seed Reuse 9.96%。
- 崩溃数：ProtoRAG 10 vs Seed Reuse 15，Seed Reuse 略多。
- 路径数：ProtoRAG 1288 低于 Seed Reuse 1674。

**总体：**
1. **分支覆盖率**：ProtoRAG 组在两个 fuzzer 下均略高于 Seed Reuse 组（Chatafl +0.25pct，aflnet +0.30pct）。
2. **状态机规模（n_states/n_edges）**：P2 时 Seed Reuse 组普遍更高（n_edges 134/107 vs 77/75），ProtoRAG 生成的状态机更精简。
3. **路径数**：Chatafl 下 ProtoRAG 更高（1893 vs 1460）；aflnet 下 Seed Reuse 更高（1674 vs 1288）。
4. **崩溃数**：两组互有高低，差异不稳定（ProtoRAG 7~10 vs Seed Reuse 2~15），崩溃多为概率性 UAF，单次采样波动大，不宜据此下强结论。
