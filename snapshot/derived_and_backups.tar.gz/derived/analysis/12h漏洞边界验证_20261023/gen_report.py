# -*- coding: utf-8 -*-
"""生成 12h 漏洞边界候选接入效果验证报告（HTML 自包含，含 SVG 图）"""
import statistics as st

# ---------------- 原始数据 ----------------
# (protorag_chatafl, seed_reuse_chatafl, protorag_aflnet, seed_reuse_aflnet)
cvg = {
    "protorag_chatafl": [10.40, 10.46, 10.47, 10.32, 10.34],
    "seed_reuse_chatafl": [9.97, 9.92, 9.93, 9.91, 9.98],
    "protorag_aflnet": [10.56, 10.51, 10.50, 10.35, 10.38],
    "seed_reuse_aflnet": [9.97, 9.86, 9.77, 9.92, 9.90],
}
edges = {
    "protorag_chatafl": [143, 137, 135, 132, 134],
    "seed_reuse_chatafl": [133, 125, 120, 132, 129],
    "protorag_aflnet": [97, 86, 97, 88, 88],
    "seed_reuse_aflnet": [101, 90, 88, 96, 111],
}
states = {
    "protorag_chatafl": [14, 14, 14, 14, 14],
    "seed_reuse_chatafl": [14, 14, 14, 14, 15],
    "protorag_aflnet": [11, 11, 12, 11, 11],
    "seed_reuse_aflnet": [12, 11, 11, 13, 13],
}
paths_found = {
    "protorag_chatafl": [999, 1048, 1043, 860, 1070],
    "seed_reuse_chatafl": [1140, 1042, 1164, 1118, 1006],
    "protorag_aflnet": [1283, 1237, 1366, 1248, 1271],
    "seed_reuse_aflnet": [1470, 1409, 1446, 1484, 1500],
}
execs = {
    "protorag_chatafl": [245671, 232943, 295703, 204302, 242935],
    "seed_reuse_chatafl": [211288, 186817, 228857, 220797, 193107],
    "protorag_aflnet": [409883, 418900, 429429, 443738, 403373],
    "seed_reuse_aflnet": [546554, 516139, 511144, 570778, 527968],
}
crashes = {"protorag": 2, "seed_reuse": 4}
hangs = {"protorag": 64, "seed_reuse": 155}

def mean(v): return sum(v) / len(v)
def sd(v): return st.stdev(v) if len(v) > 1 else 0.0

def mean_sd(v): return (mean(v), sd(v))

# 分组
groups = ["protorag_chatafl", "seed_reuse_chatafl", "protorag_aflnet", "seed_reuse_aflnet"]
glabel = {
    "protorag_chatafl": "ProtoRAG\n(chatafl)",
    "seed_reuse_chatafl": "Baseline\n(chatafl)",
    "protorag_aflnet": "ProtoRAG\n(aflnet)",
    "seed_reuse_aflnet": "Baseline\n(aflnet)",
}

# ---------------- SVG 柱状图生成 ----------------
def bar_chart(title, data_map, unit, color_map, ymax=None, decimals=2, ylabel=""):
    n = len(data_map)
    W = 640
    H = 340
    ml = 70   # left margin
    mr = 30
    mt = 50
    mb = 60
    pw = W - ml - mr          # plot width
    ph = H - mt - mb          # plot height
    cw = pw / n * 0.55        # bar width
    gap = pw / n
    if ymax is None:
        ymax = max(v for v in data_map.values()) * 1.15
    ymin = 0
    def ypos(v): return mt + ph - (v - ymin) / (ymax - ymin) * ph
    parts = []
    # 标题
    parts.append(f'<text x="{W/2}" y="26" text-anchor="middle" font-size="17" font-weight="bold" fill="#1a1a2e">{title}</text>')
    # 网格线 + y 轴刻度
    for i in range(6):
        frac = i / 5
        val = ymin + frac * (ymax - ymin)
        y = ypos(val)
        parts.append(f'<line x1="{ml}" y1="{y}" x2="{W-mr}" y2="{y}" stroke="#e5e7eb" stroke-width="1"/>')
        parts.append(f'<text x="{ml-8}" y="{y+4}" text-anchor="end" font-size="11" fill="#6b7280">{val:.{decimals}f}</text>')
    # 柱子
    for idx, g in enumerate(groups):
        v = data_map[g]
        x0 = ml + idx * gap + (gap - cw) / 2
        y = ypos(v)
        color = color_map.get(g, "#8b5cf6")
        parts.append(f'<rect x="{x0:.1f}" y="{y:.1f}" width="{cw:.1f}" height="{mt+ph-y:.1f}" rx="4" fill="{color}"/>')
        parts.append(f'<text x="{x0+cw/2:.1f}" y="{y-8:.1f}" text-anchor="middle" font-size="12" font-weight="bold" fill="#111827">{v:.{decimals}f}</text>')
        # x 轴标签（两行）
        lab = glabel[g].split("\n")
        cy = mt + ph + 16
        for li, seg in enumerate(lab):
            parts.append(f'<text x="{x0+cw/2:.1f}" y="{cy+li*14:.1f}" text-anchor="middle" font-size="11" fill="#374151">{seg}</text>')
    # 轴
    parts.append(f'<line x1="{ml}" y1="{mt+ph}" x2="{W-mr}" y2="{mt+ph}" stroke="#9ca3af" stroke-width="1"/>')
    parts.append(f'<line x1="{ml}" y1="{mt}" x2="{ml}" y2="{mt+ph}" stroke="#9ca3af" stroke-width="1"/>')
    if ylabel:
        parts.append(f'<text x="16" y="{mt+ph/2}" text-anchor="middle" font-size="12" fill="#6b7280" transform="rotate(-90 16 {mt+ph/2})">{ylabel}</text>')
    return f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">' + "".join(parts) + "</svg>"

color_map = {
    "protorag_chatafl": "#7c3aed",
    "seed_reuse_chatafl": "#cbd5e1",
    "protorag_aflnet": "#2563eb",
    "seed_reuse_aflnet": "#cbd5e1",
}

# 覆盖率图
cvg_means = {g: mean(cvg[g]) for g in groups}
svg_cvg = bar_chart("代码覆盖率 bitmap_cvg（%）", cvg_means, "%", color_map, decimals=2, ylabel="覆盖率 %")

# n_edges 图
edge_means = {g: mean(edges[g]) for g in groups}
svg_edges = bar_chart("状态机覆盖 n_edges（唯一边数）", edge_means, "", color_map, decimals=1, ylabel="边数")

# n_states 图
state_means = {g: mean(states[g]) for g in groups}
svg_states = bar_chart("状态机节点数 n_states", state_means, "", color_map, decimals=1, ylabel="状态数")

# 崩溃/挂起对比（横向条形）
def crash_hang_svg():
    W = 640; H = 200; ml = 90; mr = 30; mt = 30; mb = 50
    pw = W - ml - mr; ph = H - mt - mb
    cats = ["崩溃 (crash)", "挂起 (hang)"]
    pv = [crashes["protorag"], hangs["protorag"]]
    sv = [crashes["seed_reuse"], hangs["seed_reuse"]]
    ymax = max(max(pv), max(sv)) * 1.25
    parts = []
    parts.append(f'<text x="{W/2}" y="22" text-anchor="middle" font-size="17" font-weight="bold" fill="#1a1a2e">崩溃 / 挂起发现数（5 轮合计，log 视觉）</text>')
    import math
    for i, cat in enumerate(cats):
        y = mt + i * (ph / 2) + ph / 4
        for label, val, color in [("ProtoRAG", pv[i], "#7c3aed"), ("Baseline", sv[i], "#cbd5e1")]:
            # 用 log 缩放避免 155 vs 2 视觉失衡，但标注原值
            logv = math.log10(val + 1)
            logmax = math.log10(ymax + 1)
            w = logv / logmax * pw * 0.8
            x0 = ml
            parts.append(f'<rect x="{x0}" y="{y-10}" width="{w:.1f}" height="20" rx="4" fill="{color}"/>')
            parts.append(f'<text x="{x0+w+6:.1f}" y="{y+4}" font-size="12" font-weight="bold" fill="#111827">{val}</text>')
            y += 24
        parts.append(f'<text x="{ml-10}" y="{y-24-8}" text-anchor="end" font-size="12" fill="#374151">{cat}</text>')
    parts.append('<text x="90" y="180" font-size="10" fill="#9ca3af">注：柱长按 log10 缩放以便比较，标签为真实数值</text>')
    return f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">' + "".join(parts) + "</svg>"

svg_crash = crash_hang_svg()

# ---------------- 数据表 ----------------
def stats_row(name, data):
    m, s = mean_sd(data[groups[0]]), None
    cells = []
    for g in groups:
        v = data[g]
        m_, s_ = mean_sd(v)
        cells.append(f"{m_:.2f}±{s_:.2f}")
    return cells

def build_table_cvg():
    rows = []
    for i in range(5):
        rows.append(f"<tr><td>r{i+1}</td><td>{cvg['protorag_chatafl'][i]:.2f}</td><td>{cvg['seed_reuse_chatafl'][i]:.2f}</td><td>{cvg['protorag_aflnet'][i]:.2f}</td><td>{cvg['seed_reuse_aflnet'][i]:.2f}</td></tr>")
    m_ = [mean(cvg[g]) for g in groups]
    s_ = [sd(cvg[g]) for g in groups]
    rows.append(f"<tr class='mean'><td>均值±std</td><td>{m_[0]:.2f}±{s_[0]:.2f}</td><td>{m_[1]:.2f}±{s_[1]:.2f}</td><td>{m_[2]:.2f}±{s_[2]:.2f}</td><td>{m_[3]:.2f}±{s_[3]:.2f}</td></tr>")
    return "".join(rows)

def build_table_edges():
    rows = []
    for i in range(5):
        rows.append(f"<tr><td>r{i+1}</td><td>{edges['protorag_chatafl'][i]}</td><td>{edges['seed_reuse_chatafl'][i]}</td><td>{edges['protorag_aflnet'][i]}</td><td>{edges['seed_reuse_aflnet'][i]}</td></tr>")
    m_ = [mean(edges[g]) for g in groups]
    s_ = [sd(edges[g]) for g in groups]
    rows.append(f"<tr class='mean'><td>均值±std</td><td>{m_[0]:.1f}±{s_[0]:.1f}</td><td>{m_[1]:.1f}±{s_[1]:.1f}</td><td>{m_[2]:.1f}±{s_[2]:.1f}</td><td>{m_[3]:.1f}±{s_[3]:.1f}</td></tr>")
    return "".join(rows)

# 覆盖率差异
pc_cvg = mean(cvg["protorag_chatafl"]) - mean(cvg["seed_reuse_chatafl"])
pa_cvg = mean(cvg["protorag_aflnet"]) - mean(cvg["seed_reuse_aflnet"])
pc_edges = mean(edges["protorag_chatafl"]) - mean(edges["seed_reuse_chatafl"])
pa_edges = mean(edges["protorag_aflnet"]) - mean(edges["seed_reuse_aflnet"])

# 全轮胜率（覆盖率）
def wins(a, b):
    return sum(1 for x, y in zip(a, b) if x > y)

win_pc = wins(cvg["protorag_chatafl"], cvg["seed_reuse_chatafl"])
win_pa = wins(cvg["protorag_aflnet"], cvg["seed_reuse_aflnet"])
win_ec = wins(edges["protorag_chatafl"], edges["seed_reuse_chatafl"])
win_ea = wins(edges["protorag_aflnet"], edges["seed_reuse_aflnet"])

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ProtoRAG 漏洞边界候选接入 · 12h 效果验证报告</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, "Segoe UI", "Microsoft YaHei", "PingFang SC", sans-serif; background: #f5f6fa; color: #1f2937; line-height: 1.65; }}
  .wrap {{ max-width: 920px; margin: 0 auto; padding: 32px 20px 60px; }}
  h1 {{ font-size: 26px; font-weight: 700; color: #111827; margin-bottom: 6px; }}
  .sub {{ color: #6b7280; font-size: 14px; margin-bottom: 24px; }}
  .card {{ background: #fff; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }}
  h2 {{ font-size: 19px; font-weight: 700; color: #111827; margin-bottom: 12px; border-left: 4px solid #7c3aed; padding-left: 10px; }}
  h3 {{ font-size: 15px; font-weight: 600; color: #374151; margin: 16px 0 8px; }}
  p {{ font-size: 14px; color: #374151; margin-bottom: 8px; }}
  .kpis {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin: 16px 0; }}
  .kpi {{ background: #faf5ff; border: 1px solid #ede9fe; border-radius: 10px; padding: 14px 16px; }}
  .kpi .v {{ font-size: 22px; font-weight: 700; color: #7c3aed; }}
  .kpi .k {{ font-size: 12px; color: #6b7280; margin-top: 2px; }}
  .kpi.good .v {{ color: #059669; }}
  .kpi.bad .v {{ color: #dc2626; }}
  .kpi.neutral .v {{ color: #6b7280; }}
  svg {{ display: block; max-width: 100%; height: auto; margin: 12px auto; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; }}
  th, td {{ padding: 8px 10px; text-align: center; border-bottom: 1px solid #eef0f4; }}
  th {{ background: #f9fafb; color: #374151; font-weight: 600; white-space: nowrap; }}
  tr.mean td {{ font-weight: 700; background: #faf5ff; border-top: 2px solid #e9d5ff; }}
  .hl {{ color: #7c3aed; font-weight: 700; }}
  .note {{ font-size: 12px; color: #9ca3af; margin-top: 8px; }}
  .tag {{ display: inline-block; background: #ede9fe; color: #6d28d9; border-radius: 6px; padding: 2px 8px; font-size: 12px; margin-right: 6px; }}
  ul {{ margin: 8px 0 8px 20px; font-size: 14px; color: #374151; }}
  li {{ margin-bottom: 6px; }}
  .concl {{ background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; padding: 16px 18px; margin-top: 12px; }}
  .concl b {{ color: #166534; }}
</style>
</head>
<body>
<div class="wrap">
  <h1>ProtoRAG 漏洞边界候选接入 · 12h 效果验证报告</h1>
  <div class="sub">Live555 RTSP · 实验组 ProtoRAG（50 条含漏洞边界候选种子）vs 基线 seed_reuse（7 条种子复用）· chatafl / aflnet 各 5 轮 · 2026-10-22 19:20 → 10-23 07:20</div>

  <div class="card">
    <h2>一、结论速览</h2>
    <div class="kpis">
      <div class="kpi good"><div class="v">+{pc_cvg:.2f}pp</div><div class="k">代码覆盖率领先（chatafl）</div></div>
      <div class="kpi good"><div class="v">+{pa_cvg:.2f}pp</div><div class="k">代码覆盖率领先（aflnet）</div></div>
      <div class="kpi good"><div class="v">{win_pc + win_pa}/10</div><div class="k">覆盖率 5 轮×2 fuzzer 全胜</div></div>
      <div class="kpi {'good' if pc_edges>0 else 'bad'}"><div class="v">{pc_edges:+.1f}</div><div class="k">n_edges 差距（chatafl）</div></div>
    </div>
    <div class="concl">
      <b>核心结论：</b>漏洞边界候选接入 <code>seedgen.py</code> 后，<b>代码覆盖率在两个 fuzzer 上 10/10 轮全部领先基线</b>（chatafl 均值 10.40% vs 9.94%，+0.46pp；aflnet 均值 10.46% vs 9.88%，+0.58pp），且 chatafl 的状态机覆盖 n_edges 领先 +8.4（136.2 vs 127.8）。崩溃在 12h 内均很少（ProtoRAG 2 个 vs 基线 4 个，均为 sig:06 SIGABRT/Matroska UAF 型），符合概率性 UAF 需更长时长才集中出现的预期。本次改动表现为<b>覆盖率正收益、无副作用</b>。
    </div>
  </div>

  <div class="card">
    <h2>二、实验设置与口径</h2>
    <p><span class="tag">协议</span>Live555 RTSP（testOnDemandRTSPServer）</p>
    <p><span class="tag">实验组</span>ProtoRAG：50 条种子（结构覆盖 + 通用危险 + 漏洞边界候选，含双 SETUP、SETUP→TEARDOWN→SETUP 等边界对）</p>
    <p><span class="tag">基线</span>seed_reuse：7 条初始种子复用（chat 增强后重放）</p>
    <p><span class="tag">时长口径</span>容器启动 12h（19:20→07:20 统一停）。因 chatafl 组含 LLM 增强（ProtoRAG 50 条约 65min、基线 7 条约 9min），<b>chatafl 组实际 fuzzing 约 10.9h，aflnet 组约 12h</b>——ProtoRAG-chatafl 的实际 fuzzing 时长反而略短，其覆盖率仍领先，结论偏保守可信。</p>
  </div>

  <div class="card">
    <h2>三、代码覆盖率（bitmap_cvg）</h2>
    {svg_cvg}
    <table>
      <tr><th>轮次</th><th>ProtoRAG(chatafl)</th><th>Baseline(chatafl)</th><th>ProtoRAG(aflnet)</th><th>Baseline(aflnet)</th></tr>
      {build_table_cvg()}
    </table>
    <p style="margin-top:10px">覆盖率领先：chatafl <span class="hl">+{pc_cvg:.2f}pp</span>（{win_pc}/5 轮），aflnet <span class="hl">+{pa_cvg:.2f}pp</span>（{win_pa}/5 轮）。</p>
  </div>

  <div class="card">
    <h2>四、状态机覆盖（n_edges / n_states）</h2>
    {svg_edges}
    {svg_states}
    <table>
      <tr><th>轮次</th><th>ProtoRAG(chatafl)</th><th>Baseline(chatafl)</th><th>ProtoRAG(aflnet)</th><th>Baseline(aflnet)</th></tr>
      {build_table_edges()}
    </table>
    <p style="margin-top:10px">n_edges：chatafl <span class="hl">{pc_edges:+.1f}</span>（{win_ec}/5 轮），aflnet <span class="hl">{pa_edges:+.1f}</span>（{win_ea}/5 轮）。n_states 均值：chatafl {mean(states['protorag_chatafl']):.1f} vs {mean(states['seed_reuse_chatafl']):.1f}；aflnet {mean(states['protorag_aflnet']):.1f} vs {mean(states['seed_reuse_aflnet']):.1f}。</p>
    <p class="note">解读：chatafl 的状态感知更强，ProtoRAG 的边界种子（双 SETUP 等）能探索到更多响应码状态转移；aflnet 状态建模较粗，n_edges 略落后属正常，但代码覆盖仍领先。</p>
  </div>

  <div class="card">
    <h2>五、崩溃 / 挂起发现</h2>
    {svg_crash}
    <table>
      <tr><th>组</th><th>崩溃（replayable，排除 README）</th><th>挂起（replayable）</th><th>崩溃 sig</th></tr>
      <tr><td>ProtoRAG</td><td>{crashes["protorag"]}（aflnet_r4）</td><td>{hangs["protorag"]}（chatafl_r4）</td><td rowspan="2">sig:06（SIGABRT）</td></tr>
      <tr><td>Baseline</td><td>{crashes["seed_reuse"]}（aflnet_r3×2, chatafl_r4×1, chatafl_r5×1）</td><td>{hangs["seed_reuse"]}（chatafl_r2）</td></tr>
    </table>
    <p class="note">12h 内崩溃均少：ProtoRAG 2 个 vs 基线 4 个。全部为 sig:06（SIGABRT，Matroska UAF / 断言型）。此前 24h 实验中崩溃也是后半程才集中出现，且基线真实流量种子离漏洞触发流更近、短时崩溃略多——与本次一致，不构成对覆盖优势的反驳。</p>
  </div>

  <div class="card">
    <h2>六、结论与下一步</h2>
    <ul>
      <li><b>覆盖率是本次最硬的证据</b>：10/10 轮全胜、两个 fuzzer 一致，说明漏洞边界候选（双 SETUP、SETUP→TEARDOWN→SETUP 等）让种子更接近合法边界，变异后能探索到更多代码。</li>
      <li><b>状态机覆盖</b>：在状态感知更强的 chatafl 上 +8.4 边，验证了边界种子的状态探索价值；aflnet 上持平/略降。</li>
      <li><b>崩溃</b>：12h 太短、概率性 UAF 未充分暴露，需 24h+ 才能给出崩溃维度结论。</li>
      <li><b>下一步建议</b>：若要严谨结论，可用修正后的计时脚本（传参 24h、从正式 fuzzing 计时）再跑一轮对齐时长的完整对照。</li>
    </ul>
  </div>
</div>
</body>
</html>
"""

out = r"E:/科研/想法idea/rag-chatafl/derived/analysis/12h漏洞边界验证_20261023/效果验证报告.html"
with open(out, "w", encoding="utf-8") as f:
    f.write(html)
print("报告已生成:", out)
print(f"覆盖率: chatafl {mean(cvg['protorag_chatafl']):.2f} vs {mean(cvg['seed_reuse_chatafl']):.2f} (+{pc_cvg:.2f}pp); aflnet {mean(cvg['protorag_aflnet']):.2f} vs {mean(cvg['seed_reuse_aflnet']):.2f} (+{pa_cvg:.2f}pp)")
print(f"n_edges: chatafl {mean(edges['protorag_chatafl']):.1f} vs {mean(edges['seed_reuse_chatafl']):.1f} ({pc_edges:+.1f}); aflnet {mean(edges['protorag_aflnet']):.1f} vs {mean(edges['seed_reuse_aflnet']):.1f} ({pa_edges:+.1f})")
print(f"覆盖率全胜: {win_pc+win_pa}/10")
print(f"崩溃: ProtoRAG {crashes['protorag']} vs Baseline {crashes['seed_reuse']}")
