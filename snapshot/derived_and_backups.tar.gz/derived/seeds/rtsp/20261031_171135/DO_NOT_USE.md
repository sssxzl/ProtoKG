# ⚠️ 本语料已废弃 —— 不得用于任何实验

**生成时间**：2026-10-31 17:11（ProtoRAG RFC 源改造 A 阶段验证过程中的一次试跑）
**废弃原因**：种子目标主机污染。

## 量化

| 指标 | 值 |
|---|---|
| 种子总数 | 37 |
| 含不可播会话（`isapi`）的种子 | **22（59.5%）** |
| URL 引用 `rtsp://10.11.26.98:554`（IP 摄像机，**非目标主机**） | **93 次** |
| URL 引用 `rtsp://127.0.0.1:8554`（目标主机，正确） | 64 次 |

## 根因

`traffic` 源的事实里混入了**两台不同设备**的抓包，其中一台是非目标的
IP 摄像机（`realm="IP Camera(C1052)"`）：

```
derived/per_source/rtsp/traffic/facts/traffic.jsonl
  aspect=value_enum  subj=(header,url)
    value = ['rtsp://10.11.26.98:554/isapi/streaming/channels/101', ...]
```

`scripts/seedgen.py:273` 的兜底条件是
`if not msg.url or "localhost/seed" in msg.url:` ——
真实抓包 URL **既非空、也不含 `localhost/seed`** → 兜底不命中 → **原样透传**
→ 种子请求行指向摄像机地址 → live555 无此会话 → 404。

## 影响边界

- ❌ **本目录**：59.5% 种子打向错误主机 → **不可用于任何实验**
- ✅ **已发表的 `rq4_B/` 语料不受影响**（39/25/78，`md5sum -c` 全 OK，0 污染、100% 目标主机正确）
- ⚠ **「从仓库重建语料再跑」的复现路径已断** —— 任何现在重生成的 RTSP 语料都有约 46.5% 不可播

## 修复方向（待办，尚未实施）

优先在 **traffic 抽取侧剔除非目标设备**，而不是改 `seedgen.py:273` 的通用兜底
——后者会波及所有协议的真实流量 URL 语义。

并应把「目标主机正确率 / 不可播会话占比」接入 CI 作语料发布准入闸
（现有健康度指标一条都不会红，属于静默退化）。

详见 `docs/rfc_reform_a_implementation_report.md` §10.5。
