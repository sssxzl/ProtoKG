# RQ3 语料一致性断言报告

- 生成时间: 2026-10-31T03:09:52.598999+08:00
- 断言总数: 27
- 通过: 14
- 失败: 13

| 编号 | 断言 | 结果 | 实测 |
|---|---|---|---|
| A1.A | A 组 manifest/语料/期望条数一致 | FAIL | raw=52 manifest=38 expect=38 |
| A1.B | B 组 manifest/语料/期望条数一致 | FAIL | raw=0 manifest=50 expect=50 |
| A1.C | C 组 manifest/语料/期望条数一致 | FAIL | raw=0 manifest=50 expect=50 |
| A1.D | D 组 manifest/语料/期望条数一致 | FAIL | raw=0 manifest=50 expect=50 |
| A2.A | A 组 manifest 的 MD5 与实测一致 | FAIL | 不一致: ['01_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '02_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '03_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '04_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '05_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw'] |
| A2.B | B 组 manifest 的 MD5 与实测一致 | FAIL | 不一致: ['01_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '02_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '03_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '04_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '05_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw'] |
| A2.C | C 组 manifest 的 MD5 与实测一致 | FAIL | 不一致: ['01_DESCRIBE+SETUP.raw', '02_DESCRIBE+SETUP+TEARDOWN.raw', '03_DESCRIBE+SETUP+SETUP.raw', '04_DESCRIBE+SETUP+SETUP.raw', '05_DESCRIBE+SETUP+TEARDOWN+SETUP.raw'] |
| A2.D | D 组 manifest 的 MD5 与实测一致 | FAIL | 不一致: ['01_DESCRIBE+SETUP.raw', '02_DESCRIBE+SETUP+TEARDOWN.raw', '03_DESCRIBE+SETUP+SETUP.raw', '04_DESCRIBE+SETUP+SETUP.raw', '05_DESCRIBE+SETUP+TEARDOWN+SETUP.raw'] |
| A3.A | A 组 manifest 的文件名全部存在 | FAIL | 缺失: ['19_OPTIONS+OPTIONS+OPTIONS+DESCRIBE+SETUP+PLAY+OPTIONS+PLAY+TEARDOWN+OPTIONS.raw', '20_DESCRIBE+DESCRIBE+TEARDOWN.raw', '21_SETUP+GET_PARAMETER+SET_PARAMETER+PLAY+GET_PARAMETER+PAUSE+OPTIONS+PLAY+SET_P....raw', '22_OPTIONS+PLAY+PAUSE+TEARDOWN.raw', '23_OPTIONS+PLAY+PAUSE+GET_PARAMETER+SET_PARAMETER.raw'] |
| A3.B | B 组 manifest 的文件名全部存在 | FAIL | 缺失: ['01_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '02_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '03_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '04_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw', '05_OPTIONS+DESCRIBE+SETUP+PLAY+TEARDOWN.raw'] |
| A3.C | C 组 manifest 的文件名全部存在 | FAIL | 缺失: ['01_DESCRIBE+SETUP.raw', '02_DESCRIBE+SETUP+TEARDOWN.raw', '03_DESCRIBE+SETUP+SETUP.raw', '04_DESCRIBE+SETUP+SETUP.raw', '05_DESCRIBE+SETUP+TEARDOWN+SETUP.raw'] |
| A3.D | D 组 manifest 的文件名全部存在 | FAIL | 缺失: ['01_DESCRIBE+SETUP.raw', '02_DESCRIBE+SETUP+TEARDOWN.raw', '03_DESCRIBE+SETUP+SETUP.raw', '04_DESCRIBE+SETUP+SETUP.raw', '05_DESCRIBE+SETUP+TEARDOWN+SETUP.raw'] |
| A4 | A 的 md5 序列 == B 的前 38 项（自然序限定） | PASS | A=38 B[:38] 匹配 |
| A5 | A 的文件名序列 == B 的前 38 个文件名 | PASS | 完全相同 |
| A6 | B / C / D 的 md5 集合两两相等 | PASS | 各 50/50/50 个 |
| A7 | C 的 md5 集合 == RQ1.2 protorag 语料（50 条） | PASS | ref=50 C=50 |
| A8.A | A 组文件名前 60 字符唯一 | PASS | 最大长度 87 |
| A8.B | B 组文件名前 60 字符唯一 | PASS | 最大长度 87 |
| A8.C | C 组文件名前 60 字符唯一 | PASS | 最大长度 87 |
| A8.D | D 组文件名前 60 字符唯一 | PASS | 最大长度 87 |
| A9.base | 基础字典 24 token 且 MD5 == 镜像内 base24 | PASS | tokens=24 md5=464351f88db6c3f0bdac0de01859316b |
| A9.targeted | 定向字典 123 token | FAIL | tokens=137 |
| A9.superset | 定向字典是基础字典的严格超集 | PASS | base=24 targeted=137 新增=113 |
| A10.A | A 组 md5 组内唯一 | PASS | 38/38 |
| A10.B | B 组 md5 组内唯一 | PASS | 50/50 |
| A10.C | C 组 md5 组内唯一 | PASS | 50/50 |
| A10.D | D 组 md5 组内唯一 | PASS | 50/50 |
