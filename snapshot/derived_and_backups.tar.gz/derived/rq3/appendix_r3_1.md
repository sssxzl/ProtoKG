# 附录 R3-1：D 组（解耦对照）六项指标


## 字典冻结摘要

- `base`：24 token，MD5 `464351f88db6c3f0bdac0de01859316b`
- `protocol`：102 token，MD5 `77d47b7b76139212c86a84ae771c4784`
- `targeted`：123 token，MD5 `c3966773c16bfa798a585dd3f7e39226`
- `targeted-compact`：32 token，MD5 `0ff0118be01ac26fbdfa1263e0a308da`
