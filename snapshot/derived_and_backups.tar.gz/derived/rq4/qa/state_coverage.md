# RQ4 状态覆盖分析（paths_found = AFLNet 状态数）

> 依据：AFLNet 的 `region_t` 即状态抽象（`state_sequence` 为状态反馈序列），
> `regions/` 每个文件对应一个已发现状态，其文件数与 `paths_found` 逐一相等。
> 故 `paths_found` = 终态状态覆盖数，无需新增指标或重跑实验。

## 1. paths_found 与 regions 文件数对照

| 协议 | 组 | paths_found | regions 文件数 | 相等？ |
|---|---|---|---|---|
| rtsp | protorag | 935 | 935 | ✓ |
| rtsp | baseline | 1098 | 1098 | ✓ |
| sip | protorag | 1781 | 1781 | ✓ |
| sip | baseline | 1710 | 1710 | ✓ |
| smtp | protorag | 350 | 350 | ✓ |
| smtp | baseline | 522 | 522 | ✓ |

> 判定：全部相等，paths_found 可作状态覆盖指标。

## 2. 两口径下的组间差值（protorag − baseline）

| 协议 | Δ状态数 | 相对差 | Δ边覆盖(pp) | Δ行覆盖 | 两口径结论是否一致 |
|---|---|---|---|---|---|
| rtsp | -163 | -14.8% | +0.22 | +0.5 | 不一致 |
| sip | +71 | +4.2% | -0.05 | +0.2 | 不一致 |
| smtp | -172 | -33.0% | -1.66 | -8.2 | 一致 |

> **判定：状态覆盖口径下 ProtoRAG 仅在 sip 占优，协议族内未取得一致优势。**
