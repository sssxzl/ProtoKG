# RQ4 实验结果

## RQ4 结果对比（protorag vs baseline）

### rtsp

| 指标 | baseline (n=1) | protorag (n=1) |
|---|---|---|
| bitmap_cvg(%) [主] | 9.72 | 9.94 |
| execs_done | 212619.00 | 142878.00 |
| execs_per_sec | 13.26 | 6.94 |
| paths_total | 1105.00 | 974.00 |
| paths_found | 1098.00 | 935.00 |
| max_depth | 10.00 | 10.00 |
| stability(%) | 10.06 | 6.23 |
| unique_crashes | 0.00 | 0.00 |
| unique_hangs | 0.00 | 0.00 |
| fuzz_sec | 10796.00 | 10796.00 |
| peak_rss_mb | 40.00 | 27.00 |
| seed_files(种子文件数) | 7.00 | 39.00 |
| seed_regions(AFLNet 分区数) | 29.00 | 150.00 |
| dict_tokens(官方字典条目) | 24.00 | 24.00 |
| l_per(%) [次要·行覆盖] | 24.20 | 24.70 |
| b_per(%) [次要·分支覆盖] | 15.40 | 15.70 |
| 参数自检(command_line) | OK | OK |

### sip

| 指标 | baseline (n=1) | protorag (n=1) |
|---|---|---|
| bitmap_cvg(%) [主] | 22.11 | 22.06 |
| execs_done | 60432.00 | 53144.00 |
| execs_per_sec | 5.58 | 4.55 |
| paths_total | 1711.00 | 1806.00 |
| paths_found | 1710.00 | 1781.00 |
| max_depth | 5.00 | 4.00 |
| stability(%) | 21.80 | 23.95 |
| unique_crashes | 0.00 | 0.00 |
| unique_hangs | 0.00 | 0.00 |
| fuzz_sec | 10797.00 | 10796.00 |
| peak_rss_mb | 51.00 | 52.00 |
| seed_files(种子文件数) | 1.00 | 25.00 |
| seed_regions(AFLNet 分区数) | 4.00 | 112.00 |
| dict_tokens(官方字典条目) | 0.00 | 0.00 |
| l_per(%) [次要·行覆盖] | 6.40 | 6.60 |
| b_per(%) [次要·分支覆盖] | 1.50 | 1.60 |
| 参数自检(command_line) | OK | OK |

### smtp

| 指标 | baseline (n=1) | protorag (n=1) |
|---|---|---|
| bitmap_cvg(%) [主] | 11.66 | 10.00 |
| execs_done | 18740.00 | 19153.00 |
| execs_per_sec | 2.31 | 1.91 |
| paths_total | 524.00 | 428.00 |
| paths_found | 522.00 | 350.00 |
| max_depth | 3.00 | 3.00 |
| stability(%) | 37.55 | 36.69 |
| unique_crashes | 0.00 | 0.00 |
| unique_hangs | 3.00 | 2.00 |
| fuzz_sec | 10796.00 | 10797.00 |
| peak_rss_mb | 14.00 | 15.00 |
| seed_files(种子文件数) | 2.00 | 78.00 |
| seed_regions(AFLNet 分区数) | 14.00 | 355.00 |
| dict_tokens(官方字典条目) | 14.00 | 14.00 |
| l_per(%) [次要·行覆盖] | 14.10 | 5.90 |
| b_per(%) [次要·分支覆盖] | 9.20 | 4.00 |
| 参数自检(command_line) | OK | OK |

## 自证：两组之间只有种子不同

| 协议 | 组 | seed_files | seed_regions | dict_tokens | 字典一致 |
|---|---|---|---|---|---|
| rtsp | baseline | 7 | 29.0 | 24 | |
| rtsp | protorag | 39 | 150.0 | 24 | |
| rtsp | **字典一致性** | | | | ✓ 相同（24.0） |
| sip | baseline | 1 | 4.0 | 0 | |
| sip | protorag | 25 | 112.0 | 0 | |
| sip | **字典一致性** | | | | ✓ 相同（0.0） |
| smtp | baseline | 2 | 14.0 | 14 | |
| smtp | protorag | 78 | 355.0 | 14 | |
| smtp | **字典一致性** | | | | ✓ 相同（14.0） |

## 次要指标：官方 l_per / b_per 与主指标 bitmap_cvg 并列

> `bitmap_cvg` = AFLNet 自报边覆盖；`l_per`/`b_per` = cov_script 行/分支覆盖。
> 二者不是同一个量，**不换算、不取舍**；方向不一致时如实标注。
> 「同向」= 该协议的 `bitmap_cvg` 与 `l_per` **差值方向是否一致**（协议级判定）。

| 协议 | 指标 | protorag | baseline | 差值 | 同向 |
|---|---|---|---|---|---|
| rtsp | l_per(%) [次要·行覆盖] | 24.70 | 24.20 | +0.50 | 是 |
| rtsp | b_per(%) [次要·分支覆盖] | 15.70 | 15.40 | +0.30 | 是 |
| rtsp | bitmap_cvg(%) [主] | 9.94 | 9.72 | +0.22 | 是 |
| sip | l_per(%) [次要·行覆盖] | 6.60 | 6.40 | +0.20 | 否 |
| sip | b_per(%) [次要·分支覆盖] | 1.60 | 1.50 | +0.10 | 否 |
| sip | bitmap_cvg(%) [主] | 22.06 | 22.11 | -0.05 | 否 |
| smtp | l_per(%) [次要·行覆盖] | 5.90 | 14.10 | -8.20 | 是 |
| smtp | b_per(%) [次要·分支覆盖] | 4.00 | 9.20 | -5.20 | 是 |
| smtp | bitmap_cvg(%) [主] | 10.00 | 11.66 | -1.66 | 是 |

### ⚠ 口径分歧（必须人工判读）

- sip: bitmap_cvg 差值 -0.05 与 l_per 差值 +0.20 **方向相反** → 两个口径给出不同结论，需人工判读

## execs_done 对齐的 bitmap_cvg（主指标口径）

| 协议 | 对齐 execs_done | protorag bitmap_cvg | baseline bitmap_cvg | 差值 |
|---|---|---|---|---|
| rtsp | 36074 | 9.52 | 9.44 | +0.08 |
| rtsp | 71675 | 9.82 | 9.56 | +0.26 |
| rtsp | 107276 | 9.91 | 9.62 | +0.29 |
| rtsp | 142878 | 9.94 | 9.63 | +0.31 |
| sip | 13556 | 20.22 | 21.00 | -0.78 |
| sip | 26752 | 21.47 | 21.71 | -0.24 |
| sip | 39948 | 21.88 | 21.88 | +0.00 |
| sip | 53144 | 22.06 | 22.03 | +0.03 |
| smtp | 5729 | 9.78 | 10.61 | -0.83 |
| smtp | 10066 | 9.87 | 11.31 | -1.44 |
| smtp | 14403 | 9.94 | 11.57 | -1.63 |
| smtp | 18740 | 10.00 | 11.66 | -1.66 |

