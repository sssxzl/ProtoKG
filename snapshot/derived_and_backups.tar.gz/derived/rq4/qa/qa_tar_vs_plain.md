# RQ4 数据未被篡改的最终证据（离线核验，容器已清理）

> 容器已被删除，无法再回查容器内文件；但官方 run 脚本收尾把整个 OUTDIR 打进
> `tar -zcvf ${WORKDIR}/${OUTDIR}.tar.gz ${OUTDIR}` → **tar 内的产物就是容器内的原始字节**。
> 故本表核验：① tar 内产物 ↔ `out/` 明文副本 逐字节一致；② `command_line` ↔ summary 第 23 列逐字一致。

| 协议 | 组 | tar.gz | 产物 | tar 内 md5 | out/ 明文 md5 | 一致？ |
|---|---|---|---|---|---|---|
| rtsp | protorag | ✓ | `fuzzer_stats` | `cbd72d322f9b` | `cbd72d322f9b` | ✓ 一致 |
| rtsp | protorag | ✓ | `cov_over_time.csv` | `7c41d8ab2beb` | `7c41d8ab2beb` | ✓ 一致 |
| rtsp | protorag | ✓ | `command_line` | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | ✓ 逐字一致 |
| rtsp | baseline | ✓ | `fuzzer_stats` | `4dd3d5ea1b3e` | `4dd3d5ea1b3e` | ✓ 一致 |
| rtsp | baseline | ✓ | `cov_over_time.csv` | `6fe312eacd26` | `6fe312eacd26` | ✓ 一致 |
| rtsp | baseline | ✓ | `command_line` | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | ✓ 逐字一致 |
| sip | protorag | ✓ | `fuzzer_stats` | `28096557cf29` | `28096557cf29` | ✓ 一致 |
| sip | protorag | ✓ | `cov_over_time.csv` | `bc1df7a0d743` | `bc1df7a0d743` | ✓ 一致 |
| sip | protorag | ✓ | `command_line` | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | ✓ 逐字一致 |
| sip | baseline | ✓ | `fuzzer_stats` | `708a3875ed63` | `708a3875ed63` | ✓ 一致 |
| sip | baseline | ✓ | `cov_over_time.csv` | `cf3726273bf3` | `cf3726273bf3` | ✓ 一致 |
| sip | baseline | ✓ | `command_line` | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | ✓ 逐字一致 |
| smtp | protorag | ✓ | `fuzzer_stats` | `5504b7bea828` | `5504b7bea828` | ✓ 一致 |
| smtp | protorag | ✓ | `cov_over_time.csv` | `4de607215c5f` | `4de607215c5f` | ✓ 一致 |
| smtp | protorag | ✓ | `command_line` | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | ✓ 逐字一致 |
| smtp | baseline | ✓ | `fuzzer_stats` | `4c43fe4f571d` | `4c43fe4f571d` | ✓ 一致 |
| smtp | baseline | ✓ | `cov_over_time.csv` | `6613b5b27820` | `6613b5b27820` | ✓ 一致 |
| smtp | baseline | ✓ | `command_line` | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | /home/ubuntu/aflnet/afl-fuzz -d -i /home… | ✓ 逐字一致 |

## 结论

**全部一致** —— 6 个 tar.gz 内的原始产物与 `out/` 明文副本**逐字节相同**，`command_line` 与 `rq4_summary.csv` 第 23 列**逐字一致**。

→ **数据链完整、产物未被篡改**。容器已删除不影响任何结论的可回查性：
所有分析字段（`bitmap_cvg` / `execs_done` / `paths_*` / `l_per` / `b_per` / `command_line`）都同时存在于 `out/` 明文副本与 tar.gz 原始产物中。