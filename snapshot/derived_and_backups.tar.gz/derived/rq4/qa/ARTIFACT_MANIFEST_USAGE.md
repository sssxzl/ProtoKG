# 产物自证清单 —— 用法

`rq4_summary_v3.artifacts.md5` 记录了 RQ4 终态全部 18 个产物的 md5
（6 组 × {`fuzzer_stats`, `cov_over_time.csv`, `out.tar.gz`}）。

## 怎么用

清单里是**绝对路径**，因此**在任意目录**执行都可用：

```bash
# 在 VM 上校验（清单所在目录即产物所在根）
cd /home/zxy/rq4 && md5sum -c rq4_summary_v3.artifacts.md5

# 在任意 cwd 校验（绝对路径 → 与 cwd 无关）
cd /tmp && md5sum -c /home/zxy/rq4/rq4_summary_v3.artifacts.md5

# 本机校验（清单随交付物存档，路径基准是 VM 的 out/）
#   → 本机无那些绝对路径，需在 VM 上执行
```

**期望输出**：18 行全部 `OK`，`rc=0`。
若某行 `FAILED open or read` → 该产物自采集以来**已被改动或删除**。

## 这份清单证明什么

- 清单里的 md5 与 `out/` 明文副本**逐字节一致**（QA 独立核验，18/18）
- 清单里的 md5 与**官方 tar.gz 内的原始字节**一致（容器已删，tar 即其替身；QA 与工程师两套独立实现交叉比对，0 条不一致）
- 故：`bitmap_cvg` / `execs_done` / `paths_*` / `l_per` / `b_per` / `command_line`
  这些分析字段**全部可回查、且可自证未被篡改**

## 注意

- 清单路径**绑定当前 out_root**。换机器或换 out_root 后需重新生成：
  ```bash
  bash scripts/rq4_collect.sh --offline <OUT_ROOT> --summary <SUMMARY.csv>
  ```
  清单会写到 `<SUMMARY 去掉 .csv>.artifacts.md5`。
- 容器已删除，**必须用 `--offline`**（`collect.sh` 在容器不存在时会提前退出，
  走不到写清单那一步）。
