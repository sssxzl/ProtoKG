#!/bin/bash
echo "=== 空值行的真实位置（数据行序号 / 数据行总数）==="
for spec in "rq4_sip_protorag_r1 protorag" "rq4_sip_baseline_r1 baseline"; do
  set -- $spec; c=$1; g=$2
  echo "--- $c"
  docker exec "$c" sh -c "cat /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null \
    | awk -F',' 'NR==1{next} {tot++; if (NF!=5||$2==""||$4=="") {bad[++nb]=tot" (Time="$1")"}} END{print "    数据行总数="tot"  空值行数="nb+0; for(i=1;i<=nb;i++) print "      空值行位于第 "bad[i]" 行"}'
  echo "    当前末行:"
  docker exec "$c" sh -c "tail -1 /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null | sed 's/^/      /'
done
echo ""
echo "=== 关键判定：磁盘恢复后写入的新行是否有效？（观察 3 分钟）==="
before_p=$(docker exec rq4_sip_protorag_r1 sh -c 'wc -l < /home/ubuntu/experiments/kamailio/out-sip-protorag-r1/cov_over_time.csv' 2>/dev/null)
before_b=$(docker exec rq4_sip_baseline_r1 sh -c 'wc -l < /home/ubuntu/experiments/kamailio/out-sip-baseline-r1/cov_over_time.csv' 2>/dev/null)
echo "    3 分钟前： protorag=$before_p 行, baseline=$before_b 行"
sleep 180
after_p=$(docker exec rq4_sip_protorag_r1 sh -c 'wc -l < /home/ubuntu/experiments/kamailio/out-sip-protorag-r1/cov_over_time.csv' 2>/dev/null)
after_b=$(docker exec rq4_sip_baseline_r1 sh -c 'wc -l < /home/ubuntu/experiments/kamailio/out-sip-baseline-r1/cov_over_time.csv' 2>/dev/null)
dp=$((after_p-before_p)); db=$((after_b-before_b))
echo "    3 分钟后： protorag=$after_p 行, baseline=$after_b 行"
echo "    -> protorag 新增 $dp 行, baseline 新增 $db 行"
echo ""
echo "    新增行内容（检查是否有效）:"
if [ "$dp" -gt 0 ]; then
  docker exec rq4_sip_protorag_r1 sh -c "tail -$dp /home/ubuntu/experiments/kamailio/out-sip-protorag-r1/cov_over_time.csv" 2>/dev/null | sed 's/^/      pro: /'
fi
if [ "$db" -gt 0 ]; then
  docker exec rq4_sip_baseline_r1 sh -c "tail -$db /home/ubuntu/experiments/kamailio/out-sip-baseline-r1/cov_over_time.csv" 2>/dev/null | sed 's/^/      bas: /'
fi
echo ""
echo "=== 磁盘现状 ==="
df -h / | tail -1
