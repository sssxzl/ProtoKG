#!/bin/bash
echo "=== 各容器日志尾部（检查是否 PFATAL / 提前退出）==="
for c in rq4_rtsp_protorag_r1 rq4_rtsp_baseline_r1 rq4_sip_protorag_r1 rq4_sip_baseline_r1 rq4_smtp_protorag_r1 rq4_smtp_baseline_r1; do
  echo "--- $c  (exit=$(docker inspect -f '{{.State.ExitCode}}' $c 2>/dev/null))"
  docker logs "$c" 2>&1 | tail -6
  echo "    PFATAL/ERROR 计数: $(docker logs "$c" 2>&1 | grep -ciE 'PFATAL|FATAL|ERROR:' || echo 0)"
done
