#!/bin/bash
echo "=== 错误出现的时间分布（判断是否由 QA 占满磁盘引起）==="
echo "QA 占满磁盘的时间窗：约 13:15-13:25（VM 本地时间）"
echo ""
for c in rq4_sip_protorag_r1 rq4_sip_baseline_r1; do
  echo "--- $c"
  # 日志总行数
  total=$(docker logs "$c" 2>&1 | wc -l)
  # 各类错误首次出现的行号（相对位置 %）
  for pat in "Could not open output file" "gcovr could not infer" "No space left on device"; do
    first=$(docker logs "$c" 2>&1 | grep -n "$pat" | head -1 | cut -d: -f1)
    last=$(docker logs "$c" 2>&1 | grep -n "$pat" | tail -1 | cut -d: -f1)
    if [ -n "$first" ]; then
      pf=$((first*100/total)); pl=$((last*100/total))
      echo "    $pat : 首现行=$first (${pf}%) 末行=$last (${pl}%)"
    else
      echo "    $pat : 无"
    fi
  done
  echo ""
done
echo "=== SIP cov_over_time.csv 的异常行（gcovr 失败导致）==="
for spec in "rq4_sip_protorag_r1 protorag" "rq4_sip_baseline_r1 baseline"; do
  set -- $spec; c=$1; g=$2
  echo "--- $c"
  docker exec "$c" sh -c "cat /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null | awk -F, 'NR==1{next} NF!=5 || $2=="" || $4=="" {print "    异常行: "$0}'
  echo "    末3行:"
  docker exec "$c" sh -c "cat /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null | tail -3 | sed 's/^/      /'
done
