import re, pathlib
root = pathlib.Path('/home/zxy/rq4/out')

def parse(p):
    t = p.read_text(errors='replace'); o = {}
    for k in ['execs_done', 'paths_total', 'bitmap_cvg', 'start_time', 'last_update']:
        m = re.search(r'^' + k + r'\s*:\s*(.*?)\s*$', t, re.M)
        o[k] = m.group(1) if m else ''
    return o

print('=' * 104)
print('验证假设：首快照时的 paths_total ≈ 种子数 + 1（初始队列），说明此刻**校准刚结束**')
print('         → 首快照 execs ≈ 该组的「校准期 exec 消耗」')
print('=' * 104)
print(f"{'协议':<7}{'组':<10}{'种子数':<8}{'首快照':<26}{'校准期execs(估)':<18}{'占终态execs比':<16}")
print('-' * 104)
for proto in ['rtsp', 'sip', 'smtp']:
    for grp in ['protorag', 'baseline']:
        d = root / proto / grp / 'r1'
        snaps = sorted(d.glob('stats_*.txt'))
        pts = []
        for s in snaps:
            o = parse(s)
            if o['execs_done'] and o['paths_total']:
                pts.append((int(o['execs_done']), int(o['paths_total']), o))
        if not pts:
            continue
        pts.sort()
        e, pt, o = pts[0]
        total = pts[-1][0]
        # 种子数 = 首快照 paths_total - 1
        n = pt - 1
        print(f'{proto:<7}{grp:<10}{n:<8}execs={e}, paths_total={pt}'
              f'{"":<4}{e:<18}{e/total*100:>10.1f}%')
    print()

print('★ 结论：')
print('  protorag 的**初始校准**消耗了远多于 baseline 的 exec 预算')
print('  （RTSP 473 vs 217 / SIP 361 vs 41 / SMTP 1393 vs 81），')
print('  因为 AFLNet 要逐个校准每个种子（calibrate_case → run_target → total_execs++）。')
print('  这意味着在「等 execs_done」口径下，protorag 用于**真正模糊测试**的 exec 比例更低。')
