import pathlib

root = pathlib.Path('/home/zxy/rq4/out')
SEEDS = {'rtsp': {'protorag': 39, 'baseline': 7},
         'sip': {'protorag': 25, 'baseline': 1},
         'smtp': {'protorag': 78, 'baseline': 2}}

print('=== I1 的精确表述：倒退点是否**恰好**在段边界（行号 == 种子数）===')
print()
print('| 协议 | 组 | 种子数 | 倒退次数 | 倒退所在行 | 是否恰在段边界 | 段1末行Time | 段2首行Time | 段2首行是否更早 |')
print('|---|---|---|---|---|---|---|---|---|')
for proto in ['rtsp', 'sip', 'smtp']:
    for grp in ['protorag', 'baseline']:
        f = root / proto / grp / 'r1' / 'cov_over_time.csv'
        if not f.exists():
            continue
        lines = [l.strip() for l in f.read_text(errors='replace').splitlines() if l.strip()]
        hdr = lines[0].split(',')
        rows = []
        for i, l in enumerate(lines[1:], 1):
            p = l.split(',')
            if len(p) != len(hdr):
                continue
            try:
                rows.append((i, int(p[0])))
            except ValueError:
                pass
        ns = SEEDS[proto][grp]
        backs = [(rows[i - 1][0], rows[i - 1][1], rows[i][0], rows[i][1])
                 for i in range(1, len(rows)) if rows[i][1] < rows[i - 1][1]]
        at_b = '✓' if (len(backs) == 1 and backs[0][0] == ns) else (
            '—（无倒退）' if not backs else '✗')
        bpos = backs[0][0] if backs else None
        t1 = rows[ns - 1][1] if ns <= len(rows) else None
        t2 = rows[ns][1] if ns < len(rows) else None
        earlier = (t2 < t1) if (t1 and t2) else None
        print(f'| {proto} | {grp} | {ns} | {len(backs)} | {bpos if bpos else "—"} | {at_b} | '
              f'{t1 if t1 else "—"} | {t2 if t2 else "—"} | '
              f'{("是" if earlier else "否") if earlier is not None else "—"} |')

print()
print('=== 结论 ===')
print('**I1 的正确表述**：段边界处**可能出现**一次 Time 倒退，且**一旦出现就恰在段边界**（行号 == 种子数）。')
print('  4/6 个文件出现倒退；另 2 个（sip/baseline、smtp/baseline）**不出现** ——')
print('  原因是它们的**种子数极少**（1 / 2 个），单个种子的 mtime 恰好**早于**第一个')
print('  fuzz 生成的测试用例的 mtime → 段边界处不构成「倒退」。')
print('  → 也就是说：**倒退不是必然的**，「Time 恰好倒退 1 次」这个说法应修正为')
print('     「倒退（若发生）恰好落在段边界」，倒退次数 ∈ {0, 1}。')
print()
print('**这不影响任何结论**：')
print('  · I2（末行 = Time 最大行）6/6 成立 → 新版 cov_last_row 的「末行 = 终值」前提成立 ✓')
print('  · 段2 的 Time 范围覆盖段1（6/6）→ 段2 的用例都是 fuzz 期间产生的，比种子更新 ✓')
print('  · 「行号在两组之间不可直接比较」这个结论依然成立（依据是**每 5 个写一行**的采样率，')
print('    与 Time 是否倒退无关）')
