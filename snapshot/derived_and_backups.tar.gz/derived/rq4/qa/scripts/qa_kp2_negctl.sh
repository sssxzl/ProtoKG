#!/bin/bash
# KP-2 负控：用**参照容器**机制验证「服务端命令之后追加选项」现在能被抓住
BASE='/home/ubuntu/aflnet/afl-fuzz -d -i /home/ubuntu/experiments/in-rtsp -x /home/ubuntu/experiments/rtsp.dict -o out-rtsp-protorag-r1 -N tcp://127.0.0.1/8554 -P RTSP -D 10000 -q 3 -s 3 -E -K -R -m none -t 5000 ./testOnDemandRTSPServer 8554'
REF='/home/ubuntu/aflnet/afl-fuzz -d -i /home/ubuntu/experiments/in-rtsp -x /home/ubuntu/experiments/rtsp.dict -o out-rtsp-baseline-r1 -N tcp://127.0.0.1/8554 -P RTSP -D 10000 -q 3 -s 3 -E -K -R -m none -t 5000 ./testOnDemandRTSPServer 8554'
OPT='-P RTSP -D 10000 -q 3 -s 3 -E -K -R -m none -t 5000'
NET='tcp://127.0.0.1/8554'
PC=/home/zxy/rq4/scripts/rq4_param_check.py
run(){ printf '  %-44s -> ' "$1"; shift; python3 $PC --options "$OPT" --net "$NET" --command-line "$1" ${2:+--reference-command-line "$2"} 2>/dev/null; }
echo "=== 无参照（规则1 固有边界）==="
run '原始' "$BASE"
run '尾部追加 -X extra' "$BASE -X extra"
echo "=== 有参照（跨容器一致性兜底）==="
run '原始 + 参照' "$BASE" "$REF"
run '尾部追加 -X extra + 参照' "$BASE -X extra" "$REF"
run '数值漂移 -t 50000 + 参照' "${BASE/-t 5000/-t 50000}" "$REF"
