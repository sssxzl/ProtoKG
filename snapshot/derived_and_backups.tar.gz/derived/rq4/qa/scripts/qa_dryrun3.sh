#!/bin/bash
echo "=== perform_dry_run 主体（3555-3700）关键调用 ==="
docker exec rq4_sip_protorag_r1 bash -c 'sed -n "3555,3720p" /home/ubuntu/aflnet/afl-fuzz.c' | grep -nE 'execs_done|total_execs|perform_testcase|fuzz_one|for *\(|write_stats_file|update_stats|maybe_update_plot|if *\(t *>'
echo ""
echo "=== 9231 附近：perform_dry_run 前后 ==="
docker exec rq4_sip_protorag_r1 bash -c 'sed -n "9225,9250p" /home/ubuntu/aflnet/afl-fuzz.c'
