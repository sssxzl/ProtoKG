import re, pathlib
root = pathlib.Path('/home/zxy/rq4/out')

def parse(p):
    t = p.read_text(errors='replace'); o = {}
    for k in ['execs_done', 'paths_total', 'bitmap_cvg', 'start_time']:
        m = re.search(r'^' + k + r'\s*:\s*(.*?)\s*$', t, re.M)
        o[k] = m.group(1) if m else ''
    return o

print('=' * 100)
print('初始校准阶段（AFLNet perform_dry_run）的 execs 开销 —— execs_done **包含**校准执行')
print('=' * 100)
print(f"{'协议':<8}{'组':<10}{'种子数':<8}{'首快照execs':<13}{'首快照paths_total':<20}{'每种子校准execs(估)':<22}")
print('-' * 100)
for proto in ['rtsp', 'sip', 'smtp']:
    seed_n = {'protorag': 0, 'baseline': 0}
    for grp in ['protorag', 'baseline']:
        d = root / proto / grp / 'r1'
        snaps = sorted(d.glob('stats_*.txt'))
        best = None
        for s in snaps:
            o = parse(s)
            if o['execs_done']:
                e = int(o['execs_done'])
                pt = int(o['paths_total'] or 0)
                if best is None or e < best[0]:
                    best = (e, pt, s)
        if best is None:
            continue
        e, pt, s = best
        n = pt - 1  # paths_total = 种子数 + 1（初始队列 + 1）
        seed_n[grp] = n
        per = e / n if n else 0
        print(f'{proto:<8}{grp:<10}{n:<8}{e:<13}{pt:<20}{per:<22.1f}')
    a, b = seed_n['protorag'], seed_n['baseline']
    if a and b:
        print(f'         → protorag/baseline 种子比 = {a}/{b} = {a/b:.1f}×；'
              f'首快照 execs 比 = {a and 0 or 0}' )
print()
print('★ 推论：execs_done **含**初始种子校准执行（calibrate_case → run_target → total_execs++）。')
print('  故在「等 execs」口径下，种子多的一组有更大比例的 exec 预算被**校准**吃掉，')
print('  真正用于**模糊测试**的 exec 更少 → execs 对齐**不能**中和种子数量效应，反而**放大**了它的方向。')
