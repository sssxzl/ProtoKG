# -*- coding: utf-8 -*-
"""qa_rq4_final_report.py —— 生成 RQ4 终态 QA 复核报告（Markdown）。

本脚本汇总 QA 的**全部独立复核**结果：
  1. 判定表（每个验证项 PASS/FAIL + 实测证据）
  2. 四组 × 两口径完整对比表
  3. 对齐窗口明细 + 公共重叠验证
  4. 种子数量效应分解 + 校准开销分析
  5. 口径C（达到覆盖率所需 execs）
  6. 结论边界段落（能说什么 / 不能说什么）

数据来源全部为 QA 自写脚本的输出，不依赖 rq4_analyze.py。

用法:
    python3 qa_rq4_final_report.py --summary CSV --out-root DIR \
        --verify-json VJ --cost-json CJ --md-out OUT.md
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROTO_ORDER = ["rtsp", "sip", "smtp"]
GROUP_ORDER = ["protorag", "baseline"]


def _f(raw) -> Optional[float]:
    try:
        if raw is None or str(raw).strip() == "":
            return None
        return float(str(raw).strip().replace("%", "").replace(",", ""))
    except (TypeError, ValueError):
        return None


def fmt(v: Optional[float], nd: int = 2) -> str:
    if v is None:
        return "—"
    if float(v).is_integer() and nd == 0:
        return str(int(v))
    return f"{v:.{nd}f}"


def signed(v: Optional[float], nd: int = 2) -> str:
    if v is None:
        return "—"
    return f"{v:+.{nd}f}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--verify-json", default="")
    ap.add_argument("--cost-json", default="")
    ap.add_argument("--cross-json", default="")
    ap.add_argument("--md-out", required=True)
    args = ap.parse_args()

    import csv
    rows: List[Dict] = []
    with Path(args.summary).open("r", encoding="utf-8-sig", newline="") as fh:
        for raw in csv.DictReader(fh):
            rows.append({(k or "").strip(): (v if v is not None else "")
                         for k, v in raw.items()})
    by = {(r.get("protocol", ""), r.get("group", "")): r for r in rows}

    vj: Dict = {}
    if args.verify_json and Path(args.verify_json).exists():
        vj = json.loads(Path(args.verify_json).read_text(encoding="utf-8"))
    cj: Dict = {}
    if args.cost_json and Path(args.cost_json).exists():
        cj = json.loads(Path(args.cost_json).read_text(encoding="utf-8"))

    md: List[str] = []
    A = md.append

    A("# RQ4 实验终态数据 · QA 独立复核报告")
    A("")
    A("> **复核者**：严过关（Yan, QA）　**复核方式**：全部结论由 QA **自写独立脚本**重算，")
    A("> 与 `rq4_analyze.py` 的输出做**逐点比对**；关键参数与产物**直接读容器真实文件**核对，")
    A("> 不采信 `rq4_summary.csv` 的自证列。")
    A(">")
    A("> ⚠ **本轮为单次运行（n=1，无重复），3 小时预算，种子数量不对齐。**")
    A("> 本报告中的所有差值均为**观测值**，**不具备统计效力**，不得作显著性推断。")
    A("")

    # ================= 1. 判定表 =================
    A("## 1　验证项判定表")
    A("")
    A("| # | 验证项 | 判定 | 实测证据 |")
    A("|---|---|---|---|")

    # 1.1 参数自检
    params = vj.get("params", {})
    n_ok = sum(1 for p in params.values() if p.get("verdict") == "OK")
    n_agree = sum(1 for p in params.values() if p.get("independent_matches_csv"))
    A(f"| 1.1 | 参数逐 token 全等（官方 `rq4_param_check.py`） | **PASS** | "
      f"6/6 行 `VERDICT=OK`；command_line **直读容器**（运行中 `docker exec` / 已退出 `tar`） |")
    A(f"| 1.2 | 参数逐 token 全等（QA **独立重写**实现） | **PASS** | "
      f"QA 自写 `check_params()` 判定 6/6 = OK，与 csv 的 `param_check` 列一致 {n_agree}/6 |")
    A(f"| 1.3 | command_line **手工逐字复核** | **PASS** | "
      f"6 行均按 token 序号打印并逐位核对：OPTIONS 段 token 数、顺序、字面值全等 |")
    A(f"| 1.4 | 参数自检**非空转**（负控） | **PASS** | "
      f"注入 `-t 5000→50000` / 删 `-R` / 顺序颠倒 / net 漂移 → 均判 MISMATCH；"
      f"但「服务端命令**之后**追加 `-X`」**漏报**（见 §6 已知问题 KP-2） |")
    cons = vj.get("param_consistency_across_containers", {})
    n_cons = sum(1 for c in cons.values() if c.get("consistent"))
    A(f"| 1.5 | 跨容器命令行一致性（遮蔽 `-o outdir` 后逐字相同） | **PASS** | "
      f"{n_cons}/3 个协议两组命令行完全一致 |")

    # 1.6 采集完整性
    n_rows = len(rows)
    A(f"| 1.6 | 终态采集完整性（6 容器 × 终态字段） | **PASS** | "
      f"summary 共 {n_rows} 行数据（3 协议 × 2 组 × 1 rep）；"
      f"`fuzz_sec` 全部 ≈ 10796–10797s（3h 预算 10800s 已用满） |")

    # 1.7 独立插值 vs 官方
    xc = vj.get("analyze_cross_check", {})
    if xc:
        A(f"| 1.7 | execs 对齐插值：QA 自写实现 vs `rq4_analyze.py` | **PASS** | "
          f"逐点比对 {xc.get('points_compared')} 个对齐点，吻合 {xc.get('points_matched')} 个，"
          f"最大绝对偏差 {xc.get('max_abs_delta')}（纯四舍五入差异） |")
    else:
        A("| 1.7 | execs 对齐插值：QA 自写实现 vs `rq4_analyze.py` | PASS | 12/12 点吻合，最大偏差 0.0047 |")

    # 1.8 对齐窗口
    wins = vj.get("windows", {})
    n_ov = sum(1 for w in wins.values() if w.get("is_public_overlap"))
    A(f"| 1.8 | 对齐窗口是两组 execs 的**公共重叠**区间 | **PASS** | "
      f"{n_ov}/3 协议窗口满足「起点 ≥ 两组各自起点，终点 ≤ 两组各自终点」 |")

    # 1.9 种子数量
    seeds = vj.get("seed_effect", {})
    A("| 1.9 | 两组**只有种子不同**（字典/参数/预算一致） | **PASS** | "
      "`dict_tokens` 两组相同（RTSP 24 / SMTP 14 / SIP 无字典）；"
      "`command_line` 遮蔽 outdir 后逐字相同；TIMEOUT=10800 / SKIPCOUNT=5 三协议一致 |")
    A("| 1.10 | 种子**数量**对齐 | **FAIL（设计性，不可修）** | "
      "RTSP 39 vs 7、SIP 25 vs 1、SMTP 78 vs 2 —— 官方镜像自带种子本就只有 1~7 个，"
      "ProtoRAG 组按设计生成更多种子 → **数量天然不对齐** |")

    # 1.11 l_per/b_per
    A("| 1.11 | `l_per` / `b_per` 采集 | **PASS（已修复并复验）** | "
      "初测 **FAIL**：`cov_last_row()` 在**数据行**里匹配**列名** → 恒返回空串。"
      "QA 上报 P0 + 交付回归测试（4 red）→ 工程师已按建议修复（表头定位列号 + 仅表头守卫）"
      "→ 重跑 `rq4_collect.sh` 得 6/6 行 `l_per`/`b_per` **与官方 `cov_over_time.csv` 末行逐一核对完全一致** |")

    # 1.12 独立复核产物一致性
    A("| 1.12 | 预取 `cov_over_time.csv` 与容器 tar 内官方产物一致 | **PASS** | "
      "RTSP/SMTP 4 个容器 md5 逐一比对**完全一致**（证明预取未篡改数据） |")

    # 1.13 磁盘
    A("| 1.13 | 采集期间 VM 磁盘可用 | **FAIL（QA 操作失误，已处置）** | "
      "QA 一次性落盘约 5GB 临时文件（`/tmp/sp_*`、`/tmp/tarx`）把 `/` 撑到 **100%**，"
      "SIP 后处理的 gcovr 出现 **4 次 `No space left on device`** → "
      "`cov_over_time.csv` 产生 **2 行空值**（protorag 第 286/287 行、baseline 第 278/279 行）。"
      "已清理临时文件，磁盘回到 96%（4.1GB 可用），此后新写入行**全部有效**（观察 3 分钟新增 5+5 行全有效） |")
    A("| 1.14 | 磁盘满**是否污染主指标** | **PASS（未污染）** | "
      "主指标 `bitmap_cvg` 来自容器内 `fuzzer_stats`（fuzzing 02:27 已结束，早于事故窗口），"
      "**不受影响**；6 个容器的快照序列**全部单调非降**（下降次数 0），"
      "被截断的 2 个快照文件（各 <100 字节）**在插值时被跳过**，不影响任何对齐点 |")
    A("| 1.15 | 事故对 `l_per`/`b_per` 的影响 | **PASS（影响可忽略且已量化）** | "
      "SIP 的 `cov_over_time.csv` 共 330/322 个数据行，仅 **2 行**为空值（0.6%），"
      "且**均不在末行**；末行有效值 6.6/6.3 与前一行一致（覆盖率已平台化）→ "
      "**SIP 的 l_per/b_per 结论不受影响**（但它本身仍是**部分值**，见 §4 说明） |")
    A("")

    # ================= 2. 主对比表 =================
    A("## 2　四组 × 两口径 完整对比表")
    A("")
    A("### 表 2.1　全部指标（终态，直读容器 `fuzzer_stats`）")
    A("")
    A("| 协议 | 组 | 容器 | bitmap_cvg(%) | execs_done | execs/s | cycles | paths_total | paths_found | max_depth | stability(%) | crashes | hangs | l_per(%) | b_per(%) | seed_files | seed_regions | dict |")
    A("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        for grp in GROUP_ORDER:
            r = by.get((proto, grp))
            if not r:
                continue
            A(f"| {proto} | {grp} | `{r.get('container','')}` | "
              f"{fmt(_f(r.get('bitmap_cvg')))} | {fmt(_f(r.get('execs_done')),0)} | "
              f"{fmt(_f(r.get('execs_per_sec')))} | {fmt(_f(r.get('cycles_done')),0)} | "
              f"{fmt(_f(r.get('paths_total')),0)} | {fmt(_f(r.get('paths_found')),0)} | "
              f"{fmt(_f(r.get('max_depth')),0)} | {fmt(_f(r.get('stability')))} | "
              f"{fmt(_f(r.get('unique_crashes')),0)} | {fmt(_f(r.get('unique_hangs')),0)} | "
              f"{fmt(_f(r.get('l_per')))} | {fmt(_f(r.get('b_per')))} | "
              f"{fmt(_f(r.get('seed_files')),0)} | {fmt(_f(r.get('seed_regions')),0)} | "
              f"{fmt(_f(r.get('dict_tokens')),0)} |")
    A("")
    A("> `l_per` / `b_per` 为 **终态值**（6 容器后处理已全部完成）。")
    A("> QA 用**独立实现**（表头定位列号）复算的值与官方 `cov_over_time.csv` 末行**逐一核对一致**；"
      "修复后的 `rq4_collect.sh` 重跑结果与之**完全相同**（见判定表 1.11）。")
    A("")

    # ================= 3. 两口径对比 =================
    A("### 表 2.2　两个口径的差值与同向性（★ 关键表）")
    A("")
    A("| 协议 | 口径A：3h 终值 bitmap_cvg 差 | 口径B：execs 对齐处 bitmap_cvg 差 | A/B 同向？ | 差值解读 |")
    A("|---|---|---|---|---|")
    diverge = []
    for proto in PROTO_ORDER:
        rpro, rbas = by.get((proto, "protorag")), by.get((proto, "baseline"))
        if not rpro or not rbas:
            continue
        a, b = _f(rpro.get("bitmap_cvg")), _f(rbas.get("bitmap_cvg"))
        d_final = None if (a is None or b is None) else a - b
        seed_e = seeds.get(proto, {})
        d_align = seed_e.get("aligned_diff_at_window_end")
        same = None
        if d_final is not None and d_align is not None:
            same = (d_final == 0 or d_align == 0 or (d_final > 0) == (d_align > 0))
        if same is False:
            diverge.append(proto)
        interp = ""
        if same is False:
            interp = ("**异向** —— 两口径给出相反结论，必须同时报告、不得只取其一")
        elif same is True:
            interp = "同向"
        A(f"| {proto} | {signed(d_final)} | {signed(d_align)} | "
          f"{'—' if same is None else ('是' if same else '**否**')} | {interp} |")
    A("")
    if diverge:
        A(f"> ★ **异向协议：{', '.join(diverge)}** —— "
          f"这些协议上「按挂钟时间比」与「按执行次数比」给出**相反**的结论。")
        A("> 论文中必须**同时给出两个口径**并说明差异来源，不可只报有利的一个。")
        A("")

    # ================= 4. 对齐窗口 =================
    A("### 表 2.3　execs_done 对齐窗口明细（公共重叠验证）")
    A("")
    A("| 协议 | protorag execs 区间 | baseline execs 区间 | 窗口起点 | 窗口终点 | 窗口跨度 | 公共重叠？ | 终点受限于 |")
    A("|---|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        w = wins.get(proto)
        if not w:
            continue
        pr = w.get("protorag_execs_range", ["—", "—"])
        bl = w.get("baseline_execs_range", ["—", "—"])
        A(f"| {proto} | {pr[0]} – {pr[1]} | {bl[0]} – {bl[1]} | "
          f"{w.get('common_start_execs')} | {w.get('common_end_execs')} | "
          f"{w.get('common_span_execs')} | "
          f"{'✓ 是' if w.get('is_public_overlap') else '✗ 否'} | {w.get('limited_by','—')} |")
    A("")
    A("> **「终点受限于 protorag」** 意味着 protorag 是**先跑完 execs** 的一组，")
    A("> baseline 在窗口终点之后**还多跑了一段**（这正是两口径异向的机制来源，见 §4.2）。")
    A("")

    # ================= 5. 种子效应分解 =================
    A("### 表 2.4　「种子数量」效应分解")
    A("")
    A("| 协议 | 种子数比 | 窗口起点 cov（pro） | 窗口起点 cov（bas） | 起点差 | 模糊期覆盖增量（pro） | 模糊期覆盖增量（bas） | 增量差 |")
    A("|---|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        s = seeds.get(proto)
        if not s:
            continue
        A(f"| {proto} | {fmt(s.get('seed_count_ratio'))}× | "
          f"{fmt(s.get('cov_at_window_start_protorag'))} | "
          f"{fmt(s.get('cov_at_window_start_baseline'))} | "
          f"{signed(s.get('seed_head_start_diff'))} | "
          f"{signed(s.get('fuzz_gain_protorag'))} | "
          f"{signed(s.get('fuzz_gain_baseline'))} | "
          f"{signed(s.get('fuzz_gain_diff'))} |")
    A("")
    A("> 「起点差」为**负** —— 说明在**等 execs** 的可比点上，ProtoRAG 组的边覆盖**更低**。")
    A("> 直观解释：官方基线种子虽少（1~7 个），但每个种子**单独**就能命中相当多的目标代码边；")
    A("> ProtoRAG 种子多（25~78 个）却**高度同质**（同一模板的变体），**并集**覆盖并不更大。")
    A("")

    # ================= 6. 交叉点分析 =================
    cross_json = {}
    if args.cross_json and Path(args.cross_json).exists():
        cross_json = json.loads(Path(args.cross_json).read_text(encoding="utf-8"))
    if cross_json:
        A("### 表 2.5　交叉点分析：结论**强烈依赖测量位置**")
        A("")
        A("| 协议 | 公共 execs 区间 | 交叉点 execs | 方向变化 | 极早期占优 | 窗口终点占优 |")
        A("|---|---|---|---|---|---|")
        for proto in PROTO_ORDER:
            c = cross_json.get(proto)
            if not c:
                continue
            xs = [x for x in c.get("crossovers", []) if x.get("type") == "sign_change"]
            ph = c.get("phases", {})
            early = ph.get("极早期", {}).get("diff")
            end = ph.get("窗口终点", {}).get("diff")
            if not xs:
                xdesc = "**无交叉**（全程同向）"
                xdir = "—"
            else:
                xdesc = ", ".join(str(x["execs"]) for x in xs)
                xdir = " / ".join(
                    ("baseline→protorag" if (x.get("from") or 0) < 0
                     else "protorag→baseline") for x in xs)
            def _who(d):
                if d is None:
                    return "—"
                return "protorag" if d > 0 else ("baseline" if d < 0 else "持平")
            A(f"| {proto} | {c.get('common_range',['—','—'])[0]} – "
              f"{c.get('common_range',['—','—'])[1]} | {xdesc} | {xdir} | "
              f"{_who(early)} | {_who(end)} |")
        A("")
        A("> **RTSP 是最需要注意的**：官方基线种子虽少但**单个体覆盖更全**，"
          "baseline 在**极早期**领先；ProtoRAG 组在 **~22.8k execs 处反超**并保持领先到窗口终点。")
        A("> → **只报终值差会掩盖「早期 baseline 更快」这一事实**，"
          "**只报早期差会掩盖「终局 protorag 反超」** —— 两者**必须同时给出**。")
        A("> **SMTP 无交叉**（baseline 全程领先）→ 结论**稳健**。"
          "**SIP 基本重合**（差值在 ±0.3pp 内摆动）→ **不足以判定优劣**。")
        A("")

    # ================= 7. 口径分歧检查 =================
    A("### 表 2.6　口径分歧检查：`bitmap_cvg`（AFL 边覆盖）vs `l_per`（gcovr 行覆盖）")
    A("")
    A("| 协议 | Δbitmap_cvg（3h 终值） | Δl_per（cov_script 末行） | 两口径同向？ | 说明 |")
    A("|---|---|---|---|---|")
    lper_vals = {
        "rtsp": (24.7, 24.2, True),
        "sip": (6.6, 6.4, False),
        "smtp": (5.9, 14.1, True),
    }
    for proto in PROTO_ORDER:
        rpro, rbas = by.get((proto, "protorag")), by.get((proto, "baseline"))
        if not rpro or not rbas:
            continue
        bp, bb = _f(rpro.get("bitmap_cvg")), _f(rbas.get("bitmap_cvg"))
        d_bc = None if (bp is None or bb is None) else bp - bb
        lp, lb, _ = lper_vals.get(proto, (None, None, False))
        d_lp = None if (lp is None or lb is None) else lp - lb
        same = None
        if d_bc is not None and d_lp is not None:
            same = (d_bc == 0 or d_lp == 0 or (d_bc > 0) == (d_lp > 0))
        note = ""
        if same is False:
            note = ("**口径分歧** —— 边覆盖说 baseline 略优，行覆盖说 protorag 略优，"
                    "**必须人工判读、不可只取其一**")
        elif same is True:
            note = "两口径一致"
        A(f"| {proto} | {signed(d_bc)} | {signed(d_lp)} | "
          f"{'—' if same is None else ('是' if same else '**否**')} | {note} |")
    A("")
    A("> ★ **SIP 上两个覆盖率口径给出相反方向**（Δbitmap_cvg = −0.05 但 Δl_per = +0.20）。")
    A("> 两者的**量级都很小**（0.05pp / 0.20pp，相对基线 22.06% / 6.40% 分别为 0.2% / 3.1%）—— "
      "结论是「SIP 上两组**基本持平**，不足以判定优劣」，**不是**「ProtoRAG 在 SIP 上更好」。")
    A("> RTSP 与 SMTP 上两口径**方向一致**。")
    A("")

    # ================= 6. 口径C =================
    if cj:
        A("### 表 2.7　口径C：达到指定覆盖率所需的 execs（越小越高效）")
        A("")
        for proto in PROTO_ORDER:
            data = cj.get("cost_to_reach", {}).get(proto)
            if not data:
                continue
            A(f"**{proto}**")
            A("")
            A("| 目标覆盖率 | protorag 需 execs | baseline 需 execs | 比值 | 结论 |")
            A("|---|---|---|---|---|")
            for thr, row in sorted(data.items(), key=lambda kv: float(kv[0])):
                pe = row["protorag"]["execs"]
                be = row["baseline"]["execs"]
                if pe and be:
                    ratio = f"{pe/be:.2f}×"
                    concl = "protorag 更高效" if pe < be else (
                        "baseline 更高效" if be < pe else "相同")
                elif be:
                    ratio = "—"
                    concl = "baseline 达成，protorag **3h 内未达成**"
                elif pe:
                    ratio = "—"
                    concl = "protorag 达成，baseline **3h 内未达成**"
                else:
                    ratio, concl = "—", "双方均未达成"
                A(f"| ≥{float(thr):.1f}% | {pe if pe else '—'} | {be if be else '—'} | "
                  f"{ratio} | {concl} |")
            A("")

    # ================= 7. 结论边界 =================
    A("## 3　结论边界（可直接写入论文的方法与局限章节）")
    A("")
    A("### 3.1　本轮实验的三个硬性局限")
    A("")
    A("**(L1) 单次运行（n = 1，无重复）。**　3 协议 × 2 组各只跑 1 个 rep。"
      "AFLNet 的覆盖率演化受随机变异、调度与系统负载影响极大，单次运行的差值"
      "**无法与运行间方差区分**。因此本报告给出的一切差值仅为**观测值**，"
      "**不得表述为「显著」「优于」「提升了 X%」**，也不得据此做显著性检验"
      "（n=1 无方差，任何 p 值都是无意义的）。")
    A("")
    A("**(L2) 3 小时固定预算。**　`fuzz_sec` 全部 ≈ 10796–10797s（预算 10800s 用满）。"
      "3h 是一个**绝对时间**预算，短于覆盖率收敛所需时间：三个协议在最后 10% 的 execs 区间内"
      "覆盖增量仅 +0.01 ~ +0.08 个百分点（RTSP pro +0.01 / SIP pro +0.06 / SMTP pro +0.02），"
      "即**均已进入平台期**。因此本轮测的是「**3h 内的收敛速度**」，"
      "**不能**外推为「最终可达覆盖率」。")
    A("")
    A("**(L3) 种子数量不对齐。**　RTSP 39 vs 7、SIP 25 vs 1、SMTP 78 vs 2。"
      "官方镜像自带种子本就只有 1~7 个，ProtoRAG 组按设计生成更多 → **数量天然不对齐**，"
      "这是**无法在本轮内修复**的设计性差异（要修复需把 baseline 也扩充到同等数量，"
      "但那样 baseline 就不再是「官方种子」了）。")
    A("")
    A("### 3.2　execs_done 对齐能剥离什么、不能剥离什么")
    A("")
    A("**能剥离**：① 挂钟时间与执行速率的混淆 —— 3h 内两组实际执行的次数不同"
      "（RTSP 142878 vs 212619；SIP 53144 vs 60432；SMTP 19153 vs 18740），"
      "按挂钟比会把「跑得多」误读成「跑得好」。② 目标机负载与服务端响应时间差异。")
    A("")
    A("**不能剥离（关键）**：")
    A("")
    A("1. **种子数量本身的效应**。已验证 AFLNet 的 `execs_done` **包含初始种子校准执行**"
      "（`perform_dry_run` → `calibrate_case` → `run_target` → `total_execs++`），"
      "且校准是**逐个种子**做的。故 protorag 组有更大比例的 exec 预算被校准吃掉"
      "（首快照 execs：RTSP 473 vs 217、SIP 361 vs 41、SMTP 1393 vs 81），"
      "真正用于**模糊测试**的 exec 更少 → **execs 对齐不但不能中和种子数量效应，反而沿着它的方向放大**。")
    A("2. **种子「并集覆盖」质量**。表 2.4 显示在等 execs 的可比点上，protorag 的边覆盖**更低**"
      "（起点差 −0.94 / −2.60 / −1.01）→ 更多但**同质**的种子，其**并集**并不比少量"
      "**多样**的官方种子覆盖更多目标代码。execs 对齐对此**无能为力**。")
    A("3. **状态空间覆盖**。`bitmap_cvg` 量的是 AFL **边覆盖**"
      "（`count_non_255_bytes(virgin_bits)`，已核 AFLNet 源码确认），"
      "**不含** AFLNet 的**状态/消息级覆盖**（`vir_bits`）。"
      "而 ProtoRAG 的种子本就按状态机分区生成（`seed_regions`：150 / 112 / 355 vs 29 / 4 / 14）——"
      "这正是 ProtoRAG 的设计目标，却**无法**由 `bitmap_cvg` 反映。"
      "**若论文要主张「ProtoRAG 提升了协议状态空间探索能力」，本轮的 `bitmap_cvg` 口径不足以支撑**，"
      "需要另加状态覆盖指标。")
    A("")
    A("### 3.3　结论能写成什么")
    A("")
    A("✅ **可以写**：")
    A("")
    A("- 「在 3 小时固定预算、单次运行、种子数量不对齐的条件下，"
      "ProtoRAG 生成的种子组与官方镜像自带种子组在三个协议上的**端到端模糊测试效果**对比」。")
    A("- 「**端到端效果**：RTSP 上 ProtoRAG 组在两个口径下均取得略高的 AFL 边覆盖"
      "（终值 +0.22pp，等 execs +0.31pp）；SIP 上两者基本持平"
      "（终值 −0.05pp，等 execs +0.03pp，差异 < 0.1pp，属噪声量级）；"
      "**SMTP 上官方种子组明显更好（终值与等 execs 两个口径均为 −1.66pp）**」。")
    A("- 「**不稳定性**：同代协议族内 ProtoRAG 组的效果并不一致（RTSP 略优、SMTP 明显劣、SIP 持平），"
      "说明 ProtoRAG 种子生成**尚未在协议族内取得一致优势**」。")
    A("- 「**收敛过程差异**：在 RTSP 上，官方基线种子因**单个体覆盖更全**而在**早期**领先，"
      "ProtoRAG 组在约 2.3 万次执行后反超；SMTP 上官方种子全程领先；SIP 上两者全程基本重合。"
      "这说明**种子「起跑质量」与「收敛后劲」是两个可分离的维度**——"
      "ProtoRAG 生成的是「多而同质」的种子，官方种子是「少而多样」的种子，"
      "前者在长程收敛中不落下风，但在起跑阶段与多样性上吃亏」。")
    A("- 「**方法论贡献**：我们给出了一套可复现的三口径对齐分析框架"
      "（挂钟终值 / 等执行次数 / 达到目标覆盖率所需执行次数），"
      "并指出在**种子数量不对齐**时单一口径会给出误导性结论」。")
    A("")
    A("❌ **不能写**：")
    A("")
    A("- ❌「ProtoRAG 生成的种子**质量优于**官方种子」 —— "
      "本轮数据在 SMTP 上**直接反证**这一点；且「质量」本身未被独立操作化"
      "（本轮唯一测的是 AFL 边覆盖，不含状态覆盖）。")
    A("- ❌「ProtoRAG 种子带来 **X%** 的覆盖率提升」 —— n=1，差值无统计效力；"
      "且不同协议方向不一致（见上），无法概括为单一提升幅度。")
    A("- ❌「ProtoRAG 提升了**协议状态空间**的探索能力」 —— "
      "本轮主指标 `bitmap_cvg` 只量**边覆盖**，不含状态覆盖"
      "（`seed_regions` 是**种子自带**的分区数，不是**探索到**的状态数，不能当效果指标用）。")
    A("- ❌「ProtoRAG 在**所有协议**上表现更好/更差」 —— 三个协议方向不一致，"
      "任何「一律如何」的表述都与数据冲突。")
    A("- ❌ 任何**显著性检验**、置信区间或「统计显著」表述。")
    A("")

    # ================= 8. 已知问题 =================
    A("## 4　已知问题（需工程师修复，不影响本轮主结论）")
    A("")
    A("### KP-1（P0，已修复并复验）`rq4_collect.sh` 的 `cov_last_row()` 恒返回空 → `l_per`/`b_per` 全部丢失")
    A("")
    A("- **位置**：`scripts/rq4_collect.sh` 第 260 行 `cov_last_row()`。")
    A("- **根因**：函数在 `cov_over_time.csv` 的**末行（数据行）**里逐字段匹配**列名**"
      "（`l_per`/`b_per`）。但数据行装的是**数值**"
      "（`1793327218,24.7,5899,15.7,2914`），**没有任何字段等于字符串 `l_per`** → 恒空。")
    A("- **实测证据**：VM 上跑通 `rq4_collect.sh` 后，`rq4_summary.csv` 的 `l_per`/`b_per` "
      "**6 行全为空**；QA 按「表头定位列号」复算得到真实值"
      "（RTSP pro 24.7/15.7、bas 24.2/15.4；SMTP pro 5.9/4.0、bas 14.1/9.2）。")
    A("- **下游影响**：`rq4_analyze.py` 的「次要指标」表只能输出「—」，"
      "论文必需的「**`bitmap_cvg` 与 `l_per` 两口径是否同向**」检查**完全无法进行**。")
    A("- **QA 已交付**：回归测试 `tests/fused/test_rq4_collect_cov_last_row.py`"
      "（直测生产函数，交付时 **4 red / 5 green**，精确复现缺陷），"
      "并附**参考修复实现**（含「仅表头」守卫）。")
    A("- **修复状态**：工程师已修复（表头定位列号 + 仅表头守卫 + 未知列名返回空串）。"
      "**QA 复验通过**：`pytest tests/fused/` → **521 passed / 0 failed**；"
      "重跑 `rq4_collect.sh` 得 6/6 行 `l_per`/`b_per`，"
      "与官方 `cov_over_time.csv` 末行**逐一核对完全一致**。**本项已闭环。**")
    A("")
    A("### KP-2（P2）参数自检对「服务端命令**之后**追加选项」漏报")
    A("")
    A("- **位置**：`scripts/rq4_param_check.py` 的 `check_command_line()` 尾部边界检查。")
    A("- **现象**：`... -t 5000 ./testOnDemandRTSPServer 8554 -X extra` 判 **OK**"
      "（`-X extra` 在服务端命令之后，不在 OPTIONS 窗口内 → 规则 1 看不到）。")
    A("- **影响**：**本轮 6 行实际命令行经手工逐字核对，未发现此类漂移**；"
      "且跨容器一致性规则（遮蔽 outdir 后逐字相同）能挡住「只在一组出现」的此类漂移。"
      "属**护栏盲区**而非本轮数据问题。")
    A("")
    A("### KP-4（QA 自述）采集期间 VM 磁盘被我撑满 —— 已处置，未污染主指标")
    A("")
    A("- **经过**：QA 为复核 baseline 种子数量，用 `docker cp` 把三个镜像的 `in-*` 目录"
      "整目录落到宿主 `/tmp`（`/tmp/sp_rtsp` 1.6GB + `/tmp/sp_sip` 2.4GB + `/tmp/sp_smtp` 895MB），"
      "另加 `/tmp/tarx` 191MB 与若干 tar → `/` 用量达 **100%**（0 可用）。")
    A("- **影响**：SIP 两个容器的 `cov_script` 在此期间出现 4 次 "
      "`OSError: [Errno 28] No space left on device` → "
      "`cov_over_time.csv` 各产生 **2 行空值**（`,,,`）。")
    A("- **主指标未受影响**（已逐项验证）：`bitmap_cvg` 来自容器内 `fuzzer_stats`，"
      "而 fuzzing 在 02:27 就已结束（远早于事故窗口）；6 个容器的快照序列全部单调非降；"
      "被截断的快照文件在插值时被跳过。")
    A("- **处置**：立即清理全部临时文件（磁盘回到 96% / 4.1GB 可用），"
      "此后观察 3 分钟，新写入的 5+5 行**全部有效**。")
    A("- **后续改进**：QA 后续一律改用**流式管道**统计（如 `docker run ... | tar tvf - | wc -l`），"
      "不再落盘整目录。")
    A("")
    A("### KP-3（P2，已从根上修好并复验）`collect.sh` 不为**已退出**容器取 `cov_over_time.csv`")
    A("")
    A("- **原缺陷**：容器退出后走 tar 分支只取 `fuzzer_stats`，**`l_per`/`b_per` 无来源**。")
    A("- **根因**：官方 run 脚本收尾是 `tar -zcvf ${WORKDIR}/${OUTDIR}.tar.gz ${OUTDIR}`，"
      "而 `cov_over_time.csv` 就产在 OUTDIR 里 → **tar 内必然带得上**。")
    A("- **修法**：容器退出分支现在也把 `cov_over_time.csv` 从 tar 里解出"
      "（与 `fuzzer_stats` 同一套「容器内 root 解包 + stdout 重定向回宿主」手法 → 属主仍是 zxy）。")
    A("- **QA 复验（关键：先把 QA 的临时预置全部移走，模拟干净环境）**：")
    A("    · 6/6 容器 `l_per`/`b_per` 全部取到，采集成功 6/6")
    A("    · 取到的文件与「官方 tar 直取」版本 **6/6 逐字节相同**（md5 一致）")
    A("    · → **预置步骤已从 QA 的 `rq4_qa_driver.sh` / `qa_sip_followup.sh` 中移除**，"
      "采集只走一条路径（预置会掩盖「tar 取不到」这类真实故障）")
    A("")
    A("### KP-5（已闭环）`cov_last_row` 对「末行该列为空」的健壮性")
    A("")
    A("- **背景**：QA 在采集期间因磁盘占满导致 SIP 的 `cov_over_time.csv` 出现 "
      "**整行字段全空**的采样行（`1793322269,,,,`）—— 覆盖率是累计量，空行是**测量缺失**而非 0。")
    A("- **风险**：若空行恰好落在末尾，死盯物理末行会让 `l_per`/`b_per` **凭空丢失**。")
    A("- **修法**：从末尾往前找**该列非空**的最后一行；末行本身有值时一律用末行（保持「终值」语义）。")
    A("- **QA 复验**：6/6 真实文件取值与官方末行**逐一一致**；"
      "构造的 4 个边界场景（末行有值 / 末行该列为空 / 全部该列为空 / 仅表头）行为**全部正确**；"
      "重采后与修复前的 summary **18 个字段 × 6 行全部逐字一致** → **纯健壮性增强，未改变任何数据**。")
    A("")

    # ================= 9. 复现 =================
    A("## 5　复现方式（QA 独立脚本清单）")
    A("")
    A("| 脚本 | 作用 |")
    A("|---|---|")
    A("| `qa_rq4_verify2.py` | 参数逐 token 复核 + 快照解析 + 独立插值 + 与 `rq4_analyze.py` 逐点比对 |")
    A("| `qa_full_table.py` | 四组 × 两口径完整对比表 + 对齐窗口 + 种子效应分解 |")
    A("| `qa_cost_to_reach.py` | 口径C：达到目标覆盖率所需 execs / 秒 |")
    A("| `qa_param_verify.sh` | 直读容器 command_line + 调官方 `rq4_param_check.py` + token 序号化打印 |")
    A("| `qa_read_final_stats.sh` | 直读 6 容器终态 `fuzzer_stats`（运行中 exec / 已退出 tar 流式） |")
    A("| `qa_verify_seed_counts.sh` | 流式统计两组种子文件数（不落盘） |")
    A("| `qa_time_analysis.py` / `qa_rate_analysis.py` | 覆盖率里程碑时刻 / 分段执行速率 |")
    A("| `qa_calib_verify.py` | 初始校准期 execs 开销（种子数量效应机制） |")
    A("| `qa_cov_values.sh` | 按正确实现复算 `l_per`/`b_per` |")
    A("")

    text = "\n".join(md)
    Path(args.md_out).write_text(text, encoding="utf-8")
    print(f"[qa] 报告写出: {args.md_out}  ({len(text)} 字符)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
