# -*- coding: utf-8 -*-
"""qa_crossover.py —— 计算两组 bitmap_cvg 曲线的**交叉点**（crossover）。

★ 为什么必须算这个
-----------------
RQ4 的结论**强烈依赖测量位置**：

* RTSP 的曲线上 baseline **早期领先**（8.65% vs 7.76%，因官方种子单个体质量高），
  protorag 在 ~22.8k execs 处**反超**并保持领先；
* SMTP 上 baseline **全程领先**，从未交叉；
* SIP 上两者**基本重合**。

因此只报「终值差」或只报「某个对齐点差」都可能给出误导性结论。
本脚本给出**交叉点 execs** 与**交叉前后差值**，让论文能说清「在什么范围内谁占优」。

本脚本**不 import rq4_analyze.py**，独立实现。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def _field(text: str, key: str) -> str:
    m = re.search(r"^" + re.escape(key) + r"\s*:\s*(.*?)\s*$", text, re.MULTILINE)
    return m.group(1) if m else ""


def _num(raw: str) -> Optional[float]:
    s = str(raw).strip().replace("%", "").replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def load_series(out_root: Path, proto: str, group: str, rep: int = 1
                ) -> List[Tuple[int, float]]:
    d = out_root / proto / group / f"r{rep}"
    if not d.is_dir():
        return []
    raw: List[Tuple[int, float, int]] = []
    for snap in d.glob("stats_*.txt"):
        try:
            ts = int(snap.stem.split("_")[-1])
        except ValueError:
            continue
        try:
            text = snap.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ex = _num(_field(text, "execs_done"))
        cov = _num(_field(text, "bitmap_cvg"))
        if ex is None or cov is None:
            continue
        raw.append((int(ex), cov, ts))
    raw.sort(key=lambda x: (x[0], x[2]))
    dedup: Dict[int, float] = {}
    for ex, cov, _ts in raw:
        dedup[ex] = cov
    return sorted(dedup.items())


def interp(series, target):
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    for (x0, y0), (x1, y1) in zip(series, series[1:]):
        if x0 <= target <= x1:
            if x1 == x0:
                return y0
            return y0 + (y1 - y0) * (target - x0) / (x1 - x0)
    return series[-1][1]


def find_crossovers(s_pro, s_bas) -> List[Dict]:
    """在公共 execs 区间上找 protorag-baseline 差值曲线过零的位置。"""
    lo = max(s_pro[0][0], s_bas[0][0])
    hi = min(s_pro[-1][0], s_bas[-1][0])
    if hi <= lo:
        return []
    # 在公共区间上取密集网格
    n = 400
    grid = [lo + (hi - lo) * i / n for i in range(n + 1)]
    diffs = []
    for g in grid:
        c1 = interp(s_pro, g)
        c2 = interp(s_bas, g)
        diffs.append((g, None if (c1 is None or c2 is None) else c1 - c2))
    out: List[Dict] = []
    for i in range(1, len(diffs)):
        x0, d0 = diffs[i - 1]
        x1, d1 = diffs[i]
        if d0 is None or d1 is None:
            continue
        if d0 == 0:
            out.append({"execs": int(x0), "type": "zero"})
            continue
        if (d0 > 0) != (d1 > 0):
            x = x0 + (x1 - x0) * (-d0) / (d1 - d0)
            out.append({"execs": int(round(x)),
                        "from": round(d0, 4), "to": round(d1, 4),
                        "type": "sign_change"})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()
    out_root = Path(args.out_root)

    md: List[str] = []
    md.append("# RQ4 交叉点分析（crossover）：结论强烈依赖测量位置")
    md.append("")
    md.append("> 在**公共 execs 区间**上求 `bitmap_cvg(protorag) − bitmap_cvg(baseline)` 的过零点。")
    md.append("> 差值 > 0 → protorag 占优；< 0 → baseline 占优。")
    md.append("> **单次运行（n=1），无重复，无统计效力。**")
    md.append("")

    res: Dict = {}
    for proto in ["rtsp", "sip", "smtp"]:
        s_pro = load_series(out_root, proto, "protorag")
        s_bas = load_series(out_root, proto, "baseline")
        if not s_pro or not s_bas:
            continue
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        cross = find_crossovers(s_pro, s_bas)
        # 早期/中期/晚期差值
        pts = {}
        for frac, label in [(0.02, "极早期"), (0.1, "早期"), (0.25, "前 1/4"),
                            (0.5, "中点"), (0.75, "后 1/4"), (1.0, "窗口终点")]:
            t = lo + (hi - lo) * frac
            c1, c2 = interp(s_pro, t), interp(s_bas, t)
            pts[label] = {
                "execs": int(t),
                "protorag": None if c1 is None else round(c1, 4),
                "baseline": None if c2 is None else round(c2, 4),
                "diff": None if (c1 is None or c2 is None) else round(c1 - c2, 4),
            }
        n_cross = len([c for c in cross if c["type"] == "sign_change"])
        md.append(f"## {proto}")
        md.append("")
        md.append(f"公共 execs 区间：{lo} – {hi}　**交叉点个数：{n_cross}**")
        md.append("")
        if cross:
            md.append("| 交叉点 execs | 交叉前差值 | 交叉后差值 | 方向变化 |")
            md.append("|---|---|---|---|")
            for c in cross:
                d0, d1 = c.get("from"), c.get("to")
                if d0 is None or d1 is None:
                    md.append(f"| {c['execs']} | — | — | 过零 |")
                else:
                    md.append(f"| {c['execs']} | {d0:+.4f} | {d1:+.4f} | "
                              f"{'baseline→protorag' if d0 < 0 else 'protorag→baseline'} |")
            md.append("")
        md.append("| 位置 | 对齐 execs | protorag | baseline | 差值 | 占优方 |")
        md.append("|---|---|---|---|---|---|")
        for label, v in pts.items():
            d = v["diff"]
            if d is None:
                win = "—"
            elif d > 0:
                win = "protorag"
            elif d < 0:
                win = "baseline"
            else:
                win = "持平"
            md.append(f"| {label} | {v['execs']} | {v['protorag']} | {v['baseline']} | "
                      f"{'—' if d is None else f'{d:+.4f}'} | {win} |")
        md.append("")
        res[proto] = {"common_range": [lo, hi], "crossovers": cross, "phases": pts}

    md.append("---")
    md.append("")
    md.append("**解读**：")
    md.append("")
    md.append("- **RTSP**：baseline 在**极早期**领先（官方种子单个体覆盖更全），"
              "protorag 在 ~22.8k execs 处**反超**并保持领先至窗口终点 → "
              "**结论取决于测量位置**，必须同时给出「早期」与「终值」两个口径。")
    md.append("- **SMTP**：baseline **全程领先**，从未交叉 → 结论稳健。")
    md.append("- **SIP**：两者**全程基本重合**（差值在 ±0.3pp 内摆动）→ 不足以判定优劣。")

    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
