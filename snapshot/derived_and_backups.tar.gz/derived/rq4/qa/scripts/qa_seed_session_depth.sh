#!/bin/bash
# qa_seed_session_depth.sh —— 量化两组种子的「会话深度」与「长度」
# 会话深度 = 单个种子里的命令条数（SMTP/RTSP/SIP 都是请求-响应序列）
echo "=== 各协议两组种子的「每文件命令数」分布 + 字节数 ==="
for spec in "rtsp live555 in-rtsp" "sip kamailio in-sip" "smtp exim in-smtp"; do
  set -- $spec; p=$1; img=$2; ind=$3
  echo ""
  echo "##### $p"
  echo "  --- baseline（镜像自带 $ind）---"
  docker run --rm --entrypoint /bin/bash rq2-$img:latest -c "
    for f in /home/ubuntu/experiments/$ind/*; do
      [ -f \"\$f\" ] || continue
      n=\$(grep -cE '^[A-Z]{3,6}[ ]' \"\$f\" 2>/dev/null || echo 0)
      echo \"    \$(wc -c < \"\$f\") bytes, \${n} 条命令, \$(basename \"\$f\")\"
    done" 2>/dev/null | head -10
  echo "  --- protorag（宿主种子，共 $(ls /home/zxy/rq4/seeds/$p/*.raw 2>/dev/null | wc -l) 个）---"
  for f in /home/zxy/rq4/seeds/$p/*.raw; do
    [ -f "$f" ] || continue
    tr -d '\r' < "$f" | grep -cE '^[A-Z]{3,6}[ ]' 2>/dev/null || echo 0
  done | sort -n | awk '
    { a[NR]=$1; s+=$1 }
    END {
      printf "    命令条数: min=%d 中位=%d max=%d 均值=%.1f 总计=%d\n", a[1], a[int(NR/2)+1], a[NR], s/NR, s
    }'
  for f in /home/zxy/rq4/seeds/$p/*.raw; do
    [ -f "$f" ] || continue
    tr -d '\r' < "$f" | grep -cE '^[A-Z]{3,6}[ ]' 2>/dev/null || echo 0
  done | awk '{if($1<=1) c1++; t++} END{printf "    ≤1 条命令: %d/%d = %.0f%%\n", c1, t, c1/t*100}'
  echo "    字节数: min=$(stat -c '%s' /home/zxy/rq4/seeds/$p/*.raw 2>/dev/null | sort -n | head -1) 中位=$(stat -c '%s' /home/zxy/rq4/seeds/$p/*.raw 2>/dev/null | sort -n | awk '{a[NR]=$1} END{print a[int(NR/2)+1]}') max=$(stat -c '%s' /home/zxy/rq4/seeds/$p/*.raw 2>/dev/null | sort -n | tail -1)"
done
