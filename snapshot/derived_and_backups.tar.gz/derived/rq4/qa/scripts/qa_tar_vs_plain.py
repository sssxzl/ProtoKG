# -*- coding: utf-8 -*-
"""qa_tar_vs_plain.py —— 「数据未被篡改」的最终证据：从 6 个 tar.gz 解出原始产物，
与 out/ 下的明文副本做 **md5 逐一比对**，并核 command_line 与 summary 第 23 列逐字一致。

★ 为什么这是收尾证据
------------------
容器已被删除（team-lead 于 15:28-15:35 主动清理已退出容器以释放磁盘），
所以「容器内原始文件」不能再 `docker cp` 回查。
但官方 run 脚本收尾会把整个 OUTDIR 打进 ``tar -zcvf ${WORKDIR}/${OUTDIR}.tar.gz ${OUTDIR}``，
tar 里的 fuzzer_stats / cov_over_time.csv 就是**容器内的原始字节**。

因此：
  tar 内产物  ==  容器内原始产物（字节级）
  out/ 明文副本 ==  从 tar 解出的产物（如果一致，说明明文副本也未被篡改）
  command_line  ==  summary 第 23 列（参数零漂移的最终离线证据）

本脚本**不依赖容器**，纯离线，可随时复现。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROTOS = ["rtsp", "sip", "smtp"]
GROUPS = ["protorag", "baseline"]
TARGETS = ["fuzzer_stats", "cov_over_time.csv"]


def md5_bytes(b: bytes) -> str:
    return hashlib.md5(b).hexdigest()


def md5_file(p: Path) -> str:
    return md5_bytes(p.read_bytes())


def extract_from_tar(tar_path: Path, member_suffix: str) -> Optional[bytes]:
    """从 tar.gz 里取出【文件名以 member_suffix 结尾】的成员内容。"""
    try:
        with tarfile.open(tar_path, "r:gz") as tf:
            for m in tf.getmembers():
                if not m.isfile():
                    continue
                if m.name.rstrip("/").endswith(member_suffix):
                    f = tf.extractfile(m)
                    if f is None:
                        continue
                    return f.read()
    except (tarfile.TarError, OSError):
        return None
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True, help="/home/zxy/rq4/out")
    ap.add_argument("--summary", required=True, help="rq4_summary.csv")
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()

    out_root = Path(args.out_root)
    rows = list(csv.DictReader(open(args.summary, encoding="utf-8-sig")))

    result: Dict = {"rows": [], "all_ok": True}
    md: List[str] = []
    md.append("# RQ4 数据未被篡改的最终证据（离线核验，容器已清理）")
    md.append("")
    md.append("> 容器已被删除，无法再回查容器内文件；但官方 run 脚本收尾把整个 OUTDIR 打进")
    md.append("> `tar -zcvf ${WORKDIR}/${OUTDIR}.tar.gz ${OUTDIR}` → **tar 内的产物就是容器内的原始字节**。")
    md.append("> 故本表核验：① tar 内产物 ↔ `out/` 明文副本 逐字节一致；"
              "② `command_line` ↔ summary 第 23 列逐字一致。")
    md.append("")
    md.append("| 协议 | 组 | tar.gz | 产物 | tar 内 md5 | out/ 明文 md5 | 一致？ |")
    md.append("|---|---|---|---|---|---|---|")

    for r in rows:
        proto, grp = r["protocol"], r["group"]
        d = out_root / proto / grp / "r1"
        tar_path = d / "out.tar.gz"
        entry = {"protocol": proto, "group": grp,
                 "container": r.get("container", ""),
                 "tar_exists": tar_path.is_file(), "files": {}}
        if not tar_path.is_file():
            entry["error"] = "tar.gz 不存在"
            result["all_ok"] = False
            result["rows"].append(entry)
            md.append(f"| {proto} | {grp} | ✗ 缺失 | — | — | — | **✗** |")
            continue
        for fname in TARGETS:
            tar_bytes = extract_from_tar(tar_path, fname)
            plain_path = d / fname
            if tar_bytes is None:
                entry["files"][fname] = {"status": "tar 内未找到"}
                result["all_ok"] = False
                md.append(f"| {proto} | {grp} | ✓ | `{fname}` | ✗ 未找到 | — | **✗** |")
                continue
            if not plain_path.is_file():
                entry["files"][fname] = {"status": "明文副本缺失"}
                result["all_ok"] = False
                md.append(f"| {proto} | {grp} | ✓ | `{fname}` | {md5_bytes(tar_bytes)[:8]} | ✗ 缺失 | **✗** |")
                continue
            m_tar = md5_bytes(tar_bytes)
            m_plain = md5_file(plain_path)
            same = (m_tar == m_plain)
            entry["files"][fname] = {
                "tar_md5": m_tar, "plain_md5": m_plain, "identical": same,
                "size": len(tar_bytes),
            }
            if not same:
                result["all_ok"] = False
            md.append(f"| {proto} | {grp} | ✓ | `{fname}` | `{m_tar[:12]}` | `{m_plain[:12]}` | "
                      f"{'✓ 一致' if same else '**✗ 不一致**'} |")
        # command_line 核对
        tar_stats = extract_from_tar(tar_path, "fuzzer_stats")
        if tar_stats is not None:
            m = re.search(rb"^command_line\s*:\s*(.*?)\s*$", tar_stats, re.MULTILINE)
            tar_cmd = m.group(1).decode("utf-8", "replace") if m else ""
            sum_cmd = (r.get("command_line") or "").strip()
            same_cmd = (tar_cmd == sum_cmd)
            entry["command_line_identical"] = same_cmd
            entry["command_line"] = tar_cmd
            if not same_cmd:
                result["all_ok"] = False
            md.append(f"| {proto} | {grp} | ✓ | `command_line` | "
                      f"{(tar_cmd[:40] + '…') if tar_cmd else '—'} | "
                      f"{(sum_cmd[:40] + '…') if sum_cmd else '—'} | "
                      f"{'✓ 逐字一致' if same_cmd else '**✗ 不一致**'} |")
        result["rows"].append(entry)

    md.append("")
    md.append("## 结论")
    md.append("")
    if result["all_ok"]:
        md.append("**全部一致** —— 6 个 tar.gz 内的原始产物与 `out/` 明文副本**逐字节相同**，"
                  "`command_line` 与 `rq4_summary.csv` 第 23 列**逐字一致**。")
        md.append("")
        md.append("→ **数据链完整、产物未被篡改**。容器已删除不影响任何结论的可回查性：")
        md.append("所有分析字段（`bitmap_cvg` / `execs_done` / `paths_*` / `l_per` / `b_per` / "
                  "`command_line`）都同时存在于 `out/` 明文副本与 tar.gz 原始产物中。")
    else:
        md.append("**存在不一致** —— 需进一步排查。")
    result["all_ok"] = result["all_ok"]

    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(result, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0 if result["all_ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
