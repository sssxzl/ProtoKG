# -*- coding: utf-8 -*-
"""qa_rq4_verify2.py —— RQ4 独立复核（增强版）：加入「种子数量效应」量化。

本脚本**不 import rq4_analyze.py**，全部关键计算独立重写，然后与 rq4_analyze.py 的
输出做逐点比对。

新增能力（相对 qa_rq4_verify.py）：
  1. **种子数量效应量化**：
     · seed_head_start  = 各组在**窗口起点**处的 bitmap_cvg 差
       → 这部分是「种子语料本身带来的初始覆盖」，execs_done 对齐**剥离不掉**
     · fuzz_gain        = 窗口终点 - 窗口起点 的覆盖增量（两组各自）
       → 这部分是「模糊测试过程带来的增量」，剥离了种子头部的初始优势
     · aligned_diff     = 对齐点差值（rq4_analyze.py 的主口径）
     · final_diff       = 3h 终值差（不按 execs 对齐）
  2. **对齐窗口合法性**：验证窗口 = 两组 execs 序列的公共重叠区间
     （不是某组的私有区间），并报告窗口被谁限制。
  3. **逐点比对** rq4_analyze.py 的对齐表。
  4. **两个口径同向性**判定（终值 vs 对齐）。

用法:
    python3 qa_rq4_verify2.py --out-root DIR --summary CSV [--analyze-md MD] [--json-out J]
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROTO_TABLE: Dict[str, Dict[str, str]] = {
    "rtsp": {
        "net": "tcp://127.0.0.1/8554",
        "options": "-P RTSP -D 10000 -q 3 -s 3 -E -K -R -m none -t 5000",
    },
    "sip": {
        "net": "udp://127.0.0.1/5060",
        "options": "-m none -P SIP -l 5061 -D 50000 -q 3 -s 3 -E -K -t 5000",
    },
    "smtp": {
        "net": "tcp://127.0.0.1/25",
        "options": "-P SMTP -D 10000 -q 3 -s 3 -E -K -W 100 -m none -t 5000",
    },
}
GROUPS = ("protorag", "baseline")
FRACS = (0.25, 0.5, 0.75, 1.0)


def _field(text: str, key: str) -> str:
    m = re.search(r"^" + re.escape(key) + r"\s*:\s*(.*?)\s*$", text, re.MULTILINE)
    return m.group(1) if m else ""


def _num(raw: str) -> Optional[float]:
    s = raw.strip().replace("%", "").replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def load_series(out_root: Path, proto: str, group: str, rep: int
                ) -> List[Tuple[int, float]]:
    """读快照序列 → [(execs_done, bitmap_cvg)]（按 execs 升序、同 execs 去重）。

    去重规则：同 execs_done 保留**最后一次**快照的 cov（后一次读数更完整）。
    ★ 已验证：所有重复 execs 组内的 cov 值完全一致 → 去重与否**不影响**插值结果。
    """
    d = out_root / proto / group / f"r{rep}"
    if not d.is_dir():
        return []
    raw: List[Tuple[int, float, int]] = []
    for snap in d.glob("stats_*.txt"):
        try:
            ts = int(snap.stem.split("_")[-1])
        except ValueError:
            continue
        try:
            text = snap.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ex = _num(_field(text, "execs_done"))
        cov = _num(_field(text, "bitmap_cvg"))
        if ex is None or cov is None:
            continue
        raw.append((int(ex), cov, ts))
    raw.sort(key=lambda x: (x[0], x[2]))
    dedup: Dict[int, float] = {}
    for ex, cov, _ts in raw:
        dedup[ex] = cov
    return sorted(dedup.items())


def interp(series: List[Tuple[int, float]], target: int) -> Optional[float]:
    """线性插值；超界取端点。"""
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    for (x0, y0), (x1, y1) in zip(series, series[1:]):
        if x0 <= target <= x1:
            if x1 == x0:
                return y0
            return y0 + (y1 - y0) * (target - x0) / (x1 - x0)
    return series[-1][1]


def interp_binary(series: List[Tuple[int, float]], target: int) -> Optional[float]:
    """二分查找版插值（与线性扫描版互为交叉校验）。"""
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    lo, hi = 0, len(series) - 1
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if series[mid][0] <= target:
            lo = mid
        else:
            hi = mid
    x0, y0 = series[lo]
    x1, y1 = series[lo + 1]
    if x1 == x0:
        return y0
    return y0 + (y1 - y0) * (target - x0) / (x1 - x0)


def check_params(options: str, net: str, command_line: str) -> Dict:
    """独立实现的逐 token 全等复核（不调用 rq4_param_check.py）。"""
    expected = options.split()
    tokens = command_line.split()
    out: Dict = {"expected_options": options, "net": net,
                 "command_line": command_line}
    if not command_line.strip():
        out["verdict"] = "NO_COMMAND_LINE"
        return out
    anchor = -1
    for i, t in enumerate(tokens):
        if t == "-N" and i + 1 < len(tokens) and tokens[i + 1] == net:
            anchor = i
            break
    if anchor < 0:
        out["verdict"] = "MISMATCH"
        out["reason"] = "找不到 '-N <net>' 锚点"
        return out
    start = anchor + 2
    end = start + len(expected)
    if end > len(tokens):
        out["verdict"] = "MISMATCH"
        out["reason"] = f"OPTIONS 段提前结束（需 {len(expected)} token）"
        return out
    actual = tokens[start:end]
    out["actual_options_tokens"] = actual
    out["token_by_token"] = [
        {"idx": i + 1, "expected": e, "actual": a, "equal": e == a}
        for i, (e, a) in enumerate(zip(expected, actual))
    ]
    if actual != expected:
        out["verdict"] = "MISMATCH"
        out["reason"] = "; ".join(
            f"第 {t['idx']} token：期望 '{t['expected']}' 实际 '{t['actual']}'"
            for t in out["token_by_token"] if not t["equal"])
        return out
    if end >= len(tokens):
        out["verdict"] = "MISMATCH"
        out["reason"] = "OPTIONS 之后缺少服务端命令"
        return out
    tail = tokens[end]
    out["tail_token"] = tail
    if tail.startswith("-"):
        if tail not in ("-c", "--"):
            out["verdict"] = "MISMATCH"
            out["reason"] = f"OPTIONS 段尾部多出选项 '{tail}'"
            return out
        if tail == "-c" and (end + 1 >= len(tokens) or "/" not in tokens[end + 1]):
            out["verdict"] = "MISMATCH"
            out["reason"] = "'-c' 之后缺少服务端脚本路径"
            return out
    out["verdict"] = "OK"
    out["reason"] = "逐 token 全等"
    return out


def mask_outdir(command_line: str) -> str:
    tokens = command_line.split()
    out: List[str] = []
    skip = False
    for t in tokens:
        if skip:
            out.append("<OUTDIR>")
            skip = False
            continue
        out.append(t)
        if t == "-o":
            skip = True
    return " ".join(out)


def load_summary(path: Path) -> List[Dict]:
    rows: List[Dict] = []
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        for raw in csv.DictReader(fh):
            rows.append({(k or "").strip(): (v if v is not None else "")
                         for k, v in raw.items()})
    return rows


MD_ROW_RE = re.compile(
    r"^\|\s*(rtsp|sip|smtp)\s*\|\s*(\d+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*"
    r"\|\s*([+\-][\d.]+)\s*\|\s*$")


def parse_analyze_md(md_path: Path) -> Dict[str, Dict[int, Tuple[float, float, float]]]:
    out: Dict[str, Dict[int, Tuple[float, float, float]]] = {}
    if not md_path.exists():
        return out
    in_sec = False
    for line in md_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("## ") and "execs_done" in line:
            in_sec = True
            continue
        if in_sec and line.startswith("## "):
            break
        if not in_sec:
            continue
        m = MD_ROW_RE.match(line.strip())
        if m:
            proto, target, c1, c2, diff = m.groups()
            out.setdefault(proto, {})[int(target)] = (float(c1), float(c2), float(diff))
    return out


def parse_md_table(md_path: Path) -> Dict[str, Dict[str, Dict[str, float]]]:
    """解析主对比表 → {proto: {group: {label: value}}}。"""
    out: Dict[str, Dict[str, Dict[str, float]]] = {}
    if not md_path.exists():
        return out
    proto = None
    groups: List[str] = []
    in_table = False
    for line in md_path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if s.startswith("### ") and s[4:] in PROTO_TABLE:
            proto = s[4:]
            groups = []
            in_table = False
            continue
        if proto is None:
            continue
        if s.startswith("| 指标 |"):
            groups = [c.strip().split(" ")[0] for c in s.strip("|").split("|")][1:]
            in_table = True
            continue
        if in_table:
            if not s.startswith("|"):
                in_table = False
                continue
            if set(s) <= set("|- "):
                continue
            cells = [c.strip() for c in s.strip("|").split("|")]
            if len(cells) < 1 + len(groups):
                continue
            for g, v in zip(groups, cells[1:]):
                try:
                    out.setdefault(proto, {}).setdefault(g, {})[cells[0]] = float(v)
                except ValueError:
                    pass
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", default="/home/zxy/rq4/out")
    ap.add_argument("--summary", default="/home/zxy/rq4/rq4_summary.csv")
    ap.add_argument("--analyze-md", default="")
    ap.add_argument("--json-out", default="")
    args = ap.parse_args()

    out_root = Path(args.out_root)
    rows = load_summary(Path(args.summary))
    by_key = {(r.get("protocol", ""), r.get("group", ""),
               int(r.get("rep") or 0)): r for r in rows}

    rep: Dict = {
        "summary_file": str(args.summary),
        "summary_rows": len(rows),
        "params": {},
        "param_consistency_across_containers": {},
        "series_diag": {},
        "windows": {},
        "aligned": {},
        "seed_effect": {},
        "terminal": {},
        "analyze_cross_check": {},
        "anomalies": [],
    }

    # ---------- A. 参数 ----------
    for r in rows:
        proto = r.get("protocol", "")
        spec = PROTO_TABLE.get(proto)
        if spec is None:
            rep["anomalies"].append(f"未知协议 {proto}")
            continue
        res = check_params(spec["options"], spec["net"], r.get("command_line", ""))
        res["container"] = r.get("container", "")
        res["csv_param_check_column"] = r.get("param_check", "")
        res["independent_matches_csv"] = (res["verdict"] == r.get("param_check", ""))
        rep["params"][r.get("container", "")] = res

    for proto in sorted({k[0] for k in by_key}):
        masked = {r.get("container", ""): mask_outdir(r.get("command_line", ""))
                  for (p, _g, _rep), r in by_key.items() if p == proto}
        rep["param_consistency_across_containers"][proto] = {
            "masked": masked,
            "consistent": len(set(masked.values())) == 1,
            "distinct": len(set(masked.values())),
        }

    # ---------- B/C/D. 序列 / 窗口 / 对齐 ----------
    for proto in sorted({k[0] for k in by_key}):
        s_pro = load_series(out_root, proto, "protorag", 1)
        s_bas = load_series(out_root, proto, "baseline", 1)
        for gname, s in (("protorag", s_pro), ("baseline", s_bas)):
            if not s:
                rep["series_diag"][f"{proto}/{gname}"] = {"n": 0}
                continue
            drops = [(s[i - 1][0], s[i - 1][1], s[i][0], s[i][1])
                     for i in range(1, len(s)) if s[i][1] < s[i - 1][1] - 1e-9]
            rep["series_diag"][f"{proto}/{gname}"] = {
                "n": len(s),
                "execs_min": s[0][0], "execs_max": s[-1][0],
                "cov_first": s[0][1], "cov_last": s[-1][1],
                "cov_max": max(p[1] for p in s),
                "monotonic_non_decreasing": not drops,
                "n_drops": len(drops),
            }
        if not s_pro or not s_bas:
            rep["windows"][proto] = {"error": "缺少快照"}
            continue
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        win = {
            "protorag_execs_range": [s_pro[0][0], s_pro[-1][0]],
            "baseline_execs_range": [s_bas[0][0], s_bas[-1][0]],
            "common_start_execs": lo,
            "common_end_execs": hi,
            "common_span_execs": hi - lo,
            "is_public_overlap": (
                lo >= s_pro[0][0] and lo >= s_bas[0][0]
                and hi <= s_pro[-1][0] and hi <= s_bas[-1][0]),
            "limited_by": ("protorag" if hi == s_pro[-1][0] and hi < s_bas[-1][0]
                           else ("baseline" if hi == s_bas[-1][0] and hi < s_pro[-1][0]
                                 else "both_equal")),
            "start_limited_by": ("protorag" if lo == s_pro[0][0] and lo > s_bas[0][0]
                                 else ("baseline" if lo == s_bas[0][0] and lo > s_pro[0][0]
                                       else "both_equal")),
        }
        rep["windows"][proto] = win
        if hi <= lo:
            win["error"] = "无公共重叠窗口"
            continue
        aligned: Dict[str, Dict] = {}
        for frac in FRACS:
            target = int(lo + (hi - lo) * frac)
            c1 = interp(s_pro, target)
            c1b = interp_binary(s_pro, target)
            c2 = interp(s_bas, target)
            c2b = interp_binary(s_bas, target)
            aligned[str(target)] = {
                "frac": frac, "target": target,
                "protorag": None if c1 is None else round(c1, 6),
                "baseline": None if c2 is None else round(c2, 6),
                "diff": None if (c1 is None or c2 is None) else round(c1 - c2, 6),
                "two_interp_impls_agree": (
                    (c1 is not None and c1b is not None and abs(c1 - c1b) < 1e-9)
                    and (c2 is not None and c2b is not None and abs(c2 - c2b) < 1e-9)),
            }
        rep["aligned"][proto] = aligned

        # ---------- 种子数量效应量化 ----------
        cov_pro_at_lo = interp(s_pro, lo)
        cov_bas_at_lo = interp(s_bas, lo)
        cov_pro_at_hi = interp(s_pro, hi)
        cov_bas_at_hi = interp(s_bas, hi)
        row_pro = by_key.get((proto, "protorag", 1), {})
        row_bas = by_key.get((proto, "baseline", 1), {})
        sf_pro = _num(row_pro.get("seed_files", ""))
        sf_bas = _num(row_bas.get("seed_files", ""))
        rep["seed_effect"][proto] = {
            "seed_files_protorag": sf_pro,
            "seed_files_baseline": sf_bas,
            "seed_count_ratio": (round(sf_pro / sf_bas, 2)
                                  if sf_pro and sf_bas else None),
            "window_start_execs": lo,
            "cov_at_window_start_protorag": None if cov_pro_at_lo is None else round(cov_pro_at_lo, 4),
            "cov_at_window_start_baseline": None if cov_bas_at_lo is None else round(cov_bas_at_lo, 4),
            "seed_head_start_diff": (
                None if (cov_pro_at_lo is None or cov_bas_at_lo is None)
                else round(cov_pro_at_lo - cov_bas_at_lo, 4)),
            "cov_at_window_end_protorag": None if cov_pro_at_hi is None else round(cov_pro_at_hi, 4),
            "cov_at_window_end_baseline": None if cov_bas_at_hi is None else round(cov_bas_at_hi, 4),
            "fuzz_gain_protorag": (
                None if (cov_pro_at_hi is None or cov_pro_at_lo is None)
                else round(cov_pro_at_hi - cov_pro_at_lo, 4)),
            "fuzz_gain_baseline": (
                None if (cov_bas_at_hi is None or cov_bas_at_lo is None)
                else round(cov_bas_at_hi - cov_bas_at_lo, 4)),
            "fuzz_gain_diff": (
                None if (cov_pro_at_hi is None or cov_pro_at_lo is None
                         or cov_bas_at_hi is None or cov_bas_at_lo is None)
                else round((cov_pro_at_hi - cov_pro_at_lo) - (cov_bas_at_hi - cov_bas_at_lo), 4)),
            "aligned_diff_at_window_end": aligned.get(str(hi), {}).get("diff"),
        }

    # ---------- E. 终值 vs 对齐（两个口径）----------
    for proto in sorted({k[0] for k in by_key}):
        e: Dict = {}
        for g in GROUPS:
            r = by_key.get((proto, g, 1))
            if r is None:
                continue
            e[g] = {
                "container": r.get("container", ""),
                "bitmap_cvg_final": _num(r.get("bitmap_cvg", "")),
                "execs_done_final": _num(r.get("execs_done", "")),
                "execs_per_sec": _num(r.get("execs_per_sec", "")),
                "fuzz_sec": _num(r.get("fuzz_sec", "")),
                "paths_total": _num(r.get("paths_total", "")),
                "paths_found": _num(r.get("paths_found", "")),
                "max_depth": _num(r.get("max_depth", "")),
                "stability": _num(r.get("stability", "")),
                "unique_crashes": _num(r.get("unique_crashes", "")),
                "unique_hangs": _num(r.get("unique_hangs", "")),
                "l_per": _num(r.get("l_per", "")),
                "b_per": _num(r.get("b_per", "")),
                "seed_files": _num(r.get("seed_files", "")),
                "seed_regions": _num(r.get("seed_regions", "")),
                "dict_tokens": _num(r.get("dict_tokens", "")),
            }
        d_final = None
        if e.get("protorag") and e.get("baseline"):
            a = e["protorag"]["bitmap_cvg_final"]
            b = e["baseline"]["bitmap_cvg_final"]
            if a is not None and b is not None:
                d_final = round(a - b, 4)
        win = rep["windows"].get(proto, {})
        hi = win.get("common_end_execs")
        d_align = None
        if hi is not None:
            d_align = rep["aligned"].get(proto, {}).get(str(hi), {}).get("diff")
        d_lp = None
        if e.get("protorag") and e.get("baseline"):
            a = e["protorag"]["l_per"]
            b = e["baseline"]["l_per"]
            if a is not None and b is not None:
                d_lp = round(a - b, 4)
        same = None
        if d_final is not None and d_align is not None:
            same = (d_final == 0 or d_align == 0 or (d_final > 0) == (d_align > 0))
        e["delta_final_bitmap_cvg"] = d_final
        e["delta_aligned_bitmap_cvg_at_common_end"] = d_align
        e["two_criteria_same_direction"] = same
        e["delta_l_per"] = d_lp
        e["bitmap_cvg_vs_l_per_same_direction"] = (
            None if (d_final is None or d_lp is None)
            else (d_final == 0 or d_lp == 0 or (d_final > 0) == (d_lp > 0)))
        rep["terminal"][proto] = e

    # ---------- F. 与 rq4_analyze.py 逐点比对 ----------
    if args.analyze_md:
        md = Path(args.analyze_md)
        md_aligned = parse_analyze_md(md)
        xc: Dict = {"md_file": str(md), "points": {}}
        n_pts = n_ok = 0
        worst = 0.0
        for proto, pts in md_aligned.items():
            mine = rep["aligned"].get(proto, {})
            per: Dict = {}
            for target, (c1, c2, diff) in sorted(pts.items()):
                m = mine.get(str(target))
                if m is None:
                    per[str(target)] = {"status": "MISSING_IN_MINE"}
                    continue
                dmax = max(abs(m["protorag"] - c1), abs(m["baseline"] - c2),
                           abs(m["diff"] - diff))
                ok = dmax <= 0.005 + 1e-9
                per[str(target)] = {
                    "mine": [m["protorag"], m["baseline"], m["diff"]],
                    "theirs": [c1, c2, diff],
                    "abs_delta": [round(abs(m["protorag"] - c1), 6),
                                  round(abs(m["baseline"] - c2), 6),
                                  round(abs(m["diff"] - diff), 6)],
                    "match": ok,
                }
                worst = max(worst, dmax)
                n_pts += 1
                n_ok += 1 if ok else 0
            xc["points"][proto] = per
        xc["points_compared"] = n_pts
        xc["points_matched"] = n_ok
        xc["max_abs_delta"] = round(worst, 6)
        xc["all_match"] = (n_pts > 0 and n_ok == n_pts)
        xc["md_main_table"] = parse_md_table(md)
        rep["analyze_cross_check"] = xc

    text = json.dumps(rep, ensure_ascii=False, indent=2)
    if args.json_out:
        p = Path(args.json_out)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        print(f"[qa2] JSON 写出: {p}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
