#!/bin/bash
for c in rq4_smtp_protorag_r1 rq4_sip_protorag_r1; do
  echo "--- $c 的 ERROR 行"
  docker logs "$c" 2>&1 | grep -iE 'PFATAL|FATAL|ERROR:' | head -6
  echo ""
done
