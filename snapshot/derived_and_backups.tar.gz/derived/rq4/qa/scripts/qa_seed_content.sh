#!/bin/bash
echo "=== SMTP 两组种子的「命令构成」对比（官方 seed 只有 2 个，ProtoRAG 有 78 个）==="
echo ""
echo "--- baseline（镜像自带 in-smtp，2 个文件）---"
docker run --rm --entrypoint /bin/bash rq2-exim:latest -c 'ls -la /home/ubuntu/experiments/in-smtp/; for f in /home/ubuntu/experiments/in-smtp/*.raw; do echo "  == $f ($(wc -c < $f) bytes)"; head -c 300 "$f" | tr -d "\r" | sed "s/^/     /"; echo; done' 2>/dev/null
echo ""
echo "--- protorag（宿主种子，78 个文件）---"
ls -la /home/zxy/rq4/seeds/smtp/ | head -6
echo "  ... 共 $(ls /home/zxy/rq4/seeds/smtp/*.raw 2>/dev/null | wc -l) 个 .raw"
echo ""
echo "--- protorag 全部 78 个种子的首行（命令）统计 ---"
for f in /home/zxy/rq4/seeds/smtp/*.raw; do head -1 "$f" 2>/dev/null | tr -d '\r'; done | sed 's/ .*//' | sort | uniq -c | sort -rn
echo ""
echo "--- protorag 前 3 个种子内容样本 ---"
for f in $(ls /home/zxy/rq4/seeds/smtp/*.raw | head -3); do echo "  == $f ($(wc -c < $f) bytes)"; head -c 260 "$f" | tr -d '\r' | sed 's/^/     /'; echo; done
