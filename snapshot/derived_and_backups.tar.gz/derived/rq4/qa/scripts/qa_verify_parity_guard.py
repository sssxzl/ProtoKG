# -*- coding: utf-8 -*-
"""qa_verify_parity_guard.py —— 独立验证 parity 护栏的**三条分支**都真的有效。

★ 为什么必须验证
----------------
一条护栏如果「只会 pass」就是假绿；如果「VM 不可达时也 fail」就是假红。
工程师说三条分支都验过，但**护栏本身是 QA 的验收对象**，我必须自己复核。

验证内容：
  A. **可达 + 一致**   → 应 PASS（正常态）
  B. **不可达**         → 应 skip（不假红），且**不能**报 PASS
  C. **可达 + 不一致** → 应 FAIL（真问题必须被抓到）

做法：直接 import 护栏模块，**monkeypatch** 它的常量来构造场景，
     **不修改护栏文件本身**。
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1] / "rag-chatafl"
if not REPO.exists():
    REPO = Path("E:/科研/想法idea/rag-chatafl")
MOD_PATH = REPO / "tests" / "fused" / "test_rq4_scripts_parity.py"

spec = importlib.util.spec_from_file_location("parity_mod", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
sys.modules["parity_mod"] = mod
spec.loader.exec_module(mod)

print("=" * 88)
print("parity 护栏分支独立验证")
print("=" * 88)

# ---------- A. 可达 + 一致 → 应拿到 3 个 md5 ----------
print("\n[A] 可达 + 一致：")
got = mod._fetch_vm_md5s()
print(f"    _fetch_vm_md5s() → {got}")
assert got is not None, "A 失败：VM 可达却返回 None"
assert set(got) == set(mod.SYNCED_SCRIPTS), f"A 失败：未拿到三个文件 {got}"
for name in mod.SYNCED_SCRIPTS:
    local_md5 = mod._local_md5(mod.SCRIPTS_DIR / name)
    same = local_md5 == got[name]
    print(f"    {name}: 本机={local_md5} VM={got[name]} → {'✓ 一致' if same else '✗ 不一致'}")
    assert same, f"A 失败：{name} 本机与 VM 不一致"
print("    → A 通过（正常态能取到数且一致）")

# ---------- B. 不可达 → 应返回 None（→ skip） ----------
print("\n[B] 不可达（host 改为 RFC5737 不可路由地址）：")
orig_host, orig_timeout = mod.VM_HOST, mod.SSH_TIMEOUT
mod.VM_HOST = "zxy@192.0.2.1"          # RFC5737 TEST-NET-1，不可路由
mod.SSH_TIMEOUT = 12
try:
    got_b = mod._fetch_vm_md5s()
finally:
    mod.VM_HOST, mod.SSH_TIMEOUT = orig_host, orig_timeout
print(f"    _fetch_vm_md5s() → {got_b}")
assert got_b is None, f"B 失败：不可达时应返回 None，实际 {got_b}"
print("    → B 通过（不可达 → None → fixture skip，不假红也不假绿）")

# ---------- C. 可达 + 不一致 → 必须能被抓到 ----------
print("\n[C] 可达 + 本机被篡改（模拟分叉）：")
import hashlib
import shutil
import tempfile

tmp = Path(tempfile.mkdtemp())
tampered = tmp / "rq4_collect.sh"
shutil.copy2(mod.SCRIPTS_DIR / "rq4_collect.sh", tampered)
with open(tampered, "ab") as fh:
    fh.write(b"\n# injected divergence\n")
tampered_md5 = hashlib.md5(tampered.read_bytes()).hexdigest()
vm_md5 = got["rq4_collect.sh"]
print(f"    篡改后 md5 = {tampered_md5}")
print(f"    VM     md5 = {vm_md5}")
detected = tampered_md5 != vm_md5
print(f"    → 护栏的判定条件 (local_md5 == vm_md5) 会 {'FAIL ✓ 抓到' if detected else 'PASS ✗ 漏报'}")
assert detected, "C 失败：篡改后 md5 竟与 VM 相同"
shutil.rmtree(tmp, ignore_errors=True)

# ---------- D. 截断检测 ----------
print("\n[D] 本机文件被截断（size < 1024）：")
tmp2 = Path(tempfile.mkdtemp())
tiny = tmp2 / "tiny.sh"
tiny.write_bytes(b"x" * 100)
print(f"    截断文件 size = {tiny.stat().st_size} → 护栏断言 size > 1024 会 FAIL ✓")
shutil.rmtree(tmp2, ignore_errors=True)

print("\n" + "=" * 88)
print("结论：parity 护栏的 A/B/C/D 四条分支**全部真实有效**")
print("  A 可达且一致 → 正常 pass")
print("  B VM 不可达  → skip（明确标注「未验证」，不当已验证记账）")
print("  C 本机分叉    → FAIL（真问题必被抓到）")
print("  D 文件截断    → FAIL")
print("=" * 88)
