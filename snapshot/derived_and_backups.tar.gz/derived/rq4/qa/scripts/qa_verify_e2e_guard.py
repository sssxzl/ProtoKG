# -*- coding: utf-8 -*-
"""qa_verify_e2e_guard.py —— 独立验证工程师新增的**端到端护栏**是否真能抓住路径 bug。

★ 背景
------
工程师自述：他第一版护栏只测**函数/源码形态**，变异（改回相对 out_root 路径）只红 2 条，
而真正能抓住的端到端用例是后补的 `test_production_script_generates_manifest_that_passes_md5sum_check`。
自述变异结果：3 failed（含新增这条）。

★ 本脚本**独立复核**两件事
------------------------
1. 该端到端护栏在**注入相对路径 bug** 后是否**真的红**（不能只看源码形态）
2. **合成 fixture 那条**（`test_manifest_paths_are_absolute_and_portable`）是否如工程师所说
   **抓不住**（即它确有缺口）—— 这一条要验证「护栏有缺口」这个判断本身是否成立

★ 手法
----
直接改**生产脚本** `scripts/rq4_collect.sh` 的清单路径生成（相对 out_root → 相对清单目录），
分别跑两个用例，看各自是否红。改完**原样还原**（copy2 保留 mtime）。
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1] / "rag-chatafl"
if not REPO.exists():
    REPO = Path("E:/科研/想法idea/rag-chatafl")
COLLECT = REPO / "scripts" / "rq4_collect.sh"
TESTFILE = REPO / "tests" / "fused" / "test_rq4_artifact_manifest.py"

# 相对 out_root 的 buggy 写法（原事故形态）
BUGGY = 'printf \'%s  %s\\n\' "$(md5sum "$f" 2>/dev/null | cut -d\' \' -f1)" "$rel_base/$(basename "$f")"'
# 相对【清单所在目录】的写法（另一版 buggy）
BUGGY2 = 'printf \'%s  %s\\n\' "$(md5sum "$f" 2>/dev/null | cut -d\' \' -f1)" "$(basename "$f")"'


def run_tests(k: str = "") -> tuple[int, list[str]]:
    cmd = [sys.executable, "-m", "pytest", str(TESTFILE), "-q", "-p", "no:cacheprovider"]
    if k:
        cmd += ["-k", k]
    r = subprocess.run(cmd, cwd=str(REPO), capture_output=True, text=True,
                       errors="replace", timeout=600)
    failed = [l.split("::")[-1].split(" ")[0]
              for l in r.stdout.splitlines() if l.startswith("FAILED")]
    return r.returncode, failed


def main() -> int:
    src = COLLECT.read_text(encoding="utf-8")
    tmpdir = Path(tempfile.mkdtemp())
    backup = tmpdir / "collect.bak"
    shutil.copy2(COLLECT, backup)

    print("=" * 92)
    print("独立验证：工程师新增的端到端护栏能否抓住「清单路径写错」")
    print("=" * 92)

    # 找到当前（绝对路径）的写法
    lines = src.splitlines()
    cur_idx = None
    for i, l in enumerate(lines):
        if "printf '%s  %s\\n'" in l and "md5sum" in l:
            cur_idx = i
            break
    if cur_idx is None:
        print("!! 找不到清单路径生成语句")
        return 1
    print(f"\n当前实现（第 {cur_idx+1} 行）:")
    print(f"  {lines[cur_idx].strip()}")

    try:
        # ---- 变异 1：改回【相对 out_root】（原事故形态）----
        buggy_src = src.replace(lines[cur_idx], BUGGY)
        assert buggy_src != src, "★ 变异 1 失败：未能替换"
        COLLECT.write_text(buggy_src, encoding="utf-8")
        print(f"\n[变异 1] 改回【相对 out_root】: {BUGGY[:80]}...")
        rc, failed = run_tests()
        e2e = [f for f in failed if "production_script_generates_manifest" in f]
        synth = [f for f in failed if "paths_are_absolute_and_portable" in f]
        print(f"  全文件结果: rc={rc}  失败 {len(failed)} 条")
        print(f"    · 端到端护栏 (production_script_generates_manifest): "
              f"{'★ 红了 ✓ 抓到了' if e2e else '没红 ✗'}")
        print(f"    · 合成 fixture 护栏 (paths_are_absolute_and_portable): "
              f"{'红了' if synth else '没红（符合工程师所述的缺口）'}")
        mut1_e2e = bool(e2e)
        mut1_synth = bool(synth)

        # ---- 变异 2：改成【相对清单所在目录】----
        buggy2_src = src.replace(lines[cur_idx], BUGGY2)
        assert buggy2_src != src, "★ 变异 2 失败：未能替换"
        COLLECT.write_text(buggy2_src, encoding="utf-8")
        print(f"\n[变异 2] 改成【相对清单目录】: {BUGGY2[:80]}...")
        rc2, failed2 = run_tests()
        e2e2 = [f for f in failed2 if "production_script_generates_manifest" in f]
        print(f"  全文件结果: rc={rc2}  失败 {len(failed2)} 条")
        print(f"    · 端到端护栏: {'★ 红了 ✓ 抓到了' if e2e2 else '没红 ✗'}")
        mut2_e2e = bool(e2e2)

        # ---- 还原后必须全绿 ----
        shutil.copy2(backup, COLLECT)
        rc3, failed3 = run_tests()
        print(f"\n[还原] rc={rc3}  失败 {len(failed3)} 条 → "
              f"{'✓ 全绿' if rc3 == 0 else '✗ 仍有失败'}")

    finally:
        shutil.copy2(backup, COLLECT)
        shutil.rmtree(tmpdir, ignore_errors=True)
        print("已还原生产脚本")

    print("\n" + "=" * 92)
    print("结论：")
    print(f"  · 端到端护栏能抓住【相对 out_root】bug : {'✓ 是' if mut1_e2e else '✗ 否'}")
    print(f"  · 端到端护栏能抓住【相对清单目录】bug   : {'✓ 是' if mut2_e2e else '✗ 否'}")
    print(f"  · 合成 fixture 护栏抓不住【相对 out_root】: "
          f"{'确认有缺口（工程师判断成立）' if not mut1_synth else '能抓住（工程师判断需修正）'}")
    print("=" * 92)
    ok = mut1_e2e and mut2_e2e and rc3 == 0
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
