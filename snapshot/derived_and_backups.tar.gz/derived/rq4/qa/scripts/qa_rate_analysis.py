import re, pathlib
root = pathlib.Path('/home/zxy/rq4/out')

def parse(p):
    t = p.read_text(errors='replace'); o = {}
    for k in ['execs_done', 'bitmap_cvg', 'start_time', 'paths_total',
              'pending_favs', 'pending_total', 'variable_paths', 'execs_per_sec']:
        m = re.search(r'^' + k + r'\s*:\s*(.*?)\s*$', t, re.M)
        o[k] = m.group(1) if m else ''
    return o

for proto in ['rtsp', 'sip', 'smtp']:
    print('=' * 104)
    print(f'### {proto} —— 分段速率分析（挂钟 0→3h，分 6 段）')
    print('=' * 104)
    for grp in ['protorag', 'baseline']:
        d = root / proto / grp / 'r1'
        snaps = sorted(d.glob('stats_*.txt'))
        if not snaps:
            continue
        st = int(parse(snaps[0])['start_time'] or 0)
        if not st:
            # 从最后一个快照取 start_time
            for s in reversed(snaps):
                v = parse(s)['start_time']
                if v:
                    st = int(v); break
        pts = {}
        for s in snaps:
            o = parse(s); ts = int(s.stem.split('_')[-1])
            if o['execs_done']:
                e = int(o['execs_done'])
                if e not in pts:
                    pts[e] = (ts, o)
        ser = sorted(pts.items())
        if not ser:
            continue
        t0, t1 = ser[0][1][0], ser[-1][1][0]
        span = t1 - t0
        print(f'  --- {grp} (start={st}, 快照跨度={span}s) ---')
        seg = 6
        for i in range(seg):
            a = t0 + span * i / seg
            b = t0 + span * (i + 1) / seg
            pa = [x for x in ser if x[1][0] <= a]
            pb = [x for x in ser if x[1][0] <= b]
            if not pa or not pb:
                continue
            ea = pa[-1][0]; eb = pb[-1][0]
            dt = max(1, pb[-1][1][0] - pa[-1][1][0])
            rate = (eb - ea) / dt
            pend = pb[-1][1][1]['pending_total'] or '-'
            vpath = pb[-1][1][1]['variable_paths'] or '-'
            print(f'     段{i+1} [{a-t0:>5.0f}..{b-t0:>5.0f}s]: Δexecs={eb-ea:>7}  '
                  f'rate={rate:>6.2f}/s  pending_total={pend:>4}  variable_paths={vpath:>4}')
    print()
