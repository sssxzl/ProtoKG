#!/bin/bash
# 验证新版 cov_last_row：① 与旧版在真实数据上等价 ② 能正确处理「末行该列为空」
NEW='scripts/rq4_collect.sh'
echo "=== ① 新版在 6 个真实 cov_over_time.csv 上的取值 ==="
for spec in "rtsp protorag" "rtsp baseline" "sip protorag" "sip baseline" "smtp protorag" "smtp baseline"; do
  set -- $spec; p=$1; g=$2
  f=/home/zxy/rq4/out/$p/$g/r1/cov_over_time.csv
  [ -s "$f" ] || continue
  # 从当前脚本抽出 cov_last_row 并跑
  sed -n '/^cov_last_row()/,/^}/p' $NEW > /tmp/_fn.sh
  r=$( { echo '#!/bin/bash'; cat /tmp/_fn.sh; echo 'cov_last_row "$1" "$2"'; } > /tmp/_run.sh; bash /tmp/_run.sh "$f" l_per )
  rb=$( { echo '#!/bin/bash'; cat /tmp/_fn.sh; echo 'cov_last_row "$1" "$2"'; } > /tmp/_run2.sh; bash /tmp/_run2.sh "$f" b_per )
  # 官方末行
  hdr=$(head -1 "$f" | tr -d '\r'); last=$(tail -1 "$f" | tr -d '\r')
  c1=$(echo "$hdr" | awk -F',' -v k=l_per '{for(i=1;i<=NF;i++) if($i==k){print i; exit}}')
  c2=$(echo "$hdr" | awk -F',' -v k=b_per '{for(i=1;i<=NF;i++) if($i==k){print i; exit}}')
  e1=$(echo "$last" | awk -F',' -v c=$c1 '{print $c}'); e2=$(echo "$last" | awk -F',' -v c=$c2 '{print $c}')
  ok=$([ "$r" = "$e1" ] && [ "$rb" = "$e2" ] && echo "✓" || echo "✗")
  echo "  $p/$g: 新版 l_per=$r b_per=$rb  官方末行=$e1/$e2  → $ok"
done
echo ""
echo "=== ② 构造「末行该列为空」的边界场景 ==="
T=$(mktemp -d)
printf 'Time,l_per,l_abs,b_per,b_abs\n1,5.0,100,2.0,50\n2,,,,\n3,7.0,200,3.0,80\n' > $T/c.csv
sed -n '/^cov_last_row()/,/^}/p' $NEW > $T/fn.sh
{ echo '#!/bin/bash'; cat $T/fn.sh; echo 'cov_last_row "$1" "$2"'; } > $T/run.sh
echo "  末行有值(3,7.0)      → l_per='$(bash $T/run.sh $T/c.csv l_per)'  (期望 7.0)"
printf 'Time,l_per,l_abs,b_per,b_abs\n1,5.0,100,2.0,50\n2,,,,\n' > $T/c2.csv
echo "  末行该列为空         → l_per='$(bash $T/run.sh $T/c2.csv l_per)'  (期望 5.0，空行回退)"
printf 'Time,l_per,l_abs,b_per,b_abs\n1,,,,\n2,,,,\n' > $T/c3.csv
echo "  全部该列为空         → l_per='$(bash $T/run.sh $T/c3.csv l_per)'  (期望空)"
printf 'Time,l_per,l_abs,b_per,b_abs\n' > $T/c4.csv
echo "  仅表头               → l_per='$(bash $T/run.sh $T/c4.csv l_per)'  (期望空)"
rm -rf $T
