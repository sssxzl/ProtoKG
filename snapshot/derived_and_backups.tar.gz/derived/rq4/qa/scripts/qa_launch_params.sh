#!/bin/bash
echo "=== rq4_launch.sh 传给镜像 run 脚本的参数（TIMEOUT / SKIPCOUNT）==="
grep -nE "TIMEOUT|SKIPCOUNT|10800|out-.*-r" /home/zxy/rq4/scripts/rq4_launch.sh | head -25
echo ""
echo "=== 容器实际启动命令（docker inspect）==="
for c in rq4_rtsp_protorag_r1 rq4_sip_protorag_r1 rq4_smtp_protorag_r1; do
  echo "--- $c"
  docker inspect -f '{{join .Config.Cmd " "}}' "$c" 2>/dev/null
  docker inspect -f 'Entrypoint: {{join .Config.Entrypoint " "}}' "$c" 2>/dev/null
done
