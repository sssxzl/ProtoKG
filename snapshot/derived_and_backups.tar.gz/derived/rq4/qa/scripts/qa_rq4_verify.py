# -*- coding: utf-8 -*-
"""qa_rq4_verify.py —— RQ4 实验终态数据的**独立复核**脚本（QA 自写，不复用 rq4_analyze.py）。

本脚本刻意**不 import rq4_analyze.py**，所有关键计算（快照解析、execs_done 对齐、
线性插值、公共重叠窗口判定、参数逐 token 全等）都**独立重写一遍**，
再与 rq4_analyze.py 的输出做**逐点比对**，以验证对方实现无误。

输出（JSON + 文本）：
    1. 每个容器的快照序列诊断（点数、execs 范围、bitmap 范围、单调性、重复 execs）
    2. 每个协议的**公共重叠窗口**（起点/终点 execs）及"是否真为公共重叠"的独立判定
    3. 在 4 个对齐点上（窗口 25%/50%/75%/100%）**两组各自插值**结果与差值
    4. 与 rq4_analyze.py 输出的逐点吻合情况（最大绝对偏差）
    5. 终值（3h 结束）bitmap_cvg 与 execs 对齐处 bitmap_cvg **两个口径**的差值及同向性
    6. 参数逐 token 全等独立复核（自行实现，不调用 rq4_param_check.py）

用法:
    python3 qa_rq4_verify.py --out-root /home/zxy/rq4/out \
        --summary /home/zxy/rq4/rq4_summary.csv \
        --analyze-md /home/zxy/rq4/analysis/rq4_report.md \
        --json-out /home/zxy/rq4/analysis/qa_independent_verify.json
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# 官方参数表（取自 rq4_protocols.sh 的 PROTO_TABLE，唯一真源）
# 手工抄写在此，**故意不复用** VM 上的 shell 源，以便与 VM 版本形成交叉校验。
# ---------------------------------------------------------------------------
PROTO_TABLE: Dict[str, Dict[str, str]] = {
    "rtsp": {
        "net": "tcp://127.0.0.1/8554",
        "options": "-P RTSP -D 10000 -q 3 -s 3 -E -K -R -m none -t 5000",
    },
    "sip": {
        "net": "udp://127.0.0.1/5060",
        "options": "-m none -P SIP -l 5061 -D 50000 -q 3 -s 3 -E -K -t 5000",
    },
    "smtp": {
        "net": "tcp://127.0.0.1/25",
        "options": "-P SMTP -D 10000 -q 3 -s 3 -E -K -W 100 -m none -t 5000",
    },
}

GROUPS = ("protorag", "baseline")
FRACS = (0.25, 0.5, 0.75, 1.0)


# ---------------------------------------------------------------------------
# 1. 快照解析（独立实现）
# ---------------------------------------------------------------------------
def _field(text: str, key: str) -> str:
    """取 ``key : value`` 字段的值（逐行匹配，行首锚定）。"""
    pat = re.compile(r"^" + re.escape(key) + r"\s*:\s*(.*?)\s*$", re.MULTILINE)
    m = pat.search(text)
    return m.group(1) if m else ""


def _pct(raw: str) -> Optional[float]:
    """``"9.94%"`` → 9.94；``""`` → None。"""
    s = raw.strip().replace("%", "").replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _int(raw: str) -> Optional[int]:
    s = raw.strip().replace(",", "")
    if not s:
        return None
    try:
        return int(s)
    except ValueError:
        return None


def load_series(out_root: Path, proto: str, group: str, rep: int
                ) -> List[Tuple[int, float]]:
    """读某容器快照序列 → [(execs_done, bitmap_cvg), ...]（按 execs 升序、去重）。

    ★ 与 rq4_analyze.py 的差异：本实现**按 execs_done 去重**（同 execs 只保留最后一次
      快照的值，因为后一次快照的 bitmap 一定是同一时刻的更完整读数），
      而对方保留全部点（sorted 后由 zip 顺序决定取哪一段）。
      这条差异正是比对时要重点看的点 —— 若对方实现因重复点导致插值取错，
      逐点比对会立刻暴露。
    """
    d = out_root / proto / group / f"r{rep}"
    if not d.is_dir():
        return []
    raw: List[Tuple[int, float, str]] = []
    for snap in d.glob("stats_*.txt"):
        ts = snap.stem.split("_")[-1]
        try:
            ts_i = int(ts)
        except ValueError:
            continue
        try:
            text = snap.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ex = _int(_field(text, "execs_done"))
        cov = _pct(_field(text, "bitmap_cvg"))
        if ex is None or cov is None:
            continue
        raw.append((ex, cov, str(ts_i)))
    raw.sort(key=lambda x: (x[0], x[2]))
    # 同 execs 只保留**最后**一条（时间戳最大）
    dedup: Dict[int, float] = {}
    for ex, cov, _ts in raw:
        dedup[ex] = cov
    return sorted(dedup.items())


def series_diag(series: List[Tuple[int, float]]) -> Dict:
    """快照序列诊断。"""
    if not series:
        return {"n": 0}
    xs = [p[0] for p in series]
    ys = [p[1] for p in series]
    # bitmap_cvg 单调性（累计边覆盖理论上非降）
    drops = [
        (series[i - 1][0], series[i - 1][1], series[i][0], series[i][1])
        for i in range(1, len(series)) if series[i][1] < series[i - 1][1] - 1e-9
    ]
    # execs 是否有回退（说明快照顺序/内容异常）
    execs_back = [
        (series[i - 1][0], series[i][0])
        for i in range(1, len(series)) if series[i][0] < series[i - 1][0]
    ]
    return {
        "n": len(series),
        "execs_min": xs[0],
        "execs_max": xs[-1],
        "bitmap_first": ys[0],
        "bitmap_last": ys[-1],
        "bitmap_max": max(ys),
        "monotonic_non_decreasing": not drops,
        "bitmap_drops": drops[:5],
        "execs_non_increasing_pairs": execs_back[:5],
    }


# ---------------------------------------------------------------------------
# 2. 独立插值（与 rq4_analyze.py 同口径：线性插值 + 端点截断）
# ---------------------------------------------------------------------------
def interp(series: List[Tuple[int, float]], target: int) -> Optional[float]:
    """线性插值取 target 处的 bitmap_cvg；超界取端点。"""
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    lo, hi = 0, len(series) - 1
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if series[mid][0] <= target:
            lo = mid
        else:
            hi = mid
    x0, y0 = series[lo]
    x1, y1 = series[lo + 1]
    if x1 == x0:
        return y0
    return y0 + (y1 - y0) * (target - x0) / (x1 - x0)


def interp_linear_scan(series: List[Tuple[int, float]], target: int) -> Optional[float]:
    """**另一种写法**的插值（顺序扫描，非二分），用于交叉校验 interp()。"""
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    for (x0, y0), (x1, y1) in zip(series, series[1:]):
        if x0 <= target <= x1:
            if x1 == x0:
                return y0
            return y0 + (y1 - y0) * (target - x0) / (x1 - x0)
    return series[-1][1]


# ---------------------------------------------------------------------------
# 3. 参数逐 token 全等（独立实现，不调用 rq4_param_check.py）
# ---------------------------------------------------------------------------
def check_params(options: str, net: str, command_line: str) -> Dict:
    """独立实现的逐 token 全等复核。返回判定 + 细节。

    判定逻辑（与官方 rq4_param_check.py 同规则，但代码完全独立重写）：
      · 锚点 = ``-N <net>``，起点 = 锚点后 2 个 token
      · OPTIONS 段 = 起点起 len(expected) 个 token，逐个相等
      · OPTIONS 之后必须紧跟服务端命令（非选项 token）或 ``-c`` / ``--``
    """
    expected = options.split()
    tokens = command_line.split()
    detail: Dict = {
        "expected_options": options,
        "expected_tokens": expected,
        "net": net,
        "command_line": command_line,
    }
    if not command_line.strip():
        detail["verdict"] = "NO_COMMAND_LINE"
        return detail

    # 找 -N 锚点
    anchor = -1
    for i, t in enumerate(tokens):
        if t == "-N" and i + 1 < len(tokens) and tokens[i + 1] == net:
            anchor = i
            break
    if anchor < 0:
        has_n = any(t == "-N" for t in tokens)
        detail["verdict"] = "MISMATCH"
        detail["reason"] = ("找不到 '-N <net>' 锚点（net 值与参数表不符）"
                            if has_n else "command_line 里没有 '-N'")
        return detail

    start = anchor + 2
    end = start + len(expected)
    detail["anchor_index"] = anchor
    detail["options_start_index"] = start
    if end > len(tokens):
        detail["verdict"] = "MISMATCH"
        detail["reason"] = (f"OPTIONS 段提前结束：需要 {len(expected)} 个 token，"
                            f"实际只剩 {len(tokens) - start} 个")
        return detail

    actual = tokens[start:end]
    detail["actual_options_tokens"] = actual
    detail["token_by_token"] = [
        {"idx": i + 1, "expected": e, "actual": a, "equal": e == a}
        for i, (e, a) in enumerate(zip(expected, actual))
    ]
    if actual != expected:
        detail["verdict"] = "MISMATCH"
        bad = [t for t in detail["token_by_token"] if not t["equal"]]
        detail["reason"] = "; ".join(
            f"第 {t['idx']} 个 token：期望 '{t['expected']}' 实际 '{t['actual']}'"
            for t in bad)
        return detail

    # 尾部边界
    if end >= len(tokens):
        detail["verdict"] = "MISMATCH"
        detail["reason"] = "OPTIONS 段之后缺少服务端命令"
        return detail
    tail = tokens[end]
    detail["tail_token"] = tail
    if tail.startswith("-"):
        if tail not in ("-c", "--"):
            detail["verdict"] = "MISMATCH"
            detail["reason"] = f"OPTIONS 段尾部多出选项 '{tail}'"
            return detail
        if tail == "-c" and (end + 1 >= len(tokens) or "/" not in tokens[end + 1]):
            detail["verdict"] = "MISMATCH"
            detail["reason"] = "'-c' 之后缺少服务端脚本路径"
            return detail
    detail["verdict"] = "OK"
    detail["reason"] = "逐 token 全等"
    return detail


def mask_outdir(command_line: str) -> str:
    """遮蔽 ``-o <outdir>`` 的值（跨容器一致性比对用）。"""
    tokens = command_line.split()
    out: List[str] = []
    skip = False
    for t in tokens:
        if skip:
            out.append("<OUTDIR>")
            skip = False
            continue
        out.append(t)
        if t == "-o":
            skip = True
    return " ".join(out)


# ---------------------------------------------------------------------------
# 4. 读 summary csv
# ---------------------------------------------------------------------------
def load_summary(path: Path) -> List[Dict]:
    rows: List[Dict] = []
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        for raw in csv.DictReader(fh):
            rows.append({(k or "").strip(): (v if v is not None else "")
                         for k, v in raw.items()})
    return rows


# ---------------------------------------------------------------------------
# 5. 解析 rq4_analyze.py 生成的 Markdown 对齐表，用于逐点比对
# ---------------------------------------------------------------------------
MD_ROW_RE = re.compile(
    r"^\|\s*(rtsp|sip|smtp)\s*\|\s*(\d+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*"
    r"\|\s*([+\-][\d.]+)\s*\|\s*$")


def parse_analyze_md(md_path: Path) -> Dict[str, Dict[int, Tuple[float, float, float]]]:
    """从 rq4_report.md 的「execs_done 对齐」表里解析出 {proto: {target: (c1,c2,diff)}}。"""
    out: Dict[str, Dict[int, Tuple[float, float, float]]] = {}
    if not md_path.exists():
        return out
    in_section = False
    for line in md_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("## ") and "execs_done" in line:
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if not in_section:
            continue
        m = MD_ROW_RE.match(line.strip())
        if m:
            proto, target, c1, c2, diff = m.groups()
            out.setdefault(proto, {})[int(target)] = (
                float(c1), float(c2), float(diff))
    return out


def parse_analyze_md_terminal(md_path: Path) -> Dict[str, Dict[str, Dict[str, float]]]:
    """从 rq4_report.md 的主对比表里解析终值指标 {proto: {group: {field: value}}}。

    主对比表行形如：``| bitmap_cvg(%) [主] | 9.94 | 9.31 |``
    表头形如：``| 指标 | baseline (n=1) | protorag (n=1) |``
    """
    out: Dict[str, Dict[str, Dict[str, float]]] = {}
    if not md_path.exists():
        return out
    lines = md_path.read_text(encoding="utf-8").splitlines()
    proto = None
    in_table = False
    groups: List[str] = []
    for line in lines:
        s = line.strip()
        if s.startswith("### ") and s[4:] in PROTO_TABLE:
            proto = s[4:]
            in_table = False
            groups = []
            continue
        if proto is None:
            continue
        if s.startswith("| 指标 |"):
            groups = [c.strip() for c in s.strip("|").split("|")][1:]
            in_table = True
            continue
        if in_table:
            if not s.startswith("|"):
                in_table = False
                continue
            if set(s) <= set("|- "):
                continue
            cells = [c.strip() for c in s.strip("|").split("|")]
            if len(cells) < 1 + len(groups):
                continue
            label = cells[0]
            vals = cells[1:]
            for g, v in zip(groups, vals):
                gkey = g.split(" ")[0].strip()
                try:
                    fval = float(v)
                except ValueError:
                    fval = None
                if fval is None:
                    continue
                out.setdefault(proto, {}).setdefault(gkey, {})[label] = fval
    return out


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", default="/home/zxy/rq4/out")
    ap.add_argument("--summary", default="/home/zxy/rq4/rq4_summary.csv")
    ap.add_argument("--analyze-md", default="")
    ap.add_argument("--json-out", default="")
    args = ap.parse_args()

    out_root = Path(args.out_root)
    summary_path = Path(args.summary)
    rows = load_summary(summary_path)

    report: Dict = {
        "summary_file": str(summary_path),
        "summary_rows": len(rows),
        "params": {},
        "series": {},
        "windows": {},
        "aligned": {},
        "analyze_cross_check": {},
        "terminal": {},
        "anomalies": [],
    }

    # ---- A. 参数逐 token 全等独立复核 ----
    by_key: Dict[Tuple[str, str, int], Dict] = {}
    for r in rows:
        proto = r.get("protocol", "")
        group = r.get("group", "")
        rep = int(r.get("rep") or 0)
        by_key[(proto, group, rep)] = r
        spec = PROTO_TABLE.get(proto)
        if spec is None:
            report["anomalies"].append(f"summary 出现未知协议 '{proto}'")
            continue
        res = check_params(spec["options"], spec["net"], r.get("command_line", ""))
        res["container"] = r.get("container", "")
        res["csv_param_check_column"] = r.get("param_check", "")
        res["csv_claim_matches_independent"] = (
            res["verdict"] == r.get("param_check", ""))
        report["params"][r.get("container", "")] = res

    # ---- 跨容器一致性（遮蔽 outdir 后同协议逐字相同）----
    consistency: Dict[str, Dict] = {}
    for proto in sorted({k[0] for k in by_key}):
        masked: Dict[str, str] = {}
        for (p, g, rep), r in by_key.items():
            if p != proto:
                continue
            masked[r.get("container", "")] = mask_outdir(r.get("command_line", ""))
        vals = set(masked.values())
        consistency[proto] = {
            "masked_command_lines": masked,
            "consistent": len(vals) == 1,
            "distinct_count": len(vals),
        }
    report["param_consistency_across_containers"] = consistency

    # ---- B/C/D. 序列诊断 + 公共重叠窗口 + 对齐点插值 ----
    for proto in sorted({k[0] for k in by_key}):
        for group in GROUPS:
            reps = sorted({k[2] for k in by_key if k[0] == proto and k[1] == group})
            for rep in reps:
                series = load_series(out_root, proto, group, rep)
                key = f"{proto}/{group}/r{rep}"
                report["series"][key] = series_diag(series)

        # ---- 公共重叠窗口（独立判定）----
        s_pro = load_series(out_root, proto, "protorag", 1)
        s_bas = load_series(out_root, proto, "baseline", 1)
        if not s_pro or not s_bas:
            report["windows"][proto] = {"error": "缺少快照序列"}
            continue
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        win = {
            "protorag_execs_range": [s_pro[0][0], s_pro[-1][0]],
            "baseline_execs_range": [s_bas[0][0], s_bas[-1][0]],
            "common_start": lo,
            "common_end": hi,
            "common_span_execs": hi - lo,
            "is_true_common_overlap": (
                lo >= s_pro[0][0] and lo >= s_bas[0][0]
                and hi <= s_pro[-1][0] and hi <= s_bas[-1][0]),
            "overlap_is_subset_of_both": (
                lo <= hi
                and s_pro[0][0] <= lo and s_bas[0][0] <= lo
                and hi <= s_pro[-1][0] and hi <= s_bas[-1][0]),
        }
        if hi <= lo:
            win["error"] = "两组 execs 无公共重叠窗口"
        report["windows"][proto] = win
        if hi <= lo:
            continue

        aligned: Dict[str, Dict] = {}
        for frac in FRACS:
            target = int(lo + (hi - lo) * frac)
            c1 = interp(s_pro, target)
            c1b = interp_linear_scan(s_pro, target)
            c2 = interp(s_bas, target)
            c2b = interp_linear_scan(s_bas, target)
            aligned[str(target)] = {
                "frac": frac,
                "target": target,
                "protorag": None if c1 is None else round(c1, 6),
                "baseline": None if c2 is None else round(c2, 6),
                "diff": None if (c1 is None or c2 is None) else round(c1 - c2, 6),
                "two_impls_agree": (
                    (c1 is None and c1b is None)
                    or (c1 is not None and c1b is not None
                        and abs(c1 - c1b) < 1e-9)
                    and (c2 is None and c2b is None)
                    or (c2 is not None and c2b is not None
                        and abs(c2 - c2b) < 1e-9)),
            }
        report["aligned"][proto] = aligned

    # ---- E. 与 rq4_analyze.py 输出逐点比对 ----
    if args.analyze_md:
        md_path = Path(args.analyze_md)
        md_aligned = parse_analyze_md(md_path)
        md_terminal = parse_analyze_md_terminal(md_path)
        xcheck: Dict = {"md_file": str(md_path), "aligned_points": {}}
        worst = 0.0
        n_pts = 0
        n_match = 0
        for proto, pts in md_aligned.items():
            mine = report["aligned"].get(proto, {})
            per_proto = {}
            for target, (c1, c2, diff) in sorted(pts.items()):
                m = mine.get(str(target))
                if m is None:
                    per_proto[str(target)] = {"status": "MISSING_IN_MINE"}
                    continue
                d1 = abs(m["protorag"] - c1)
                d2 = abs(m["baseline"] - c2)
                d3 = abs(m["diff"] - diff)
                dmax = max(d1, d2, d3)
                ok = dmax <= 0.005 + 1e-9   # 允许 0.005 的四舍五入误差
                per_proto[str(target)] = {
                    "mine": [m["protorag"], m["baseline"], m["diff"]],
                    "theirs": [c1, c2, diff],
                    "abs_delta": [round(d1, 6), round(d2, 6), round(d3, 6)],
                    "match": ok,
                }
                worst = max(worst, dmax)
                n_pts += 1
                n_match += 1 if ok else 0
            xcheck["aligned_points"][proto] = per_proto
        xcheck["points_compared"] = n_pts
        xcheck["points_matched"] = n_match
        xcheck["max_abs_delta"] = round(worst, 6)
        xcheck["all_match"] = (n_pts > 0 and n_match == n_pts)

        # 终值交叉比对
        xcheck["terminal_from_md"] = md_terminal
        report["analyze_cross_check"] = xcheck

    # ---- F. 终值（3h）对比：两个口径 ----
    terminal: Dict = {}
    for proto in sorted({k[0] for k in by_key}):
        entry: Dict = {}
        for group in GROUPS:
            r = by_key.get((proto, group, 1))
            if r is None:
                continue
            entry[group] = {
                "container": r.get("container", ""),
                "bitmap_cvg_final": _pct(r.get("bitmap_cvg", "")),
                "execs_done_final": _int(r.get("execs_done", "")),
                "execs_per_sec": _pct(r.get("execs_per_sec", "")),
                "fuzz_sec": _int(r.get("fuzz_sec", "")),
                "paths_total": _int(r.get("paths_total", "")),
                "paths_found": _int(r.get("paths_found", "")),
                "max_depth": _int(r.get("max_depth", "")),
                "stability": _pct(r.get("stability", "")),
                "unique_crashes": _int(r.get("unique_crashes", "")),
                "unique_hangs": _int(r.get("unique_hangs", "")),
                "l_per": _pct(r.get("l_per", "")),
                "b_per": _pct(r.get("b_per", "")),
                "seed_files": _int(r.get("seed_files", "")),
                "seed_regions": _pct(r.get("seed_regions", "")),
                "dict_tokens": _int(r.get("dict_tokens", "")),
            }
        d_final = None
        d_align = None
        if "protorag" in entry and "baseline" in entry:
            a = entry["protorag"]["bitmap_cvg_final"]
            b = entry["baseline"]["bitmap_cvg_final"]
            if a is not None and b is not None:
                d_final = round(a - b, 4)
            al = report["aligned"].get(proto, {})
            # 取窗口 100% 处（公共重叠终点）的对齐差值
            if al:
                last_key = sorted(al.keys(), key=lambda k: int(k))[-1]
                d_align = al[last_key]["diff"]
        same_dir = None
        if d_final is not None and d_align is not None:
            same_dir = (d_final > 0) == (d_align > 0) or d_final == 0 or d_align == 0
        entry["delta_final_bitmap_cvg"] = d_final
        entry["delta_aligned_bitmap_cvg_at_common_end"] = d_align
        entry["two_criteria_same_direction"] = same_dir
        # 口径分歧：bitmap_cvg vs l_per
        d_lp = None
        if "protorag" in entry and "baseline" in entry:
            a = entry["protorag"]["l_per"]
            b = entry["baseline"]["l_per"]
            if a is not None and b is not None:
                d_lp = round(a - b, 4)
        entry["delta_l_per"] = d_lp
        if d_final is not None and d_lp is not None:
            entry["bitmap_cvg_vs_l_per_same_direction"] = (
                (d_final > 0) == (d_lp > 0)
                or d_final == 0 or d_lp == 0)
        else:
            entry["bitmap_cvg_vs_l_per_same_direction"] = None
        terminal[proto] = entry
    report["terminal"] = terminal

    # ---- 输出 ----
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.json_out:
        p = Path(args.json_out)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        print(f"[qa] JSON 写出: {p}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
