# -*- coding: utf-8 -*-
"""qa_cost_to_reach.py —— 第三口径分析：「达到某覆盖率所需的 execs / 挂钟秒」。

为什么需要第三个口径
------------------
前两个口径各有盲区：

* **口径A（3h 终值 bitmap_cvg）**：按**挂钟时间**对齐 → 会被「exec 速率差」污染
  （两组 exec/s 不同 → 同样 3h 做了不同数量的 exec）。
* **口径B（execs 对齐处 bitmap_cvg）**：按**执行次数**对齐 → 剥离了速率差，
  但把「挂钟预算是否公平」这个维度整个丢掉了。

**口径C（达到覆盖率 X 所需的 execs）** 同时用两个维度做横轴：
  · 横轴用 execs → 剥离速率差
  · 被解释变量用「达到 X% 覆盖所用的 execs」→ 越小越高效
  它等价于「覆盖率曲线在 execs 维上的横移」，比单点差值更稳（用整段曲线求交点，
  而不是只看某两个点）。

★ 挂钟版本（达到 X% 覆盖所需秒数）也一并给出 —— 它等价于「覆盖率曲线在时间维上的横移」。

本脚本**不 import rq4_analyze.py**，独立实现。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def _field(text: str, key: str) -> str:
    m = re.search(r"^" + re.escape(key) + r"\s*:\s*(.*?)\s*$", text, re.MULTILINE)
    return m.group(1) if m else ""


def _num(raw: str) -> Optional[float]:
    s = str(raw).strip().replace("%", "").replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def load_series(out_root: Path, proto: str, group: str, rep: int = 1
                ) -> List[Tuple[int, float, int]]:
    """→ [(execs, cov, snapshot_ts)]，按 execs 升序（同 execs 保留最后一次）。"""
    d = out_root / proto / group / f"r{rep}"
    if not d.is_dir():
        return []
    raw: List[Tuple[int, float, int]] = []
    for snap in d.glob("stats_*.txt"):
        try:
            ts = int(snap.stem.split("_")[-1])
        except ValueError:
            continue
        try:
            text = snap.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ex = _num(_field(text, "execs_done"))
        cov = _num(_field(text, "bitmap_cvg"))
        st = _num(_field(text, "start_time"))
        if ex is None or cov is None:
            continue
        raw.append((int(ex), cov, ts))
    raw.sort(key=lambda x: (x[0], x[2]))
    dedup: Dict[int, Tuple[float, int]] = {}
    for ex, cov, ts in raw:
        dedup[ex] = (cov, ts)
    return [(ex, v[0], v[1]) for ex, v in sorted(dedup.items())]


def execs_to_reach(series, thr: float) -> Optional[int]:
    """达到 cov>=thr 所需的最小 execs（线性插值求交点）。"""
    if not series:
        return None
    if series[0][1] >= thr:
        return series[0][0]
    for (x0, y0, _t0), (x1, y1, _t1) in zip(series, series[1:]):
        if y0 < thr <= y1:
            if y1 == y0:
                return x1
            return int(round(x0 + (x1 - x0) * (thr - y0) / (y1 - y0)))
    return None


def secs_to_reach(series, thr: float) -> Optional[int]:
    """达到 cov>=thr 所需的最早挂钟秒（以 start_time 为原点）。"""
    if not series:
        return None
    st = None
    for _e, _c, t in series:
        st = t
        break
    # start_time 从最早快照里读（可能为空 → 用最早快照时间戳近似）
    start_ts = series[0][2]
    if series[0][1] >= thr:
        return 0
    prev_c = series[0][1]
    prev_t = series[0][2]
    for e, c, t in series[1:]:
        if prev_c < thr <= c:
            if c == prev_c:
                return t - start_ts
            frac = (thr - prev_c) / (c - prev_c)
            return int(round((prev_t + (t - prev_t) * frac) - start_ts))
        prev_c, prev_t = c, t
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()
    out_root = Path(args.out_root)

    thresholds = {
        "rtsp": [8.0, 8.5, 9.0, 9.2, 9.4, 9.6, 9.8],
        "sip": [14.0, 16.0, 18.0, 20.0, 21.0, 21.5, 21.8, 22.0],
        "smtp": [9.5, 9.8, 10.0, 10.5, 11.0, 11.3, 11.5],
    }

    out: Dict = {"cost_to_reach": {}}
    md: List[str] = []
    md.append("# RQ4 口径C：达到指定覆盖率所需的 execs / 挂钟秒")
    md.append("")
    md.append("> 横轴 = execs（剥离执行速率差）；被解释变量 = 「达到 X% 覆盖所需的 execs」，越小越高效。")
    md.append("> 「—」= 该组在 3h 内**从未达到**该覆盖率。")
    md.append("> **单次运行（n=1），无重复，无统计效力。**")
    md.append("")

    for proto in ["rtsp", "sip", "smtp"]:
        md.append(f"## {proto}")
        md.append("")
        md.append("| 目标覆盖率 | protorag 需 execs | baseline 需 execs | execs 比 (pro/bas) | protorag 需秒 | baseline 需秒 | 谁先达到 |")
        md.append("|---|---|---|---|---|---|---|")
        for thr in thresholds.get(proto, []):
            row: Dict = {}
            for grp in ["protorag", "baseline"]:
                s = load_series(out_root, proto, grp)
                row[grp] = {
                    "execs": execs_to_reach(s, thr),
                    "secs": secs_to_reach(s, thr),
                }
            pe, be = row["protorag"]["execs"], row["baseline"]["execs"]
            ps, bs = row["protorag"]["secs"], row["baseline"]["secs"]
            ratio = (f"{pe/be:.2f}" if (pe and be) else "—")
            if pe and be:
                win = "protorag 先" if pe < be else ("baseline 先" if be < pe else "相同")
            else:
                win = "单边达成"
            md.append(f"| ≥{thr}% | {pe if pe else '—'} | {be if be else '—'} | {ratio} | "
                      f"{ps if ps is not None else '—'} | {bs if bs is not None else '—'} | {win} |")
            out["cost_to_reach"].setdefault(proto, {})[str(thr)] = row
        md.append("")

    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(
            json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
