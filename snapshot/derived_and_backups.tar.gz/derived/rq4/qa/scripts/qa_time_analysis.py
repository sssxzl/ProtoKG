import re, pathlib
root = pathlib.Path('/home/zxy/rq4/out')

def parse(p):
    t = p.read_text(errors='replace'); o = {}
    for k in ['execs_done', 'bitmap_cvg', 'start_time', 'last_update']:
        m = re.search(r'^' + k + r'\s*:\s*(.*?)\s*$', t, re.M)
        o[k] = m.group(1) if m else ''
    return o

for proto in ['rtsp', 'sip', 'smtp']:
    print('=' * 96)
    print(f'### {proto} —— execs_done / bitmap_cvg 随挂钟时间的演化')
    print('=' * 96)
    store = {}
    for grp in ['protorag', 'baseline']:
        d = root / proto / grp / 'r1'
        snaps = sorted(d.glob('stats_*.txt'))
        if not snaps:
            continue
        st = int(parse(snaps[0])['start_time'] or 0)
        pts = {}
        for s in snaps:
            o = parse(s); ts = int(s.stem.split('_')[-1])
            if o['execs_done']:
                e = int(o['execs_done'])
                c = float(o['bitmap_cvg'].rstrip('%')) if o['bitmap_cvg'] else None
                if e not in pts or (c is not None and pts[e][1] is not None and c > pts[e][1]):
                    pts[e] = (ts, c)
        ser = sorted(pts.items())
        store[grp] = (st, ser)
        if not ser:
            continue
        print(f'  --- {grp} (start_time={st}) ---')
        for e, (ts, c) in ser[:8]:
            print(f'     t+{ts-st:>6}s  execs={e:>8}  cov={c}')
        total_e = ser[-1][0]; total_t = ser[-1][1][0]
        print(f'     ...末点: t+{total_t-st}s execs={total_e} cov={ser[-1][1][1]}')
        # 外推 execs=0 时刻（dry_run 结束）
        if len(ser) >= 2 and ser[1][0] > ser[0][0]:
            (e1, (t1, _)), (e2, (t2, _)) = ser[0], ser[1]
            if e2 > e1:
                t0 = t1 - e1 * (t2 - t1) / (e2 - e1)
                print(f'     → 外推 execs=0 @ t+{t0-st:.0f}s  (初始 dry_run ≈ {t0-st:.0f}s)')
        # 各覆盖率里程碑的到达时刻
        for thr in [8.0, 9.0, 9.5, 10.0, 15.0, 20.0, 22.0]:
            hit = [(ts, c) for e, (ts, c) in ser if c is not None and c >= thr]
            if hit:
                print(f'     → cov≥{thr}%: t+{hit[0][0]-st}s (protorag/baseline 对比见下)')
            else:
                print(f'     → cov≥{thr}%: 未达到')
    # 里程碑对比
    print(f'  >>> {proto} 覆盖率里程碑到达时刻对比（挂钟秒，越小越快）')
    for thr in [8.0, 9.0, 9.5, 10.0, 15.0, 20.0, 22.0]:
        row = {}
        for grp in ['protorag', 'baseline']:
            if grp not in store:
                continue
            st, ser = store[grp]
            hit = [(ts, c) for e, (ts, c) in ser if c is not None and c >= thr]
            row[grp] = (hit[0][0] - st) if hit else None
        if any(v is not None for v in row.values()):
            a, b = row.get('protorag'), row.get('baseline')
            win = 'protorag 先' if (a is not None and b is not None and a < b) else (
                   'baseline 先' if (a is not None and b is not None and b < a) else '持平/单边')
            print(f'     cov≥{thr:>5}%: protorag t+{a}s  baseline t+{b}s  → {win}')
    print()
