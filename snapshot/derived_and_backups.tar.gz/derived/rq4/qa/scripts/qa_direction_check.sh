#!/bin/bash
# 口径分歧检查：用「正确实现」复算的 l_per vs bitmap_cvg，判断两口径是否同向
echo "================================================================"
echo " 口径分歧检查：bitmap_cvg（AFL 边覆盖） vs l_per（gcovr 行覆盖）"
echo "================================================================"
printf "%-8s %-12s %-12s %-10s | %-12s %-12s %-10s | %s\n" \
  "协议" "bcvg_pro" "bcvg_bas" "Δbcvg" "lper_pro" "lper_bas" "Δlper" "两口径同向?"
echo "----------------------------------------------------------------"
check() {
  proto=$1; bp=$2; bb=$3; lp=$4; lb=$5
  d1=$(echo "$bp $bb" | awk '{printf "%+.4f", $1-$2}')
  d2=$(echo "$lp $lb" | awk '{printf "%+.4f", $1-$2}')
  same=$(echo "$d1 $d2" | awk '{if ($1==0||$2==0) print "是(含0)"; else if (($1>0)==($2>0)) print "是"; else print "★否(异向)"}')
  printf "%-8s %-12s %-12s %-10s | %-12s %-12s %-10s | %s\n" "$proto" "$bp" "$bb" "$d1" "$lp" "$lb" "$d2" "$same"
}
check rtsp 9.94 9.72 24.7 24.2
check sip  22.06 22.11 6.6  6.3
check smtp 10.00 11.66 5.9  14.1
echo ""
echo "注：sip 两行 l_per 来自**部分完成**的 cov_over_time.csv（后处理未完）→ 该行待终值复核"
echo "    RTSP / SMTP 两行 l_per 为终值（容器已 Exited，cov_script 已跑完）"
