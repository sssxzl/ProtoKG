#!/bin/bash
echo "=== 验证：两组容器的 in-<proto> 挂载来源不同（protorag=宿主种子, baseline=镜像自带）==="
for c in rq4_rtsp_protorag_r1 rq4_rtsp_baseline_r1 rq4_sip_protorag_r1 rq4_sip_baseline_r1 rq4_smtp_protorag_r1 rq4_smtp_baseline_r1; do
  echo "--- $c"
  docker inspect -f '{{range .Mounts}}{{.Type}} {{.Source}} -> {{.Destination}} (RW={{.RW}}){{println}}{{end}}' "$c" 2>/dev/null | grep -E "in-|seed" || echo "   (无 in-* 挂载 → 用镜像自带)"
done
echo ""
echo "=== 容器内 in-<proto> 实际文件数（运行中容器 exec / 已退出容器跳过）==="
for spec in "rq4_rtsp_protorag_r1 rtsp" "rq4_rtsp_baseline_r1 rtsp" "rq4_sip_protorag_r1 sip" "rq4_sip_baseline_r1 sip" "rq4_smtp_protorag_r1 smtp" "rq4_smtp_baseline_r1 smtp"; do
  set -- $spec; c=$1; p=$2
  if docker ps --format '{{.Names}}' | grep -qx "$c"; then
    n=$(docker exec "$c" sh -c "ls /home/ubuntu/experiments/in-$p 2>/dev/null | grep -v README | wc -l" 2>/dev/null)
    echo "  $c: in-$p 文件数 = $n"
  else
    echo "  $c: (已退出，用宿主种子画像)"
  fi
done
