#!/bin/bash
# qa_read_final_stats.sh —— 直接从容器真实产物读 6 个容器的终态 fuzzer_stats 关键字段
# 运行中容器 → docker exec；已退出容器 → 从 tar 流式读取（tar -xO，不落盘）
set -uo pipefail
TMP=$(mktemp -d /home/zxy/rq4/qa_tmp.XXXXXX)
trap 'rm -rf "$TMP"' EXIT

emit() {
  local p="$1" g="$2" c="rq4_${p}_${g}_r1" d img tar_path
  case $p in
    rtsp) d=/home/ubuntu/experiments/live/testProgs/out-${p}-${g}-r1 ;;
    sip)  d=/home/ubuntu/experiments/kamailio/out-${p}-${g}-r1 ;;
    smtp) d=/home/ubuntu/experiments/exim/out-${p}-${g}-r1 ;;
  esac
  img=$(docker inspect -f '{{.Config.Image}}' "$c" 2>/dev/null)
  tar_path="/home/ubuntu/experiments/out-${p}-${g}-r1.tar.gz"
  local stats=""
  if docker ps --format '{{.Names}}' | grep -qx "$c"; then
    stats=$(docker exec "$c" cat "$d/fuzzer_stats" 2>/dev/null)
    src="exec(running)"
  else
    if docker cp "$c:$tar_path" "$TMP/o.tar.gz" >/dev/null 2>&1; then
      stats=$(docker run --rm -v "$TMP:/out" --entrypoint /bin/bash "$img" \
        -c "cd /out && tar xzOf o.tar.gz '$(basename $d)/fuzzer_stats'" 2>/dev/null)
      src="tar(exited)"
    else
      src="UNAVAILABLE"
    fi
  fi
  echo "### $c  [$src]"
  if [[ -z "$stats" ]]; then
    echo "  !! fuzzer_stats 不可读"
    return
  fi
  echo "$stats" | grep -E '^(start_time|last_update|cycles_done|execs_done|execs_per_sec|paths_total|paths_found|max_depth|stability|bitmap_cvg|unique_crashes|unique_hangs|peak_rss_mb|exec_timeout) *:' \
    | sed -E 's/^ +/  /'
  echo "  [fuzz_sec] $(echo "$stats" | sed -n 's/^start_time *: *//p;s/^last_update *: *//p' | awk 'NR==1{a=$1} NR==2{b=$1} END{print b-a}')"
}

echo "================================================================"
echo " QA 直接读容器终态 fuzzer_stats（不经过 rq4_summary.csv）"
echo "================================================================"
for p in rtsp sip smtp; do
  for g in protorag baseline; do
    emit "$p" "$g"
    echo ""
  done
done
