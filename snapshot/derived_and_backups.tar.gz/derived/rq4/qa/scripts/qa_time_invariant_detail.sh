#!/bin/bash
python3 - <<'PYEOF'
import pathlib
root = pathlib.Path('/home/zxy/rq4/out')
SEEDS = {'rtsp': {'protorag':39,'baseline':7}, 'sip': {'protorag':25,'baseline':1}, 'smtp': {'protorag':78,'baseline':2}}
print('=== 逐文件：Time 倒退的精确位置与「段边界 = 种子数+1」的关系 ===')
for proto in ['rtsp','sip','smtp']:
    for grp in ['protorag','baseline']:
        f = root/proto/grp/'r1'/'cov_over_time.csv'
        if not f.exists(): continue
        lines=[l.strip() for l in f.read_text(errors='replace').splitlines() if l.strip()]
        hdr=lines[0].split(',')
        ts=[]; empty=[]
        for i,l in enumerate(lines[1:],1):
            p=l.split(',')
            if len(p)!=len(hdr): continue
            try: t=int(p[0])
            except ValueError: continue
            ts.append((i,t))
            if len(p)>1 and p[1].strip()=='': empty.append(i)
        backs=[(rows[i-1][0], rows[i-1][1], rows[i][0], rows[i][1]) for i in range(1,len(rows)) if rows[i][1]<rows[i-1][1]]
        ns=SEEDS[proto][grp]
        print(f'  {proto}/{grp}: 种子数={ns} 倒退次数={len(backs)}')
        for (r0,t0,r1,t1) in backs:
            print(f'      行{r0}(Time={t0}) → 行{r1}(Time={t1})   [种子数+1={ns+1}]  {"✓ 恰在段边界" if r0==ns else f"✗ 段边界应为行{ns}"}')
        if not backs:
            print(f'      无倒退 → 段边界处 Time 未下降（可能因该组种子回放耗时与后续用例时间重叠）')
        print(f'      空值行位置: {empty}')
PYEOF
