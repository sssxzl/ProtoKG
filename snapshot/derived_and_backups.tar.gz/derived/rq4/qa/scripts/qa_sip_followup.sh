#!/bin/bash
# qa_sip_followup.sh —— 后台守候：SIP 容器最终退出后，重跑采集/分析以补齐 l_per / b_per
#
# 背景：SIP 的 cov_script（cov_over_time.csv 生产者）还在跑，
#       第一次采集时 SIP 两行的 l_per/b_per 是**部分值**。
#       等容器真正退出（cov_script + gcovr html + tar 全部完成）后重采一次即可拿到终值。
set -uo pipefail
LOG=/home/zxy/rq4/logs/qa_sip_followup.log
mkdir -p /home/zxy/rq4/logs
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG"; }

MAX=${MAX:-21600}
POLL=${POLL:-180}
DRIVER_SENTINEL=/home/zxy/rq4/logs/qa_driver.done
W=0
log "=== SIP followup watcher start (max=${MAX}s) ==="

# ---- 先等主 driver 结束（避免两个脚本同时写 rq4_summary.csv / analysis/）----
#   注：主 driver 是**先于本脚本**启动的，其内容里的 sentinel 写入是后加的，
#   故运行中的实例**不会**写 sentinel → 改为「进程消失」判据（更通用）。
while true; do
  if [[ -f "$DRIVER_SENTINEL" ]]; then
    log "主 driver 已写 sentinel → 开始守候 SIP"
    break
  fi
  if ! pgrep -f 'rq4_qa_driver.sh' >/dev/null 2>&1; then
    log "主 driver 进程已消失（未写 sentinel）→ 开始守候 SIP"
    break
  fi
  if [[ "$W" -ge 2400 ]]; then
    log "!! 等待主 driver 结束超时（2400s）→ 放弃 followup（避免写冲突）"
    exit 0
  fi
  sleep 30; W=$((W + 30))
done

W=0
while true; do
  up=$(docker ps --format '{{.Names}}' | grep -c '^rq4_sip_' || true)
  if [[ "$up" -eq 0 ]]; then
    log "SIP 容器已全部退出（等待 ${W}s）→ 重跑采集 + 分析"
    break
  fi
  if [[ "$W" -ge "$MAX" ]]; then
    log "!! 等待超时 ${W}s，放弃followup（保留第一次采集结果）"
    exit 0
  fi
  sleep "$POLL"
  W=$((W + POLL))
done

# ★ **不再预置 cov_over_time.csv**
#   KP-3 已由工程师从根上修好：容器退出分支现在也从 tar 里解出 cov_over_time.csv
#   （官方 run 脚本收尾 `tar -zcvf ${WORKDIR}/${OUTDIR}.tar.gz ${OUTDIR}`，
#    cov_over_time.csv 就产在 OUTDIR 里 → tar 内必然带得上）。
#   QA 已实测验证（无任何预置的干净环境下）：
#     · 6/6 容器 l_per/b_per 全部取到
#     · 取到的文件与「官方 tar 直取」版本**逐字节相同**（md5 一致）
#   → 保留预置会**掩盖「tar 取不到」这类真实故障**（让采集只剩一条路径，
#     故障时无法区分是采集逻辑坏了还是产物缺失）→ 故移除。

# 备份第一次的 summary，重采
if [[ -f /home/zxy/rq4/rq4_summary.csv ]]; then
  cp /home/zxy/rq4/rq4_summary.csv /home/zxy/rq4/rq4_summary.round1.csv
  log "第一次 summary 已备份为 rq4_summary.round1.csv"
  rm -f /home/zxy/rq4/rq4_summary.csv
fi

log "重跑 rq4_collect.sh"
bash /home/zxy/rq4/scripts/rq4_collect.sh --summary /home/zxy/rq4/rq4_summary.csv >> "$LOG" 2>&1
log "collect rc=$?"

log "重跑 rq4_analyze.py"
python3 /home/zxy/rq4/scripts/rq4_analyze.py \
    --summary /home/zxy/rq4/rq4_summary.csv \
    --out-root /home/zxy/rq4/out --out-dir /home/zxy/rq4/analysis --plot >> "$LOG" 2>&1
log "analyze rc=$?"

log "重跑 QA 独立复核"
python3 /home/zxy/rq4/qa_rq4_verify2.py \
    --out-root /home/zxy/rq4/out --summary /home/zxy/rq4/rq4_summary.csv \
    --analyze-md /home/zxy/rq4/analysis/rq4_report.md \
    --json-out /home/zxy/rq4/analysis/qa_independent_verify.json >> "$LOG" 2>&1
log "qa_verify rc=$?"

log "重跑 QA 完整表"
python3 /home/zxy/rq4/qa_full_table.py \
    --summary /home/zxy/rq4/rq4_summary.csv --out-root /home/zxy/rq4/out \
    --md-out /home/zxy/rq4/analysis/qa_full_table.md \
    --json-out /home/zxy/rq4/analysis/qa_full_table.json >> "$LOG" 2>&1
log "qa_full_table rc=$?"

log "重跑 QA 口径C"
python3 /home/zxy/rq4/qa_cost_to_reach.py \
    --out-root /home/zxy/rq4/out \
    --json-out /home/zxy/rq4/analysis/qa_cost_to_reach.json \
    --md-out /home/zxy/rq4/analysis/qa_cost_to_reach.md >> "$LOG" 2>&1
log "qa_cost_to_reach rc=$?"

log "重跑 QA 最终报告"
python3 /home/zxy/rq4/qa_rq4_final_report.py \
    --summary /home/zxy/rq4/rq4_summary.csv --out-root /home/zxy/rq4/out \
    --verify-json /home/zxy/rq4/analysis/qa_independent_verify.json \
    --cost-json /home/zxy/rq4/analysis/qa_cost_to_reach.json \
    --md-out /home/zxy/rq4/analysis/qa_final_report.md >> "$LOG" 2>&1
log "qa_final_report rc=$?"

log "=== followup done ==="
