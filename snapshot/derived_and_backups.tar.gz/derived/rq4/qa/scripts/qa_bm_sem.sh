#!/bin/bash
docker exec rq4_sip_protorag_r1 bash -c 'python3 - <<PY
src = open("/home/ubuntu/aflnet/afl-fuzz.c", errors="replace").read()
lines = src.split("\n")
i = next(i for i,l in enumerate(lines) if "count_non_255_bytes(virgin_bits)" in l)
print("=== count_non_255_bytes(virgin_bits) 上下文 ===")
print("\n".join(lines[i-6:i+4]))
print()
print("=== virgin_bits 声明 ===")
for j,l in enumerate(lines):
    if "virgin_bits[" in l and ("=" in l or "u8" in l):
        print(f"{j+1}: {l.strip()}"); break
print()
print("=== vir_bits（AFLNet 状态位图）是否参与 bitmap_cvg ===")
print("vir_bits 出现在 count_non_255_bytes 调用附近:", 
      any("vir_bits" in lines[k] for k in range(max(0,i-8), min(len(lines), i+4))))
print()
print("=== count_non_255_bytes 实现 ===")
k = next(j for j,l in enumerate(lines) if "count_non_255_bytes" in l and "(" in l and "static" in l)
print("\n".join(lines[k:k+18]))
PY'
