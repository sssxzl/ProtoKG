#!/bin/bash
docker exec rq4_sip_protorag_r1 bash -c 'sed -n "3555,3640p" /home/ubuntu/aflnet/afl-fuzz.c' | grep -nE 'total_execs|perform_testcase|fuzz_one|for *\(|write_stats' 
echo "---- 3310-3325 (total_execs++) 上下文 ----"
docker exec rq4_sip_protorag_r1 bash -c 'sed -n "3300,3325p" /home/ubuntu/aflnet/afl-fuzz.c'
