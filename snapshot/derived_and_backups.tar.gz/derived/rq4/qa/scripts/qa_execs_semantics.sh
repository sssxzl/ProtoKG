#!/bin/bash
docker exec rq4_sip_protorag_r1 bash -c 'python3 - <<PY
import re
src = open("/home/ubuntu/aflnet/afl-fuzz.c", errors="replace").read()
lines = src.split("\n")
# 找 perform_dry_run 函数体范围
start = next(i for i,l in enumerate(lines) if l.startswith("static void perform_dry_run"))
end = start
depth = 0
for i in range(start, min(start+400, len(lines))):
    depth += lines[i].count("{") - lines[i].count("}")
    if depth == 0 and i > start:
        end = i; break
body = "\n".join(lines[start:end+1])
print("perform_dry_run 行范围:", start+1, "-", end+1)
print("  体内含 total_execs++ :", "total_execs++" in body)
print("  体内含 run_target    :", "run_target" in body)
print("  体内含 perform_testcase:", "perform_testcase" in body)
# execs_done 定义
for i,l in enumerate(lines):
    if "execs_done" in l and ("=" in l) and "total_execs" in l:
        print("execs_done 定义:", i+1, l.strip())
print()
print("--- perform_dry_run 前 40 行 ---")
print("\n".join(lines[start:start+42]))
PY'
