# -*- coding: utf-8 -*-
"""qa_full_table.py —— RQ4 四组×两口径完整对比表（QA 独立生成，不依赖 rq4_analyze.py）。

产出：
  1. 主对比表：终值 bitmap_cvg / execs 对齐 bitmap_cvg / l_per / b_per / 崩溃 / paths 等
  2. 两个口径的差值与同向性判定
  3. 对齐窗口明细（起点/终点 execs、公共重叠验证）
  4. 种子数量效应分解（窗口起点覆盖差 / 模糊期覆盖增量差）
  5. Markdown 输出

用法:
    python3 qa_full_table.py --summary CSV --out-root DIR [--md-out FILE] [--json-out FILE]
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROTO_ORDER = ["rtsp", "sip", "smtp"]
GROUP_ORDER = ["protorag", "baseline"]
FRACS = (0.25, 0.5, 0.75, 1.0)


def _field(text: str, key: str) -> str:
    m = re.search(r"^" + re.escape(key) + r"\s*:\s*(.*?)\s*$", text, re.MULTILINE)
    return m.group(1) if m else ""


def _num(raw: str) -> Optional[float]:
    s = str(raw).strip().replace("%", "").replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def load_series(out_root: Path, proto: str, group: str, rep: int = 1
                ) -> List[Tuple[int, float]]:
    d = out_root / proto / group / f"r{rep}"
    if not d.is_dir():
        return []
    raw: List[Tuple[int, float, int]] = []
    for snap in d.glob("stats_*.txt"):
        try:
            ts = int(snap.stem.split("_")[-1])
        except ValueError:
            continue
        try:
            text = snap.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ex = _num(_field(text, "execs_done"))
        cov = _num(_field(text, "bitmap_cvg"))
        if ex is None or cov is None:
            continue
        raw.append((int(ex), cov, ts))
    raw.sort(key=lambda x: (x[0], x[2]))
    dedup: Dict[int, float] = {}
    for ex, cov, _ts in raw:
        dedup[ex] = cov
    return sorted(dedup.items())


def interp(series, target):
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    for (x0, y0), (x1, y1) in zip(series, series[1:]):
        if x0 <= target <= x1:
            if x1 == x0:
                return y0
            return y0 + (y1 - y0) * (target - x0) / (x1 - x0)
    return series[-1][1]


def load_summary(path: Path) -> Dict[Tuple[str, str, int], Dict]:
    out: Dict[Tuple[str, str, int], Dict] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        for raw in csv.DictReader(fh):
            row = {(k or "").strip(): (v if v is not None else "")
                   for k, v in raw.items()}
            key = (row.get("protocol", ""), row.get("group", ""),
                   int(row.get("rep") or 0))
            out[key] = row
    return out


def fmt(v: Optional[float], nd: int = 2) -> str:
    if v is None:
        return "—"
    if float(v).is_integer() and nd == 0:
        return str(int(v))
    return f"{v:.{nd}f}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--md-out", default="")
    ap.add_argument("--json-out", default="")
    args = ap.parse_args()

    rows = load_summary(Path(args.summary))
    out_root = Path(args.out_root)

    data: Dict[str, Dict] = {}
    for proto in PROTO_ORDER:
        entry: Dict = {}
        for grp in GROUP_ORDER:
            r = rows.get((proto, grp, 1))
            if r is None:
                continue
            entry[grp] = {
                "container": r.get("container", ""),
                "bitmap_cvg_final": _num(r.get("bitmap_cvg", "")),
                "execs_done": _num(r.get("execs_done", "")),
                "execs_per_sec": _num(r.get("execs_per_sec", "")),
                "fuzz_sec": _num(r.get("fuzz_sec", "")),
                "cycles_done": _num(r.get("cycles_done", "")),
                "paths_total": _num(r.get("paths_total", "")),
                "paths_found": _num(r.get("paths_found", "")),
                "max_depth": _num(r.get("max_depth", "")),
                "stability": _num(r.get("stability", "")),
                "unique_crashes": _num(r.get("unique_crashes", "")),
                "unique_hangs": _num(r.get("unique_hangs", "")),
                "l_per": _num(r.get("l_per", "")),
                "b_per": _num(r.get("b_per", "")),
                "seed_files": _num(r.get("seed_files", "")),
                "seed_regions": _num(r.get("seed_regions", "")),
                "dict_tokens": _num(r.get("dict_tokens", "")),
                "param_check": r.get("param_check", ""),
            }
        data[proto] = entry

    md: List[str] = []
    md.append("# RQ4 独立复核：四组 × 两口径完整对比表")
    md.append("")
    md.append("> 本表由 QA **独立脚本**生成（`qa_full_table.py`，不 import `rq4_analyze.py`）。")
    md.append("> `bitmap_cvg` = AFLNet 自报边覆盖%；`l_per`/`b_per` = cov_script 行/分支覆盖%。")
    md.append("> **单次运行（n=1），无重复，无统计效力 —— 差值仅为观测值，不构成显著性结论。**")
    md.append("")

    json_data: Dict = {"protocols": {}}

    # ---------------- 表 1：主对比表 ----------------
    md.append("## 表 1　主对比表（每协议 2 组 × 全部指标）")
    md.append("")
    md.append("| 协议 | 组 | 容器 | bitmap_cvg 终值(%) | execs_done | execs/s | cycles | paths_total | paths_found | max_depth | stability(%) | crashes | hangs | l_per(%) | b_per(%) | seed_files | seed_regions | dict | 参数自检 |")
    md.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        for grp in GROUP_ORDER:
            e = data.get(proto, {}).get(grp)
            if not e:
                continue
            md.append(
                f"| {proto} | {grp} | `{e['container']}` | {fmt(e['bitmap_cvg_final'])} | "
                f"{fmt(e['execs_done'], 0)} | {fmt(e['execs_per_sec'])} | {fmt(e['cycles_done'], 0)} | "
                f"{fmt(e['paths_total'], 0)} | {fmt(e['paths_found'], 0)} | {fmt(e['max_depth'], 0)} | "
                f"{fmt(e['stability'])} | {fmt(e['unique_crashes'], 0)} | {fmt(e['unique_hangs'], 0)} | "
                f"{fmt(e['l_per'])} | {fmt(e['b_per'])} | {fmt(e['seed_files'], 0)} | "
                f"{fmt(e['seed_regions'], 0)} | {fmt(e['dict_tokens'], 0)} | {e['param_check']} |")
    md.append("")

    # ---------------- 表 2：两口径差值 ----------------
    md.append("## 表 2　两个口径的差值与同向性")
    md.append("")
    md.append("| 协议 | 口径A：3h 终值 bitmap_cvg 差 | 口径B：execs 对齐处 bitmap_cvg 差 | A/B 是否同向 | l_per 差 | bitmap_cvg vs l_per 是否同向 | 判定 |")
    md.append("|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        e = data.get(proto, {})
        pro, bas = e.get("protorag"), e.get("baseline")
        if not pro or not bas:
            continue
        s_pro = load_series(out_root, proto, "protorag")
        s_bas = load_series(out_root, proto, "baseline")
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        c_pro_hi = interp(s_pro, hi)
        c_bas_hi = interp(s_bas, hi)
        d_align = (None if (c_pro_hi is None or c_bas_hi is None)
                   else round(c_pro_hi - c_bas_hi, 4))
        a, b = pro["bitmap_cvg_final"], bas["bitmap_cvg_final"]
        d_final = None if (a is None or b is None) else round(a - b, 4)
        d_lp = (None if (pro["l_per"] is None or bas["l_per"] is None)
                else round(pro["l_per"] - bas["l_per"], 4))
        same_ab = None
        if d_final is not None and d_align is not None:
            same_ab = (d_final == 0 or d_align == 0 or (d_final > 0) == (d_align > 0))
        same_bc_lp = None
        if d_final is not None and d_lp is not None:
            same_bc_lp = (d_final == 0 or d_lp == 0 or (d_final > 0) == (d_lp > 0))
        verdict = "—" if same_ab is None else ("一致（同向）" if same_ab else "★不一致（异向）")
        md.append(f"| {proto} | {fmt(d_final):>8} | {fmt(d_align):>8} | "
                  f"{'—' if same_ab is None else ('是' if same_ab else '**否**')} | "
                  f"{fmt(d_lp):>8} | "
                  f"{'—' if same_bc_lp is None else ('是' if same_bc_lp else '**否**')} | "
                  f"{verdict} |")
        json_data["protocols"].setdefault(proto, {})[grp + "_final"] = None
        json_data["protocols"][proto] = {
            "delta_final_bitmap_cvg": d_final,
            "delta_aligned_bitmap_cvg": d_align,
            "two_criteria_same_direction": same_ab,
            "delta_l_per": d_lp,
            "bitmap_cvg_vs_l_per_same_direction": same_bc_lp,
            "window": {"common_start_execs": lo, "common_end_execs": hi},
        }
    md.append("")

    # ---------------- 表 3：对齐窗口明细 ----------------
    md.append("## 表 3　execs_done 对齐窗口明细（是否公共重叠区间）")
    md.append("")
    md.append("| 协议 | protorag execs 区间 | baseline execs 区间 | 窗口起点 execs | 窗口终点 execs | 窗口跨度 | 是否公共重叠 | 终点受限于 |")
    md.append("|---|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        s_pro = load_series(out_root, proto, "protorag")
        s_bas = load_series(out_root, proto, "baseline")
        if not s_pro or not s_bas:
            continue
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        limited = ("protorag" if hi == s_pro[-1][0] and hi < s_bas[-1][0]
                   else ("baseline" if hi == s_bas[-1][0] and hi < s_pro[-1][0] else "两者相同"))
        is_ov = (lo >= s_pro[0][0] and lo >= s_bas[0][0]
                 and hi <= s_pro[-1][0] and hi <= s_bas[-1][0])
        md.append(f"| {proto} | {s_pro[0][0]} – {s_pro[-1][0]} | {s_bas[0][0]} – {s_bas[-1][0]} | "
                  f"{lo} | {hi} | {hi-lo} | {'✓ 是' if is_ov else '✗ 否'} | {limited} |")
    md.append("")

    # ---------------- 表 4：对齐点逐点 ----------------
    md.append("## 表 4　execs 对齐点逐点 bitmap_cvg（窗口 25% / 50% / 75% / 100%）")
    md.append("")
    md.append("| 协议 | 对齐 execs | protorag | baseline | 差值 |")
    md.append("|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        s_pro = load_series(out_root, proto, "protorag")
        s_bas = load_series(out_root, proto, "baseline")
        if not s_pro or not s_bas:
            continue
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        for frac in FRACS:
            t = int(lo + (hi - lo) * frac)
            c1, c2 = interp(s_pro, t), interp(s_bas, t)
            d = None if (c1 is None or c2 is None) else c1 - c2
            md.append(f"| {proto} | {t} | {fmt(c1)} | {fmt(c2)} | "
                      f"{'—' if d is None else f'{d:+.2f}'} |")
    md.append("")

    # ---------------- 表 5：种子数量效应分解 ----------------
    md.append("## 表 5　「种子数量」效应分解（execs 对齐能剥离什么 / 不能剥离什么）")
    md.append("")
    md.append("| 协议 | 种子数比 (protorag/baseline) | 窗口起点 cov：protorag | 窗口起点 cov：baseline | 起点差（种子头部效应） | 模糊期覆盖增量：protorag | 模糊期覆盖增量：baseline | 增量差 |")
    md.append("|---|---|---|---|---|---|---|---|")
    for proto in PROTO_ORDER:
        e = data.get(proto, {})
        pro, bas = e.get("protorag"), e.get("baseline")
        if not pro or not bas:
            continue
        s_pro = load_series(out_root, proto, "protorag")
        s_bas = load_series(out_root, proto, "baseline")
        if not s_pro or not s_bas:
            continue
        lo = max(s_pro[0][0], s_bas[0][0])
        hi = min(s_pro[-1][0], s_bas[-1][0])
        p0, p1 = interp(s_pro, lo), interp(s_pro, hi)
        b0, b1 = interp(s_bas, lo), interp(s_bas, hi)
        ratio = (pro["seed_files"] / bas["seed_files"]
                 if pro["seed_files"] and bas["seed_files"] else None)
        md.append(
            f"| {proto} | {fmt(ratio)}× | {fmt(p0)} | {fmt(b0)} | "
            f"{'—' if (p0 is None or b0 is None) else f'{p0-b0:+.2f}'} | "
            f"{'—' if (p1 is None or p0 is None) else f'{p1-p0:+.2f}'} | "
            f"{'—' if (b1 is None or b0 is None) else f'{b1-b0:+.2f}'} | "
            f"{'—' if None in (p1, p0, b1, b0) else f'{(p1-p0)-(b1-b0):+.2f}'} |")
    md.append("")

    text = "\n".join(md)
    if args.md_out:
        p = Path(args.md_out)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {p}")
    else:
        print(text)
    if args.json_out:
        p = Path(args.json_out)
        p.write_text(json.dumps(json_data, ensure_ascii=False, indent=2),
                     encoding="utf-8")
        print(f"[qa] JSON 写出: {p}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
