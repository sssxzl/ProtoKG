#!/bin/bash
echo "=== perform_dry_run 全文（看是否走 total_execs++ 路径）==="
docker exec rq4_sip_protorag_r1 bash -c 'sed -n "3555,3660p" /home/ubuntu/aflnet/afl-fuzz.c' | grep -nE 'total_execs|perform_testcase|fuzz_one|for *\(|write_stats|execs_done'
echo ""
echo "=== 3319 total_execs++ 所在函数 ==="
docker exec rq4_sip_protorag_r1 bash -c 'awk "NR>=3150 && NR<=3325 && /^[a-zA-Z].*\(/ {print NR\": \"\$0}" /home/ubuntu/aflnet/afl-fuzz.c' | tail -5
