#!/bin/bash
echo "=== 空值行在 CSV 中的位置（行号 vs 当前总行数）==="
for spec in "rq4_sip_protorag_r1 protorag" "rq4_sip_baseline_r1 baseline"; do
  set -- $spec; c=$1; g=$2
  docker exec "$c" sh -c "cat /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null \
    | awk -F, -v c="$c" 'NR==1{next} {tot++; if (NF!=5||$2==""||$4=="") {print "  "c" 空值行位于第 "tot" 行 / 共 "tot" 行"}}'
done
echo ""
echo "=== cov_over_time.csv 文件 mtime（最后写入时刻）==="
for spec in "rq4_sip_protorag_r1 protorag" "rq4_sip_baseline_r1 baseline"; do
  set -- $spec; c=$1; g=$2
  docker exec "$c" sh -c "ls -la --time-style=full-iso /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null
done
echo ""
echo "=== 容器内 /tmp 与 / 空间现状 ==="
for c in rq4_sip_protorag_r1 rq4_sip_baseline_r1; do
  echo "--- $c"
  docker exec "$c" df -h / /tmp 2>/dev/null | tail -3
done
echo ""
echo "=== 宿主 /tmp 残留（gcovr 临时目录）==="
ls -d /tmp/tmp* 2>/dev/null | head -5
ls -d /tmp/tmp* 2>/dev/null | wc -l
