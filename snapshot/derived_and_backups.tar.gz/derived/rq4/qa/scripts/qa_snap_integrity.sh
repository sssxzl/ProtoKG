#!/bin/bash
echo "=== 快照文件完整性检查（空/截断/行数异常）==="
for spec in "rtsp protorag" "rtsp baseline" "sip protorag" "sip baseline" "smtp protorag" "smtp baseline"; do
  set -- $spec; p=$1; g=$2
  d=/home/zxy/rq4/out/$p/$g/r1
  tot=$(ls $d/stats_*.txt 2>/dev/null | wc -l)
  empty=$(find $d -name 'stats_*.txt' -size -100c 2>/dev/null | wc -l)
  # 缺少 execs_done 或 bitmap_cvg 的
  bad=$(grep -L 'execs_done' $d/stats_*.txt 2>/dev/null | wc -l)
  nocov=$(grep -L 'bitmap_cvg' $d/stats_*.txt 2>/dev/null | wc -l)
  echo "  $p/$g: 总数=$tot  <100字节=$empty  缺execs_done=$bad  缺bitmap_cvg=$nocov"
done
echo ""
echo "=== 13:15 之后写入的快照（磁盘满窗口）是否有损坏 ==="
for spec in "rtsp protorag" "rtsp baseline" "sip protorag" "sip baseline" "smtp protorag" "smtp baseline"; do
  set -- $spec; p=$1; g=$2
  d=/home/zxy/rq4/out/$p/$g/r1
  n=0; bad=0
  for f in $d/stats_*.txt; do
    ts=$(echo "$f" | sed -E 's/.*stats_([0-9]+)\.txt/\1/')
    if [ "$ts" -ge 1793335000 ] 2>/dev/null; then   # 13:15 之后
      n=$((n+1))
      grep -q 'execs_done' "$f" 2>/dev/null || bad=$((bad+1))
    fi
  done
  echo "  $p/$g: 13:15后快照数=$n 其中缺execs_done=$bad"
done
