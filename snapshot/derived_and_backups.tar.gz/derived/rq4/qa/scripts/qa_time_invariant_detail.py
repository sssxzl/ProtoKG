import pathlib

root = pathlib.Path('/home/zxy/rq4/out')
SEEDS = {'rtsp': {'protorag': 39, 'baseline': 7},
         'sip': {'protorag': 25, 'baseline': 1},
         'smtp': {'protorag': 78, 'baseline': 2}}

print('=== 逐文件：Time 倒退的精确位置与「段边界 = 种子数」的关系 ===')
for proto in ['rtsp', 'sip', 'smtp']:
    for grp in ['protorag', 'baseline']:
        f = root / proto / grp / 'r1' / 'cov_over_time.csv'
        if not f.exists():
            continue
        lines = [l.strip() for l in f.read_text(errors='replace').splitlines() if l.strip()]
        hdr = lines[0].split(',')
        rows = []
        empty = []
        for i, l in enumerate(lines[1:], 1):
            p = l.split(',')
            if len(p) != len(hdr):
                continue
            try:
                t = int(p[0])
            except ValueError:
                continue
            rows.append((i, t))
            if len(p) > 1 and p[1].strip() == '':
                empty.append(i)
        backs = []
        for i in range(1, len(rows)):
            if rows[i][1] < rows[i - 1][1]:
                backs.append((rows[i - 1][0], rows[i - 1][1], rows[i][0], rows[i][1]))
        ns = SEEDS[proto][grp]
        print(f'  {proto}/{grp}: 种子数={ns}  数据行={len(rows)}  空值行={empty}')
        for (r0, t0, r1, t1) in backs:
            mark = '✓ 恰在段边界(行=种子数)' if r0 == ns else f'✗ 段边界应为行{ns}'
            print(f'      倒退: 行{r0}(Time={t0}) → 行{r1}(Time={t1})   [{mark}]')
        if not backs:
            print('      无倒退 → 段边界处 Time 未下降')
        # 段边界两侧的 Time 范围
        if ns <= len(rows):
            seg1 = [r[1] for r in rows[:ns]]
            seg2 = [r[1] for r in rows[ns:]]
            print(f'      段1(Time=种子mtime) max={max(seg1) if seg1 else "-"}  '
                  f'段2 max={max(seg2) if seg2 else "-"}  '
                  f'→ 段2 是否覆盖段1: {bool(seg2) and bool(seg1) and max(seg2) >= max(seg1)}')
        print()
