# -*- coding: utf-8 -*-
"""qa_coverscript_invariants.py —— 独立验证 `cov_script` 输出 CSV 的三条结构性不变量。

工程师（software-engineer-2）提出三条断言，QA 独立复核：
  I1. **Time 列每个文件恰好倒退 1 次**（段边界）→ 印证「段1 逐种子回放 / 段2 每5用例采样」
  I2. **末行始终是 Time 最大的行** → 「末行 = 终值」成立（新版 cov_last_row 依赖此不变量）
  I3. **SMTP protorag 的 l_abs 冻结**（后 144 行 l_abs 全 = 2564，取值种类 = 1），
      baseline 同段有 30 种不同值

I2 是**新版 cov_last_row 正确性的前提**（若末行不是 Time 最大行，"取末行=终值"就不成立），
必须独立验证 —— 不能只信任何一方的口述。

本脚本**不 import rq4_analyze.py**，独立实现。
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SEEDS = {"rtsp": {"protorag": 39, "baseline": 7},
         "sip": {"protorag": 25, "baseline": 1},
         "smtp": {"protorag": 78, "baseline": 2}}


def load(path: Path) -> List[Dict]:
    """读 cov_over_time.csv → [{'time':int,'l_per':float|None,'l_abs':float|None,...}]。

    ★ 保留**空值行**（该列为空的行），因为 I2/I3 的验证恰恰要看它们的位置。
    """
    if not path.exists():
        return []
    lines = [l.strip() for l in path.read_text(errors="replace").splitlines() if l.strip()]
    if not lines:
        return []
    hdr = [h.strip() for h in lines[0].split(",")]
    out: List[Dict] = []
    for l in lines[1:]:
        p = l.split(",")
        if len(p) != len(hdr):
            continue
        rec = dict(zip(hdr, p))
        try:
            rec["t"] = int(rec.get("Time", "0"))
        except ValueError:
            continue
        for k in ("l_per", "l_abs", "b_per", "b_abs"):
            try:
                rec[k] = float(rec[k])
            except (KeyError, ValueError):
                rec[k] = None      # 空值行 → None（测量缺失，不是 0）
        out.append(rec)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()
    root = Path(args.out_root)

    res: Dict = {"invariants": {}}
    md: List[str] = []
    md.append("# `cov_script` 输出 CSV 的结构性不变量 —— 独立复核")
    md.append("")
    md.append("> 复核对象：工程师提出的三条断言。**I2 是新版 `cov_last_row` 正确性的前提**"
              "（若末行不是 Time 最大的行，「取末行 = 终值」就不成立）。")
    md.append("")

    # ---------- I1 + I2 ----------
    md.append("## I1 / I2　Time 列的单调性结构 与「末行 = Time 最大行」")
    md.append("")
    md.append("| 协议 | 组 | 数据行 | 空值行 | Time 倒退次数 | 倒退位置(行号) | 末行=Time最大行? | 段边界行 |")
    md.append("|---|---|---|---|---|---|---|---|")
    all_i1 = all_i2 = True
    for proto in ("rtsp", "sip", "smtp"):
        for grp in ("protorag", "baseline"):
            rows = load(root / proto / grp / "r1" / "cov_over_time.csv")
            if not rows:
                continue
            ts = [r["t"] for r in rows]
            # ★ 倒退发生在第 i 行 → 第 i+1 行之间；**段边界行号 = i**（= 种子数），
            #   而非 i+1。判据必须比对**边界行号**。
            backs = [(i, ts[i - 1], ts[i]) for i in range(1, len(ts)) if ts[i] < ts[i - 1]]
            max_t = max(ts)
            last_is_max = (ts[-1] == max_t)
            n_empty = sum(1 for r in rows if r["l_per"] is None)
            # I1 修正后的判据：倒退**若发生**必须恰在段边界（行号 == 种子数），
            # 且倒退次数 ∈ {0, 1}（0 次的情形 = 种子数极少、单种子 mtime 早于首个 fuzz 用例）
            i1_ok = (len(backs) <= 1
                     and (not backs or backs[0][0] == SEEDS[proto][grp]))
            i2_ok = last_is_max
            all_i1 = all_i1 and i1_ok
            all_i2 = all_i2 and i2_ok
            bpos = backs[0][0] if backs else None   # 边界行号 = 前一行行号
            md.append(f"| {proto} | {grp} | {len(rows)} | {n_empty} | {len(backs)} | "
                      f"{bpos if bpos else '—'} | {'✓ 是' if i2_ok else '✗ 否'} | "
                      f"{'行 ' + str(bpos) if bpos else '—'} |")
            res["invariants"].setdefault(proto, {})[grp] = {
                "n_rows": len(rows), "n_empty_rows": n_empty,
                "time_backwards_count": len(backs),
                "time_backwards_positions": [b[0] for b in backs],
                "time_backwards_boundary_rows": [b[0] for b in backs],
                "last_row_is_max_time": i2_ok,
                "max_time": max_t, "last_time": ts[-1],
                "i1_ok": i1_ok, "i2_ok": i2_ok,
                "n_seed": SEEDS[proto][grp],
                "backwards_at_seed_boundary": (
                    bpos == SEEDS[proto][grp] if bpos else None),
            }
    md.append("")
    md.append(f"- **I1（Time 倒退**若发生**恰在段边界，倒退次数 ∈ {{0,1}}）**："
              f"{'✓ 6/6 全部成立' if all_i1 else '✗ 有反例'}")
    md.append("  - 4/6 个文件出现倒退且**行号恰等于该组种子数**；另 2 个（`sip/baseline` 种子数 1、"
              "`smtp/baseline` 种子数 2）**不出现** —— 因其单个种子的 mtime 恰好**早于**"
              "第一个 fuzz 生成的测试用例 mtime，段边界处不构成「倒退」。")
    md.append("  - → **精确表述**：不是「Time 恰好倒退 1 次」（那对 2/6 是反例），"
              "而是「倒退**若发生**恰落在段边界」。")
    md.append(f"- **I2（末行 = Time 最大行）**：{'✓ 6/6 全部成立' if all_i2 else '✗ 有反例'}"
              "　→ 新版 `cov_last_row` 的「末行 = 终值」语义**前提成立**")
    md.append("")

    # ---------- I3 ----------
    md.append("## I3　SMTP 的 l_abs 冻结")
    md.append("")
    md.append("| 协议 | 组 | 模糊阶段采样点数 | 该段 l_abs 取值种类 | l_abs 最小 | l_abs 最大 | 是否冻结 |")
    md.append("|---|---|---|---|---|---|---|")
    for proto in ("rtsp", "sip", "smtp"):
        for grp in ("protorag", "baseline"):
            rows = load(root / proto / grp / "r1" / "cov_over_time.csv")
            if not rows:
                continue
            n_seed = SEEDS[proto][grp]
            seg = [r for r in rows[SEEDS[proto][grp]:] if r["l_abs"] is not None]
            if not seg:
                continue
            vals = sorted({r["l_abs"] for r in seg})
            frozen = len(vals) == 1
            md.append(f"| {proto} | {grp} | {len(seg)} | {len(vals)} | "
                      f"{min(vals):.0f} | {max(vals):.0f} | "
                      f"{'**✓ 冻结**' if frozen else '否（持续增长）'} |")
            res["invariants"].setdefault(proto, {}).setdefault(grp, {})["fuzz_stage"] = {
                "n_points": len(seg), "l_abs_distinct_values": len(vals),
                "l_abs_min": min(vals), "l_abs_max": max(vals), "frozen": frozen,
                "l_abs_values_sample": vals[:5] + (["..."] if len(vals) > 5 else []),
            }
    md.append("")
    md.append("> 「模糊阶段」= 跳过该组的前 N_seed 行（段1 逐种子回放），其余为段2。")
    md.append("> ★ 注意：**只有 SMTP/protorag 冻结**；RTSP/SIP 两组 l_abs 都持续增长 → "
              "这正是「SMTP protorag 撞上覆盖天花板」这一结论的数据依据。")

    res["i1_all_ok"] = all_i1
    res["i2_all_ok"] = all_i2
    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
