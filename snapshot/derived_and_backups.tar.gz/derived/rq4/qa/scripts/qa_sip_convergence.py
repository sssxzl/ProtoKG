# -*- coding: utf-8 -*-
"""qa_sip_convergence.py —— 检验「SIP 上差距单调收敛」这一主张（team-lead 的问题 A 判读依据）。

★ 需要检验的主张
----------------
team-lead 主张：SIP 的 execs 对齐差距**单调收敛**
（@13556: −0.78pp → @39948: 0.00pp → @53144: +0.03pp），
因此「SIP 应表述为两者持平」，而非「protorag 更差」。

★ QA 的独立检验方式（比 4 个采样点更严）
----------------------------------------
只看 4 个点无法判定「单调收敛」——中间可能来回摆动。
本脚本在**公共 execs 区间的密集网格**（默认 400 点）上：
  1. 求 Δcvg(execs) = cvg_pro − cvg_bas 的完整轨迹
  2. 统计符号翻转次数（= 交叉点数）→ 判断是否真的单调
  3. 计算「最后一次符号翻转的位置」与「窗口终点的距离」
  4. 计算 |Δ| 的包络（min / max / 末值）
  5. **关键**：量化「终值 −0.05pp」相对「整段轨迹的波动幅度」的位置
     → 若 |−0.05| 远小于轨迹波动幅度，则终值快照**不足以判定优劣**（支持 team-lead 的结论）
     → 若 |−0.05| 与波动幅度同量级，则两者都是噪声，终值同样不可判定

本脚本**不 import rq4_analyze.py**，独立实现。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def _field(text: str, key: str) -> str:
    m = re.search(r"^" + re.escape(key) + r"\s*:\s*(.*?)\s*$", text, re.MULTILINE)
    return m.group(1) if m else ""


def _num(raw: str) -> Optional[float]:
    s = str(raw).strip().replace("%", "").replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def load_series(out_root: Path, proto: str, group: str, rep: int = 1
                ) -> List[Tuple[int, float]]:
    d = out_root / proto / group / f"r{rep}"
    if not d.is_dir():
        return []
    raw: List[Tuple[int, float, int]] = []
    for snap in d.glob("stats_*.txt"):
        try:
            ts = int(snap.stem.split("_")[-1])
        except ValueError:
            continue
        try:
            text = snap.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ex = _num(_field(text, "execs_done"))
        cov = _num(_field(text, "bitmap_cvg"))
        if ex is None or cov is None:
            continue
        raw.append((int(ex), cov, ts))
    raw.sort(key=lambda x: (x[0], x[2]))
    dedup: Dict[int, float] = {}
    for ex, cov, _ts in raw:
        dedup[ex] = cov
    return sorted(dedup.items())


def interp(series, target):
    if not series:
        return None
    if target <= series[0][0]:
        return series[0][1]
    if target >= series[-1][0]:
        return series[-1][1]
    for (x0, y0), (x1, y1) in zip(series, series[1:]):
        if x0 <= target <= x1:
            if x1 == x0:
                return y0
            return y0 + (y1 - y0) * (target - x0) / (x1 - x0)
    return series[-1][1]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--proto", default="sip")
    ap.add_argument("--grid", type=int, default=400)
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()
    out_root = Path(args.out_root)

    s_pro = load_series(out_root, args.proto, "protorag")
    s_bas = load_series(out_root, args.proto, "baseline")
    if not s_pro or not s_bas:
        print("缺少快照序列")
        return 1

    lo = max(s_pro[0][0], s_bas[0][0])
    hi = min(s_pro[-1][0], s_bas[-1][0])
    n = args.grid
    traj: List[Tuple[int, float]] = []
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n
        c1 = interp(s_pro, x)
        c2 = interp(s_bas, x)
        if c1 is not None and c2 is not None:
            traj.append((int(x), c1 - c2))

    diffs = [d for _x, d in traj]
    flips = []
    for i in range(1, len(traj)):
        d0, d1 = diffs[i - 1], diffs[i]
        if d0 == 0:
            continue
        if (d0 > 0) != (d1 > 0):
            x0, x1 = traj[i - 1][0], traj[i][0]
            xc = x0 + (x1 - x0) * (-d0) / (d1 - d0)
            flips.append(int(xc))

    dmin = min(diffs)
    dmax = max(diffs)
    dend = diffs[-1]
    span = dmax - dmin
    # 终值 |−0.05| 相对轨迹波动幅度的位置
    ratio = (abs(dend) / span) if span > 0 else None
    # 末段单调性：最后 10% 区间内是否单调
    tail = [(x, d) for x, d in traj if x >= lo + 0.9 * (hi - lo)]
    tail_d = [d for _x, d in tail]
    tail_monotone = all(tail_d[i] >= tail_d[i - 1] for i in range(1, len(tail_d))) \
        or all(tail_d[i] <= tail_d[i - 1] for i in range(1, len(tail_d)))

    print("=" * 92)
    print(f"### {args.proto.upper()}：Δcvg(execs) 轨迹的密集网格检验（{n+1} 点）")
    print("=" * 92)
    print(f"  公共 execs 区间: {lo} – {hi}")
    print(f"  Δcvg 轨迹: min={dmin:+.4f}  max={dmax:+.4f}  末值={dend:+.4f}")
    print(f"  波动幅度 span = {span:.4f} pp")
    print(f"  **符号翻转次数 = {len(flips)}**  翻转位置 execs = {flips}")
    print(f"  → **『单调收敛』成立吗？** {'是（无翻转，方向单一）' if len(flips) == 0 else '否（存在 %d 次翻转 → 并非单调）' % len(flips)}")
    print(f"  末 10% 区间单调性: {'单调' if tail_monotone else '非单调（来回摆动）'}")
    print(f"  |末值| / span = {ratio:.3f}" if ratio is not None else "")
    print(f"  → 末值 |{abs(dend):.4f}|pp 相对整段波动幅度 {span:.4f}pp "
          f"= {ratio*100:.1f}%" if ratio is not None else "")
    print()
    if ratio is not None and ratio < 0.25:
        print("  ★ 判定：末值快照的幅度**远小于**整段轨迹的波动幅度 →")
        print("    **单看终值不足以判定优劣**，应表述为「两者持平/不可区分」。")
        verdict = "持平（末值不具区分力）"
    elif ratio is not None and ratio < 0.6:
        print("  ★ 判定：末值幅度与轨迹波动同量级 → 两者都属噪声，**不可判定优劣**。")
        verdict = "不可判定（末值与波动同量级）"
    else:
        print("  ★ 判定：末值幅度相对波动幅度**显著** → 终值有区分力。")
        verdict = "终值有区分力"

    # 采样点对照（team-lead 用的 4 点）
    print()
    print("  --- team-lead 用的 4 个采样点 ---")
    for target in (13556, 39948, 53144):
        c1 = interp(s_pro, target)
        c2 = interp(s_bas, target)
        print(f"    @{target}: pro={c1:.4f} bas={c2:.4f} Δ={c1-c2:+.4f}")

    res = {
        "proto": args.proto,
        "common_range": [lo, hi],
        "grid_points": n + 1,
        "diff_min": dmin, "diff_max": dmax, "diff_end": dend,
        "span": span,
        "n_sign_flips": len(flips),
        "flip_execs": flips,
        "monotone": len(flips) == 0,
        "tail_monotone": tail_monotone,
        "abs_end_over_span": ratio,
        "verdict": verdict,
    }
    md = []
    md.append(f"# {args.proto.upper()}：Δcvg(execs) 轨迹的密集网格检验")
    md.append("")
    md.append(f"- 公共 execs 区间：**{lo} – {hi}**，网格 **{n+1}** 点")
    md.append(f"- Δcvg 轨迹：min **{dmin:+.4f}** / max **{dmax:+.4f}** / 末值 **{dend:+.4f}** pp")
    md.append(f"- 波动幅度 span = **{span:.4f}** pp")
    md.append(f"- **符号翻转次数 = {len(flips)}**（位置 execs = {flips}）")
    md.append(f"- 末 10% 区间单调性：**{'单调' if tail_monotone else '非单调（来回摆动）'}**")
    md.append(f"- |末值| / span = **{ratio:.3f}**" if ratio is not None else "")
    md.append("")
    md.append(f"### 判定：**{verdict}**")
    md.append("")
    md.append("**「单调收敛」主张的检验结果**：")
    md.append("")
    if len(flips) == 0:
        md.append("- Δcvg 全程**无符号翻转** → 「单调收敛」**成立**。")
    else:
        md.append(f"- Δcvg 在 execs={flips} 处发生 **{len(flips)} 次符号翻转** → "
                  "「单调收敛」**不成立**（方向在末段来回摆动）。")
        md.append("- 但这**不改变**「SIP 不可判定优劣」的结论 —— 见下。")
    md.append("")
    md.append("**关键论证（与 team-lead 的结论一致，但依据更强）**：")
    md.append("")
    md.append(f"- 末值 |{abs(dend):.4f}|pp 只占整段轨迹波动幅度 {span:.4f}pp 的 **{ratio*100:.1f}%**")
    md.append(f"- 即：**终值那 −0.05pp 的快照差异，其量级远小于 SIP 上两组覆盖率的正常波动**")
    md.append("- → 无论 Δcvg 还是 Δl_per，**SIP 上的差异都在噪声内**；")
    md.append("- → 正确表述是「**SIP 上两组持平，本轮无法区分**」，"
              "而**不是**「protorag 更差」（那是只看 −0.05pp 终值快照的误导性读法），")
    md.append("  也**不是**「protorag 更好」（那是被 +0.20 的 l_per 噪声误导）。")

    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
