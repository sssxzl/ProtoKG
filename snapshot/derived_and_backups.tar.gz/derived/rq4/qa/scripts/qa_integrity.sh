#!/bin/bash
# 校验：预取的 cov_over_time.csv 与 tar 内官方产物是否一致（证明预取没篡改数据）
echo "=== 预取 cov_over_time.csv vs 容器 tar 内官方产物 md5 ==="
for spec in "rtsp protorag rq2-live555:latest /home/ubuntu/experiments/out-rtsp-protorag-r1.tar.gz" \
            "rtsp baseline rq2-live555:latest /home/ubuntu/experiments/out-rtsp-baseline-r1.tar.gz" \
            "smtp protorag rq2-exim:latest    /home/ubuntu/experiments/out-smtp-protorag-r1.tar.gz" \
            "smtp baseline rq2-exim:latest    /home/ubuntu/experiments/out-smtp-baseline-r1.tar.gz"; do
  set -- $spec; p=$1; g=$2; img=$3; tp=$4
  a=/home/zxy/rq4/out/$p/$g/r1/cov_over_time.csv
  T=$(mktemp -d /home/zxy/rq4/qa_tmp.XXXXXX)
  docker cp rq4_${p}_${g}_r1:$tp $T/o.tar.gz >/dev/null 2>&1
  m2=$(docker run --rm -v $T:/out --entrypoint /bin/bash $img \
        -c "cd /out && tar xzOf o.tar.gz 'out-$p-$g-r1/cov_over_time.csv' 2>/dev/null | md5sum | cut -d' ' -f1" 2>/dev/null)
  m1=$(md5sum < "$a" | cut -d' ' -f1)
  if [ "$m1" = "$m2" ]; then v="✓ 一致"; else v="✗ 不一致"; fi
  echo "  $p/$g: prefetch=$m1  tar=$m2  → $v"
  docker run --rm -v $T:/out --entrypoint /bin/bash $img -c 'rm -rf /out/*' >/dev/null 2>&1
  rm -rf $T
done
echo ""
echo "=== 清理 collect.sh 解出的 tar 目录（省磁盘，不影响数据）==="
for d in /home/zxy/rq4/out/*/*/r1/out-*-r1 /home/zxy/rq4/out/*/*/r1/out.tar.gz; do
  [ -e "$d" ] || continue
  docker run --rm -v "$(dirname "$d"):/out" --entrypoint /bin/bash rq2-live555:latest \
    -c 'chmod -R u+w /out 2>/dev/null; rm -rf /out/out.tar.gz /out/out-*-r1' >/dev/null 2>&1
  rm -rf "$d" 2>/dev/null
done
df -h / | tail -1
