# -*- coding: utf-8 -*-
"""qa_fuzz_gain_decomp.py —— 分解「种子阶段贡献」与「模糊阶段新增」，判定覆盖天花板。

★ 要回答的问题
--------------
SMTP 上 protorag 的 l_per 比 baseline 低 8.2pp。差距是：
  (a) **种子阶段就落后**（起跑就弱）→ 种子质量/覆盖面问题
  (b) **模糊阶段被拉开**（起跑相当，后程掉队）→ 变异效率问题
  (c) 两者叠加

判据：把每组的 l_abs 轨迹按「累计回放数」切成
  · **种子阶段**：回放数 ≤ 该组种子数（cov_script 段1，逐个种子）
  · **模糊阶段**：回放数 > 该组种子数（cov_script 段2，每 5 个测试用例写一行）
然后算：
  · 种子阶段末的 l_abs → **起跑覆盖**（种子本身的覆盖面）
  · 模糊阶段末的 l_abs − 种子阶段末的 l_abs → **模糊期新增**（变异效率）

★ 同时检验「覆盖天花板」假设：模糊阶段新增是否为 0。

本脚本**不 import rq4_analyze.py**，独立实现。
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SKIPCOUNT = 5


def load_csv(path: Path) -> List[Dict]:
    if not path.exists():
        return []
    lines = [l.strip() for l in path.read_text(errors="replace").splitlines() if l.strip()]
    if not lines:
        return []
    hdr = [h.strip() for h in lines[0].split(",")]
    out: List[Dict] = []
    for l in lines[1:]:
        p = l.split(",")
        if len(p) != len(hdr):
            continue
        rec = dict(zip(hdr, p))
        try:
            for k in ("l_per", "l_abs", "b_per", "b_abs"):
                rec[k] = float(rec[k])
        except (KeyError, ValueError):
            continue
        out.append(rec)
    return out


def to_axis(rows: List[Dict], n_seed: int) -> List[Tuple[int, Dict]]:
    out = []
    for i, r in enumerate(rows, start=1):
        replayed = i if i <= n_seed else n_seed + (i - n_seed) * SKIPCOUNT
        out.append((replayed, r))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--proto", default="smtp")
    ap.add_argument("--seed-counts", default="protorag=78,baseline=2")
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()

    sc = {}
    for kv in args.seed_counts.split(","):
        k, v = kv.split("=")
        sc[k.strip()] = int(v)

    root = Path(args.out_root)
    res: Dict = {"proto": args.proto, "groups": {}}
    md: List[str] = []
    md.append(f"# {args.proto.upper()}：起跑覆盖 vs 模糊期新增 分解")
    md.append("")
    md.append("> `cov_script` 段1 = 初始种子语料（**每个种子写一行**）；段2 = fuzzing 产生的测试用例（**每 5 个写一行**）。")
    md.append("> 行号已换算成「累计回放数」，并在各组自身的种子数处切分两阶段。")
    md.append("")

    for grp in ("protorag", "baseline"):
        rows = load_csv(root / args.proto / grp / "r1" / "cov_over_time.csv")
        axis = to_axis(rows, sc[grp])
        if not axis:
            continue
        n_seed = sc[grp]
        seed_rows = [(r, rec) for r, rec in axis if r <= n_seed]
        fuzz_rows = [(r, rec) for r, rec in axis if r > n_seed]
        if not seed_rows:
            continue
        seed_end = seed_rows[-1][1]
        fuzz_end = fuzz_rows[-1][1] if fuzz_rows else seed_end
        # 模糊期 l_abs 轨迹（用于看天花板）
        traj = [(r, rec["l_abs"], rec["l_per"]) for r, rec in fuzz_rows]
        l_abs_vals = [t[1] for t in traj]
        l_abs_min = min(l_abs_vals) if l_abs_vals else 0
        l_abs_max = max(l_abs_vals) if l_abs_vals else 0
        gain = fuzz_end["l_abs"] - seed_end["l_abs"]
        gain_pct = (fuzz_end["l_per"] - seed_end["l_per"])
        res["groups"][grp] = {
            "n_seed": n_seed,
            "seed_stage_end": {"l_abs": seed_end["l_abs"], "l_per": seed_end["l_per"],
                               "b_per": seed_end["b_per"], "replayed": seed_rows[-1][0]},
            "fuzz_stage_end": {"l_abs": fuzz_end["l_abs"], "l_per": fuzz_end["l_per"],
                               "b_per": fuzz_end["b_per"], "replayed": fuzz_rows[-1][0] if fuzz_rows else None},
            "fuzz_gain_l_abs": gain,
            "fuzz_gain_l_per": gain_pct,
            "fuzz_stage_l_abs_min": l_abs_min,
            "fuzz_stage_l_abs_max": l_abs_max,
            "fuzz_stage_l_abs_frozen": (l_abs_max - l_abs_min) < 1e-9,
            "fuzz_stage_l_abs_range": [l_abs_min, l_abs_max],
            "n_fuzz_rows": len(fuzz_rows),
        }
        print(f"--- {grp} ---")
        print(f"  种子阶段末(回放{n_seed}个):  l_abs={seed_end['l_abs']:.0f}  l_per={seed_end['l_per']:.2f}  b_per={seed_end['b_per']:.2f}")
        print(f"  模糊阶段末(回放{fuzz_rows[-1][0] if fuzz_rows else 0}个): l_abs={fuzz_end['l_abs']:.0f}  l_per={fuzz_end['l_per']:.2f}  b_per={fuzz_end['b_per']:.2f}")
        print(f"  模糊期新增: Δl_abs={gain:+.0f}  Δl_per={gain_pct:+.2f}")
        print(f"  模糊期 l_abs 取值范围: [{l_abs_min:.0f}, {l_abs_max:.0f}]  "
              f"{'← 全程冻结（天花板）' if (l_abs_max-l_abs_min) < 1e-9 else ''}")
        print()

    if len(res.get("groups", {})) == 2:
        p = res["groups"]["protorag"]
        b = res["groups"]["baseline"]
        md.append("| 阶段 | protorag l_abs | baseline l_abs | 差 |")
        md.append("|---|---|---|---|")
        md.append(f"| **种子阶段末**（起跑覆盖） | {p['seed_stage_end']['l_abs']:.0f} | "
                  f"{b['seed_stage_end']['l_abs']:.0f} | "
                  f"{p['seed_stage_end']['l_abs'] - b['seed_stage_end']['l_abs']:+.0f} |")
        md.append(f"| **模糊阶段末** | {p['fuzz_stage_end']['l_abs']:.0f} | "
                  f"{b['fuzz_stage_end']['l_abs']:.0f} | "
                  f"{p['fuzz_stage_end']['l_abs'] - b['fuzz_stage_end']['l_abs']:+.0f} |")
        md.append(f"| **模糊期新增**（变异效率） | {p['fuzz_gain_l_abs']:+.0f} | "
                  f"{b['fuzz_gain_l_abs']:+.0f} | "
                  f"{p['fuzz_gain_l_abs'] - b['fuzz_gain_l_abs']:+.0f} |")
        md.append("")
        d_start = p["seed_stage_end"]["l_abs"] - b["seed_stage_end"]["l_abs"]
        d_end = p["fuzz_stage_end"]["l_abs"] - b["fuzz_stage_end"]["l_abs"]
        md.append("## 结论")
        md.append("")
        md.append(f"- **起跑差距 Δl_abs = {d_start:+.0f}**（种子阶段末，尚未做任何 fuzzing 变异）")
        md.append(f"- **最终差距 Δl_abs = {d_end:+.0f}**")
        md.append(f"- **模糊期差距变化 = {d_end - d_start:+.0f}**")
        md.append("")
        if p["fuzz_stage_l_abs_frozen"] and p["fuzz_gain_l_abs"] == 0:
            md.append("### ★ 判定：**差距在种子阶段就已存在（起跑就落后），且 protorag 的模糊期新增为 0**")
            md.append("")
            md.append(f"- protorag 的 l_abs 在**整个模糊阶段**恒为 **{p['fuzz_stage_l_abs_max']:.0f}**"
                      f"（{p['n_fuzz_rows']} 个采样点，波动 = 0）→ **覆盖天花板**")
            md.append(f"- baseline 同阶段从 {b['seed_stage_end']['l_abs']:.0f} 增长到 "
                      f"{b['fuzz_stage_end']['l_abs']:.0f}（+{b['fuzz_gain_l_abs']:.0f}）")
            md.append("")
            md.append("→ **不是「后程拉开」，而是「起跑就落后 + 撞上天花板」**。"
                      "根因在**种子本身的覆盖面**，不在变异效率。")
            res["verdict"] = "起跑落后 + 覆盖天花板（种子覆盖面问题）"
        elif abs(d_end - d_start) < max(1.0, abs(d_start) * 0.15):
            md.append("### 判定：**差距在种子阶段就已存在，模糊阶段基本没有变化** → 根因是**种子覆盖面**，不是变异效率")
            res["verdict"] = "起跑落后，差距恒定（种子覆盖面问题）"
        else:
            md.append("### 判定：差距在模糊阶段**被进一步拉开** → 根因含**变异效率**因素")
            res["verdict"] = "后程拉开（含变异效率因素）"
        print("★ 判定:", res.get("verdict", ""))

    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
