#!/bin/bash
# qa_param_verify.sh —— QA 独立参数复核：对 6 个容器逐行跑官方 rq4_param_check.py
#
# ★ 关键：command_line **直接从容器真实产物**取（tar 内的 fuzzer_stats / 运行中容器 exec），
#   **不**依赖 rq4_summary.csv 的 param_check 列（那列本身也是本脚本判定的产物，
#   用它验证自己是循环论证）。
set -uo pipefail
source /home/zxy/rq4/scripts/rq4_protocols.sh
PC=/home/zxy/rq4/scripts/rq4_param_check.py
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

extract_cmdline() {
  local p="$1" g="$2" c="rq4_${p}_${g}_r1" d
  case $p in
    rtsp) d=/home/ubuntu/experiments/live/testProgs/out-${p}-${g}-r1 ;;
    sip)  d=/home/ubuntu/experiments/kamailio/out-${p}-${g}-r1 ;;
    smtp) d=/home/ubuntu/experiments/exim/out-${p}-${g}-r1 ;;
  esac
  # 优先：运行中容器直接 exec
  if docker ps --format '{{.Names}}' | grep -qx "$c"; then
    docker exec "$c" bash -c "sed -n 's/^command_line *: *//p' '$d/fuzzer_stats' | head -1" 2>/dev/null
    return
  fi
  # 已退出：从 tar 里取
  local img tar_path
  img=$(proto_field "$p" image)
  tar_path="/home/ubuntu/experiments/out-${p}-${g}-r1.tar.gz"
  if docker cp "$c:$tar_path" "$TMP/o.tar.gz" >/dev/null 2>&1; then
    docker run --rm -v "$TMP:/out" --entrypoint /bin/bash "$img" \
      -c "cd /out && rm -rf '${p}-${g}-r1' && tar xzf o.tar.gz --exclude=o.tar.gz 2>/dev/null; sed -n 's/^command_line *: *//p' '$(basename $d)/fuzzer_stats' | head -1" 2>/dev/null
  fi
}

echo "================================================================"
echo " QA 独立参数复核（rq4_param_check.py 逐 token 全等）"
echo "================================================================"
FAIL=0
for p in rtsp sip smtp; do
  o=$(proto_field "$p" options)
  n=$(proto_field "$p" net)
  for g in protorag baseline; do
    c="rq4_${p}_${g}_r1"
    cmd=$(extract_cmdline "$p" "$g")
    echo ""
    echo "##### $c"
    echo "  EXPECTED OPTIONS : $o"
    echo "  EXPECTED NET     : $n"
    echo "  ACTUAL command_line:"
    echo "    $cmd"
    if [[ -z "$cmd" ]]; then
      echo "  VERDICT: NO_COMMAND_LINE (取不到 command_line)"
      FAIL=1
      continue
    fi
    v=$(python3 "$PC" --options "$o" --net "$n" --command-line "$cmd" 2>/tmp/qa_pc_err)
    rc=$?
    echo "  VERDICT: $v (rc=$rc)"
    if [[ -s /tmp/qa_pc_err ]]; then
      sed 's/^/  REASON: /' /tmp/qa_pc_err
    fi
    # 额外：token 序号化打印（人工逐字核对用）
    echo "  TOKENIZED ACTUAL:"
    i=0
    for tok in $cmd; do
      i=$((i+1))
      printf "    [%02d] %s\n" "$i" "$tok"
    done
    [[ "$v" == "OK" ]] || FAIL=1
  done
done
echo ""
echo "================================================================"
if [[ "$FAIL" -eq 0 ]]; then
  echo " 结果: 全部 6 行 VERDICT=OK"
else
  echo " 结果: 存在非 OK 行（见上）"
fi
exit "$FAIL"
