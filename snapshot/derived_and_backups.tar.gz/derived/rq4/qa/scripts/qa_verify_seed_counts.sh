#!/bin/bash
# qa_verify_seed_counts.sh —— 独立复核两组种子数量（不依赖 rq4_summary.csv 的 seed_files 列）
# 用法：流式 tar 管道 → 只在内存/流上统计，不落盘（避免撑爆 VM 磁盘）。
set -uo pipefail

count_seeds() {
  local img="$1" in_dir="$2"
  docker run --rm --entrypoint /bin/bash "$img" -c \
    "tar cf - -C '$(dirname "$in_dir")' '$(basename "$in_dir")' 2>/dev/null" \
  | tar tvf - 2>/dev/null \
  | awk -F'\t' '{print $NF}' \
  | grep -v '/$' \
  | grep -v 'README.txt' \
  | wc -l
}

count_regions_note() {
  echo "(region 计数需 rq4_seed_profile.py，此处仅复核文件数)"
}

echo "================================================================"
echo " QA 独立复核：两组种子文件数（流式统计，不落盘）"
echo "================================================================"
printf "%-38s %-10s %-10s\n" "容器" "seed_files" "来源"
for spec in "rq2-live555:latest rtsp /home/ubuntu/experiments/in-rtsp" \
            "rq2-kamailio:latest sip /home/ubuntu/experiments/in-sip" \
            "rq2-exim:latest smtp /home/ubuntu/experiments/in-smtp"; do
  set -- $spec
  img="$1"; p="$2"; d="$3"
  n=$(count_seeds "$img" "$d")
  printf "%-38s %-10s %-10s\n" "baseline/$p (镜像自带)" "$n" "镜像 in-$p"
done

echo ""
for p in rtsp sip smtp; do
  n=$(find /home/zxy/rq4/seeds/$p -maxdepth 1 -type f -name '*.raw' 2>/dev/null | wc -l)
  allf=$(find /home/zxy/rq4/seeds/$p -maxdepth 1 -type f 2>/dev/null | wc -l)
  printf "%-38s %-10s %-10s\n" "protorag/$p (宿主)" "$n" "共${allf}个文件"
done

echo ""
echo "================================================================"
echo " 字典 token 数（两组共用同一份宿主缓存副本 → 必须相同）"
echo "================================================================"
for p in rtsp sip smtp; do
  f=/home/zxy/rq4/dicts/$p.dict
  if [[ -s "$f" ]]; then
    echo "  $p: $(grep -cvE '^\s*(#|$)' "$f") 条有效 token（共 $(wc -l < "$f") 行）"
  else
    echo "  $p: 无字典（官方即无）"
  fi
done
