#!/bin/bash
echo "=== SIP cov_over_time.csv 的 gcovr 失败率检查 ==="
for spec in "rq4_sip_protorag_r1 protorag" "rq4_sip_baseline_r1 baseline"; do
  set -- $spec; c=$1; g=$2
  echo "--- $c"
  docker logs "$c" 2>&1 | grep -c "No space left on device" | sed 's/^/    NoSpace 错误次数: /'
  docker logs "$c" 2>&1 | grep -c "Could not open output file" | sed 's/^/    CouldNotOpen 次数: /'
  docker logs "$c" 2>&1 | grep -c "gcovr could not infer a working directory" | sed 's/^/    gcovr工作目录推断失败次数: /'
  # CSV 是否有空行/缺列（gcovr 失败的行）
  docker exec "$c" sh -c "cat /home/ubuntu/experiments/kamailio/out-sip-$g-r1/cov_over_time.csv" 2>/dev/null | awk -F, 'NF!=5 || $2=="" || $4=="" {bad++} END{print "    CSV 总行="NR" 异常行(缺列或空值)="bad+0}'
done
echo ""
echo "=== 这些错误发生在什么阶段（时间顺序）==="
docker logs rq4_sip_protorag_r1 2>&1 | grep -n "No space left" | head -3
echo "..."
docker logs rq4_sip_protorag_r1 2>&1 | grep -n "No space left" | tail -3
echo ""
echo "总日志行数: $(docker logs rq4_sip_protorag_r1 2>&1 | wc -l)"
