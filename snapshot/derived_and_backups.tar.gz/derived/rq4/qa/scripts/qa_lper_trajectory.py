# -*- coding: utf-8 -*-
"""qa_lper_trajectory.py —— 回答「SMTP 的 l_per 差距是恒定差异还是后程拉开？」

★ 关键前提（必须先搞清楚，否则会得出错误结论）
------------------------------------------------
官方 ``cov_script`` 的写法是**两段**：

    # 段1：初始种子语料 —— **每个种子都写一行**（不 skip）
    for f in $(echo $folder/$testdir/*.raw); do ... echo "$time,$l_per,..." >> $covfile; done

    # 段2：fuzzer 生成的测试用例 —— **每 SKIPCOUNT(=5) 个才写一行**
    count=0
    for f in $(echo $folder/$testdir/id*); do
        count=$(expr $count + 1); rem=$(expr $count % $step)
        if [ "$rem" != "0" ]; then continue; fi
        ... echo "$time,$l_per,..." >> $covfile
    done

→ 所以 **CSV 的行号在两组之间不可直接比较**：
   protorag 的前 N_seed 行是「逐个种子」的贡献（每个种子一行），
   baseline 的前 N_seed 行同理，但 N_seed 差 39 倍（78 vs 2）。
   行号越靠后，对应的「已回放测试用例数」越多，但两组的换算关系**不同**。

→ 正确的比较方式：把行号换算成**「已回放的测试用例累计数」**：
     · 段1（行 1..N_seed）：累计回放数 = 行号
     · 段2（行 N_seed+1..）：累计回放数 = N_seed + (行号 - N_seed) * SKIPCOUNT

   然后在**相同的累计回放数**上比较 l_abs / l_per。

★ 三种可能的形态（本脚本会明确区分）：
   (a) **恒定差异**：两组曲线平行，间距从头到尾不变 → 「触达面不同」的稳态差异
   (b) **后程拉开**：早期接近，随回放数增加间距单调扩大 → protorag 被越拉越远
   (c) **早期落后**：一开始就明显落后，之后大致平行 → protorag 起跑就弱

本脚本**不 import rq4_analyze.py**，独立实现。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SKIPCOUNT = 5


def load_cov_csv(path: Path) -> List[Dict]:
    """读 cov_over_time.csv → [{'time','l_per','l_abs','b_per','b_abs'}, ...]。

    ★ 跳过**空值行**（gcovr 失败时 cov_script 会写出 ",,,"）—— 那是数据缺失，不是 0。
    """
    if not path.exists():
        return []
    lines = [l.strip() for l in path.read_text(errors="replace").splitlines() if l.strip()]
    if not lines:
        return []
    hdr = [h.strip() for h in lines[0].split(",")]
    out: List[Dict] = []
    for l in lines[1:]:
        parts = l.split(",")
        if len(parts) != len(hdr):
            continue
        rec = dict(zip(hdr, parts))
        try:
            rec["l_per"] = float(rec["l_per"])
            rec["l_abs"] = float(rec["l_abs"])
            rec["b_per"] = float(rec["b_per"])
            rec["b_abs"] = float(rec["b_abs"])
        except (KeyError, ValueError):
            continue          # 空值行 → 跳过
        rec["time"] = rec.get("Time", rec.get("time", ""))
        out.append(rec)
    return out


def to_replay_axis(rows: List[Dict], n_seed: int) -> List[Tuple[int, Dict]]:
    """把行号换算成「累计回放的测试用例数」。"""
    out: List[Tuple[int, Dict]] = []
    for i, r in enumerate(rows, start=1):
        if i <= n_seed:
            replayed = i
        else:
            replayed = n_seed + (i - n_seed) * SKIPCOUNT
        out.append((replayed, r))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", required=True, help="含 <proto>/<group>/r1/cov_over_time.csv")
    ap.add_argument("--proto", default="smtp")
    ap.add_argument("--seed-counts", default="protorag=78,baseline=2",
                    help="protorag=78,baseline=2")
    ap.add_argument("--json-out", default="")
    ap.add_argument("--md-out", default="")
    args = ap.parse_args()

    seed_counts = {}
    for kv in args.seed_counts.split(","):
        k, v = kv.split("=")
        seed_counts[k.strip()] = int(v)

    root = Path(args.out_root)
    series: Dict[str, List[Tuple[int, Dict]]] = {}
    for grp in ("protorag", "baseline"):
        p = root / args.proto / grp / "r1" / "cov_over_time.csv"
        rows = load_cov_csv(p)
        series[grp] = to_replay_axis(rows, seed_counts[grp])
        print(f"{grp}: CSV 有效数据行={len(rows)}  种子数={seed_counts[grp]}  "
              f"→ 段1(逐种子)行数={min(len(rows), seed_counts[grp])}  "
              f"段2(每5个)行数={max(0, len(rows) - seed_counts[grp])}")

    def at(grp: str, replayed: int) -> Optional[Dict]:
        """取「累计回放数 ≤ replayed 的最后一条」。"""
        s = series.get(grp) or []
        best = None
        for r, rec in s:
            if r <= replayed:
                best = rec
            else:
                break
        return best

    # 关键锚点：两组种子语料全部回放完的时刻（各自的 n_seed）
    print()
    print("=" * 96)
    print(f"### {args.proto}：在「相同累计回放数」上比较 l_abs / l_per")
    print("=" * 96)
    max_replay = min((s[-1][0] if s else 0) for s in series.values() if s)
    anchors = []
    for frac in (0.0, 0.02, 0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.85, 1.0):
        anchors.append(int(max_replay * frac))
    # 额外锚点：两组各自种子数（若在范围内）
    for sc in seed_counts.values():
        if 0 < sc <= max_replay:
            anchors.append(sc)
    anchors = sorted(set(anchors))

    md: List[str] = []
    md.append(f"# {args.proto.upper()}：l_per 差距形态分析（恒定差异 / 后程拉开 / 早期落后）")
    md.append("")
    md.append("> **口径**：CSV 行号在两组之间**不可直接比较**（段1 每个种子一行、段2 每 5 个一行，"
              "且两组种子数不同）。本表已把行号换算成**「累计回放的测试用例数」**，"
              "在相同回放数上比较。")
    md.append("")
    md.append("| 累计回放数 | protorag l_abs | baseline l_abs | Δl_abs | protorag l_per | baseline l_per | Δl_per | 形态 |")
    md.append("|---|---|---|---|---|---|---|---|")

    res: Dict = {"anchors": []}
    prev_gap = None
    gaps: List[Tuple[int, float]] = []
    for a in anchors:
        pa = at("protorag", a)
        ba = at("baseline", a)
        if not pa or not ba:
            continue
        d_abs = pa["l_abs"] - ba["l_abs"]
        d_per = pa["l_per"] - ba["l_per"]
        gaps.append((a, d_abs))
        # 形态判据
        if prev_gap is None:
            shape = "—"
        else:
            if abs(d_abs - prev_gap) < max(1.0, abs(prev_gap) * 0.05):
                shape = "平行（差距恒定）"
            elif d_abs < prev_gap:
                shape = "**差距扩大**"
            else:
                shape = "差距缩小"
        prev_gap = d_abs
        md.append(f"| {a} | {pa['l_abs']:.0f} | {ba['l_abs']:.0f} | {d_abs:+.0f} | "
                  f"{pa['l_per']:.2f} | {ba['l_per']:.2f} | {d_per:+.2f} | {shape} |")
        res["anchors"].append({"replayed": a, "l_abs_pro": pa["l_abs"],
                                "l_abs_bas": ba["l_abs"], "d_l_abs": d_abs,
                                "l_per_pro": pa["l_per"], "l_per_bas": ba["l_per"],
                                "d_l_per": d_per, "shape": shape})

    # 种子语料阶段的贡献（段1 末行）
    print()
    print("--- 段1：初始种子语料逐个回放完毕时的累计覆盖（=「种子起跑质量」）---")
    seed_phase: Dict = {}
    for grp in ("protorag", "baseline"):
        s = series.get(grp) or []
        seed_rows = [(r, rec) for r, rec in s if r <= seed_counts[grp]]
        if not seed_rows:
            continue
        last = seed_rows[-1][1]
        seed_phase[grp] = {"n_seed": seed_counts[grp], "l_abs": last["l_abs"],
                           "l_per": last["l_per"], "b_per": last["b_per"]}
        print(f"  {grp}: {seed_counts[grp]} 个种子全部回放后 → "
              f"l_abs={last['l_abs']:.0f}  l_per={last['l_per']:.2f}  b_per={last['b_per']:.2f}")
    if len(seed_phase) == 2:
        d = seed_phase["protorag"]["l_abs"] - seed_phase["baseline"]["l_abs"]
        ratio = (seed_phase["protorag"]["l_abs"] / seed_phase["baseline"]["l_abs"]
                 if seed_phase["baseline"]["l_abs"] else None)
        print(f"  → Δl_abs(种子阶段) = {d:+.0f}"
              + (f"  （protorag 是 baseline 的 {ratio:.2f}×）" if ratio else ""))
        res["seed_phase"] = seed_phase

    md.append("")
    md.append("--- 段1：初始种子语料逐个回放完毕时的累计覆盖（「种子起跑质量」）---")
    md.append("")
    md.append("| 组 | 种子数 | l_abs | l_per | b_per |")
    md.append("|---|---|---|---|---|")
    for grp in ("protorag", "baseline"):
        if grp in seed_phase:
            v = seed_phase[grp]
            md.append(f"| {grp} | {v['n_seed']} | {v['l_abs']:.0f} | {v['l_per']:.2f} | {v['b_per']:.2f} |")
    if len(seed_phase) == 2:
        d = seed_phase["protorag"]["l_abs"] - seed_phase["baseline"]["l_abs"]
        md.append("")
        md.append(f"→ **Δl_abs(种子阶段) = {d:+.0f}** —— "
                  + ("ProtoRAG 种子**触达的可执行代码更多**（覆盖面更广），"
                     "这与「l_per 落后」的最终结果方向**相反**。"
                     if d > 0 else
                     "ProtoRAG 种子触达的可执行代码**更少**。"))
    res["seed_phase_note"] = "见 md"

    # 形态总判
    print()
    print("--- 形态总判 ---")
    if gaps:
        first_gap = gaps[0][1]
        last_gap = gaps[-1][1]
        print(f"  首个锚点 Δl_abs = {first_gap:+.0f}")
        print(f"  末个锚点 Δl_abs = {last_gap:+.0f}")
        if len(seed_phase) == 2 and first_gap > 0 and last_gap < 0:
            print("  ★ 形态：**从『种子阶段 protorag 领先』变为『末段 protorag 落后』**")
            print("     → 这是**后程拉开**（protorag 在后续 fuzzing 阶段被越拉越远），")
            print("       **不是**「触达面不同」的恒定稳态差异。")
            verdict = "后程拉开"
        elif last_gap < first_gap:
            print("  ★ 形态：**差距随回放数扩大** → 后程拉开")
            verdict = "后程拉开"
        else:
            print("  ★ 形态：**差距大致恒定/收敛** → 稳态差异（触达面不同）")
            verdict = "恒定/收敛差异"
        res["verdict"] = verdict
        md.append("")
        md.append(f"**形态总判：{verdict}**")
        md.append("")
        md.append(f"- 首个锚点 Δl_abs = {first_gap:+.0f}；末个锚点 Δl_abs = {last_gap:+.0f}")

    text = "\n".join(md)
    if args.md_out:
        Path(args.md_out).write_text(text, encoding="utf-8")
        print(f"\n[qa] Markdown 写出: {args.md_out}")
    else:
        print(text)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print(f"[qa] JSON 写出: {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
