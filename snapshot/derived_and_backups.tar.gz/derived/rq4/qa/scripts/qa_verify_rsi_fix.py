# -*- coding: utf-8 -*-
"""qa_verify_rsi_fix.py —— 独立验证工程师对 RSI off-by-one 的修复（3 个维度）。

维度 1：**行为正确性** —— 脚本真实取数表达式在标准/非整数倍轴上都取到「标签时刻」
维度 2：**护栏有效性** —— 把调用点改回 buggy 公式，护栏必须**红**
        （这是最关键的：工程师自述第一版护栏只测函数、变异只红 1 条 → 假安全感）
维度 3：**回归不破** —— 修复没破坏脚本其他行为

★ 本脚本**不修改**生产脚本（除变异阶段用临时副本，且立即还原）。
"""
from __future__ import annotations

import ast
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1] / "rag-chatafl"
if not REPO.exists():
    REPO = Path("E:/科研/想法idea/rag-chatafl")
SCRIPT = REPO / "scripts" / "analyze_compare_12h.py"
TEST = REPO / "tests" / "fused" / "test_analyze_compare_index.py"

print("=" * 88)
print("RSI off-by-one 修复的独立验证")
print("=" * 88)

# ---------- 维度 1：行为正确性 ----------
print("\n[维度 1] 脚本真实取数表达式 → 是否取到「标签时刻」")


def extract_index_expr(src: str) -> ast.expr:
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, ast.For) and isinstance(node.target, ast.Name) \
                and node.target.id == "h_target":
            for stmt in ast.walk(node):
                if isinstance(stmt, ast.Assign):
                    for tgt in stmt.targets:
                        if isinstance(tgt, ast.Name) and tgt.id == "idx":
                            return stmt.value
    raise AssertionError("找不到给 idx 赋值的语句")


def load_pick_index(src: str):
    """从源码里摘出 pick_index 并执行它（测生产代码本身）。"""
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == "pick_index":
            mod = ast.Module(body=[node], type_ignores=[])
            ast.fix_missing_locations(mod)
            ns: dict = {"np": np}
            exec(compile(mod, str(SCRIPT), "exec"), ns)
            return ns["pick_index"]
    raise AssertionError("找不到 pick_index")


src = SCRIPT.read_text(encoding="utf-8")
expr = extract_index_expr(src)
pick_index = load_pick_index(src)
print(f"  真实表达式: {ast.unparse(expr)}")


def eval_expr(expr: ast.expr, hours, h_target: float) -> int:
    mod = ast.Expression(body=expr)
    ast.fix_missing_locations(mod)
    ns = {"h_target": h_target, "np": np, "hc": hours, "pick_index": pick_index}
    return int(eval(compile(mod, str(SCRIPT), "eval"), ns))


HOURS = 24.0
hours = np.arange(0, HOURS + 1e-6, 0.25)
print("\n  | 标签 | 真实表达式 idx | 取到的时刻 | 是否等于标签 |")
print("  |---|---|---|---|")
all_ok = True
for h in (2.0, 4.0, 8.0, 12.0, HOURS):
    idx = eval_expr(expr, hours, h)
    got = hours[idx]
    ok = abs(got - h) < 1e-9
    all_ok = all_ok and ok
    print(f"  | {h:>5.1f}h | {idx:>14} | {got:>10.2f}h | {'✓' if ok else '✗'} |")

# 非整数倍轴（工程师指出的坑）
print("\n  非整数倍轴（HOURS=10.3，末元素仅 10.25）：")
hours2 = np.arange(0, 10.3 + 1e-6, 0.25)
for h in (2.0, 4.0, 8.0, 10.3):
    idx = eval_expr(expr, hours2, h)
    got = hours2[idx]
    ok = abs(got - h) < 0.251 and 0 <= idx < len(hours2)
    all_ok = all_ok and ok
    print(f"    | {h:>5.1f}h | idx={idx:>3} → {got:>6.2f}h | 越界={idx >= len(hours2)} | {'✓' if ok else '✗'} |")

# 旧 buggy 公式对照
print("\n  旧 buggy 公式 `int(h_target/step) - 1` 对照（证明缺陷确实存在且已被修掉）：")
for h in (2.0, 4.0, 8.0, 12.0, HOURS):
    old = int(h / 0.25) - 1
    print(f"    标签 {h:>5.1f}h → 旧公式 idx={old:>3} 取到 {hours[old]:>6.2f}h  "
          f"{'（正确）' if abs(hours[old]-h) < 1e-9 else '✗ 偏一格'}")

# ---------- 维度 2：护栏有效性（变异测试） ----------
print("\n" + "=" * 88)
print("[维度 2] 护栏有效性：把调用点改回 buggy 公式，护栏必须红")
print("=" * 88)

tmpdir = Path(tempfile.mkdtemp())
backup = tmpdir / "orig.py"
shutil.copy2(SCRIPT, backup)
try:
    buggy_src = src.replace(
        "idx = pick_index(hc, h_target)",
        "idx = int(h_target / 0.25) - 1",
    )
    assert buggy_src != src, "★ 变异失败：没能替换调用点（源码可能已变，请检查）"
    SCRIPT.write_text(buggy_src, encoding="utf-8")
    print("  已注入变异：idx = int(h_target / 0.25) - 1")

    r = subprocess.run(
        [sys.executable, "-m", "pytest", str(TEST), "-q", "-p", "no:cacheprovider"],
        cwd=str(REPO), capture_output=True, text=True, errors="replace", timeout=300,
    )
    tail = [l for l in r.stdout.splitlines() if "passed" in l or "failed" in l]
    print(f"  变异后护栏结果: {tail[-1] if tail else r.stdout[-300:]}")
    n_failed = r.stdout.count("FAILED")
    print(f"  失败用例数: {n_failed}")
    if n_failed >= 5:
        print(f"  ✓ 护栏**能抓住调用点回退**（{n_failed} 条红）")
        guard_ok = True
    else:
        print(f"  ✗ 护栏**抓不住**（只红 {n_failed} 条）—— 存在假安全感")
        guard_ok = False
finally:
    shutil.copy2(backup, SCRIPT)
    shutil.rmtree(tmpdir, ignore_errors=True)
    print("  已还原生产脚本")

# 还原后必须全绿
r2 = subprocess.run(
    [sys.executable, "-m", "pytest", str(TEST), "-q", "-p", "no:cacheprovider"],
    cwd=str(REPO), capture_output=True, text=True, errors="replace", timeout=300,
)
tail2 = [l for l in r2.stdout.splitlines() if "passed" in l or "failed" in l]
print(f"  还原后护栏结果: {tail2[-1] if tail2 else r2.stdout[-200:]}")
restored_ok = r2.returncode == 0

print("\n" + "=" * 88)
print("维度 1 行为正确性 :", "✓ 通过" if all_ok else "✗ 失败")
print("维度 2 护栏有效性 :", "✓ 通过" if guard_ok else "✗ 失败")
print("还原后护栏全绿    :", "✓ 通过" if restored_ok else "✗ 失败")
print("=" * 88)
sys.exit(0 if (all_ok and guard_ok and restored_ok) else 1)
