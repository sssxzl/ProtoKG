#!/bin/bash
# 用「按列号取值」的正确实现，从 6 个容器的 cov_over_time.csv 末行取 l_per / b_per
printf "%-28s %-10s %-10s %-10s %-10s\n" "容器" "行数" "l_per" "b_per" "末行时间"
for spec in "rtsp protorag /home/ubuntu/experiments/live/testProgs/out-rtsp-protorag-r1" \
            "rtsp baseline /home/ubuntu/experiments/live/testProgs/out-rtsp-baseline-r1" \
            "sip  protorag /home/ubuntu/experiments/kamailio/out-sip-protorag-r1" \
            "sip  baseline /home/ubuntu/experiments/kamailio/out-sip-baseline-r1" \
            "smtp protorag /home/ubuntu/experiments/exim/out-smtp-protorag-r1" \
            "smtp baseline /home/ubuntu/experiments/exim/out-smtp-baseline-r1"; do
  set -- $spec; p=$1; g=$2; d=$3
  f=/home/zxy/rq4/out/$p/$g/r1/cov_over_time.csv
  if [ ! -s "$f" ]; then printf "%-28s %-10s\n" "$p/$g" "MISSING"; continue; fi
  hdr=$(head -1 "$f" | tr -d '\r')
  c1=$(echo "$hdr" | awk -F',' -v k=l_per '{for(i=1;i<=NF;i++) if($i==k){print i; exit}}')
  c2=$(echo "$hdr" | awk -F',' -v k=b_per '{for(i=1;i<=NF;i++) if($i==k){print i; exit}}')
  c0=$(echo "$hdr" | awk -F',' -v k=Time '{for(i=1;i<=NF;i++) if($i==k){print i; exit}}')
  last=$(tail -1 "$f" | tr -d '\r')
  v1=$(echo "$last" | awk -F',' -v c="$c1" '{print $c}')
  v2=$(echo "$last" | awk -F',' -v c="$c2" '{print $c}')
  v0=$(echo "$last" | awk -F',' -v c="$c0" '{print $c}')
  printf "%-28s %-10s %-10s %-10s %-10s\n" "$p/$g" "$(wc -l < "$f")" "$v1" "$v2" "$v0"
done
echo ""
echo "注：sip 两行的 cov_over_time.csv 仍在被 cov_script 追加（后处理未完）→ 其 l_per/b_per 是部分值"
