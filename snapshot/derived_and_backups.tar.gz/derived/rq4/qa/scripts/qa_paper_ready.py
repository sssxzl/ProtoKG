# -*- coding: utf-8 -*-
"""qa_paper_ready.py —— 生成**可直接写入论文**的 RQ4 结果与局限章节。

输入（均为 QA 自写脚本的独立产物）：
  · rq4_summary.csv            终态汇总（28 列）
  · qa_independent_verify.json  QA 独立复核（参数/窗口/两口径）
  · qa_crossover.json           交叉点分析
  · qa_conv_<proto>.json        Δcvg 轨迹的密集网格检验
  · qa_decomp_<proto>.json      起跑覆盖 vs 模糊期新增分解
  · qa_seed_depth.json          两组种子的会话深度画像

用法:
    python3 qa_paper_ready.py --summary CSV --verify-json VJ --out MD
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List, Optional

PROTOS = ["rtsp", "sip", "smtp"]
SEEDS = {"rtsp": (39, 7), "sip": (25, 1), "smtp": (78, 2)}


def _f(s: str) -> Optional[float]:
    try:
        return float(str(s).strip().replace("%", "").replace(",", ""))
    except (TypeError, ValueError):
        return None


def fmt(v, nd=2):
    return "—" if v is None else f"{v:.{nd}f}"


def sg(v, nd=2):
    return "—" if v is None else f"{v:+.{nd}f}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", required=True)
    ap.add_argument("--verify-json", required=True)
    ap.add_argument("--cross-json", default="")
    ap.add_argument("--conv-json", default="", help="逗号分隔的 proto=path")
    ap.add_argument("--decomp-json", default="", help="逗号分隔的 proto=path")
    ap.add_argument("--depth-json", default="")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rows = {f"{r['protocol']}/{r['group']}": r
            for r in csv.DictReader(open(args.summary, encoding="utf-8-sig"))}
    vj = json.loads(Path(args.verify_json).read_text(encoding="utf-8"))
    cross = json.loads(Path(args.cross_json).read_text(encoding="utf-8")) if args.cross_json else {}
    conv: Dict = {}
    for kv in filter(None, args.conv_json.split(",")):
        k, v = kv.split("=", 1)
        if Path(v).exists():
            conv[k] = json.loads(Path(v).read_text(encoding="utf-8"))
    decomp: Dict = {}
    for kv in filter(None, args.decomp_json.split(",")):
        k, v = kv.split("=", 1)
        if Path(v).exists():
            decomp[k] = json.loads(Path(v).read_text(encoding="utf-8"))
    depth = json.loads(Path(args.depth_json).read_text(encoding="utf-8")) if args.depth_json else {}

    M: List[str] = []
    A = M.append

    A("# RQ4 实验结果（可直接写入论文）")
    A("")
    A("> **实验设置**：3 协议（RTSP / SIP / SMTP）× 2 种子组（ProtoRAG 生成组 vs 官方镜像自带组）"
      "× 1 次重复 × 3 小时预算，AFLNet 驱动，目标程序为 live555 / kamailio / exim。")
    A("> **指标**：`bitmap_cvg` = AFLNet 自报边覆盖（%，跨协议可比）；"
      "`l_per` / `b_per` = cov_script 官方口径的行 / 分支覆盖（%）。")
    A("> **重复**：每组每协议 **n = 1**（无重复实验）。")
    A("")

    # ---------- 表 1 ----------
    A("## 表 1　RQ4 终态实验结果")
    A("")
    A("| 协议 | 组 | 种子文件数 | seed_regions | 字典 token | execs_done | execs/s | paths_total | paths_found | max_depth | bitmap_cvg (%) | l_per (%) | b_per (%) | 崩溃 | 挂起 |")
    A("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for p in PROTOS:
        for g in ("protorag", "baseline"):
            r = rows.get(f"{p}/{g}")
            if not r:
                continue
            A(f"| {p} | {g} | {r['seed_files']} | {r['seed_regions']} | {r['dict_tokens']} | "
              f"{int(float(r['execs_done']))} | {r['execs_per_sec']} | {r['paths_total']} | "
              f"{r['paths_found']} | {r['max_depth']} | {r['bitmap_cvg'].rstrip('%')} | "
              f"{r['l_per']} | {r['b_per']} | {r['unique_crashes']} | {r['unique_hangs']} |")
    A("")
    A("> `seed_regions` = AFLNet 真实分区器从种子语料切出的消息级区域数；"
      "`字典 token` = 官方字典条目数（**两组相同**，证明字典不是实验变量）。")
    A("> **崩溃**：6 个容器的 `unique_crashes` **全为 0**；`unique_hangs` 仅 SMTP 出现"
      "（protorag 2 / baseline 3）。")
    A("")

    # ---------- 表 2 ----------
    A("## 表 2　两种对齐口径下的组间对比")
    A("")
    A("| 协议 | 口径 A：3 h 终值 Δbitmap_cvg | 口径 B：等执行次数处 Δbitmap_cvg | A/B 同向？ | Δl_per | Δb_per | bitmap_cvg 与 l_per 同向？ |")
    A("|---|---|---|---|---|---|---|")
    for p in PROTOS:
        rp, rb = rows.get(f"{p}/protorag"), rows.get(f"{p}/baseline")
        if not rp or not rb:
            continue
        d_final = _f(rp["bitmap_cvg"]) - _f(rb["bitmap_cvg"])
        d_align = vj.get("seed_effect", {}).get(p, {}).get("aligned_diff_at_window_end")
        same_ab = (d_final == 0 or d_align == 0 or (d_final > 0) == (d_align > 0))
        d_lp = _f(rp["l_per"]) - _f(rb["l_per"])
        d_bp = _f(rp["b_per"]) - _f(rb["b_per"])
        same_lp = (d_final == 0 or d_lp == 0 or (d_final > 0) == (d_lp > 0))
        A(f"| {p} | {sg(d_final)} | {sg(d_align)} | "
          f"{'是' if same_ab else '**否**'} | {sg(d_lp)} | {sg(d_bp)} | "
          f"{'是' if same_lp else '**否**'} |")
    A("")
    A("> **口径 A** = 相同挂钟预算（3 h）下的终值；**口径 B** = 相同执行次数处的插值覆盖，"
      "用于剥离两组执行速率不同带来的混淆（3 h 内 RTSP 两组分别执行 142 878 与 212 619 次，"
      "差异达 49%）。")
    A("> **同向性**为协议级判定：Δ 的符号一致即为「同向」。")
    A("")

    # ---------- 表 3 ----------
    A("## 表 3　对齐窗口与结论稳健性")
    A("")
    A("| 协议 | 对齐窗口（execs） | 公共重叠 | Δcvg 轨迹极值 | 末值 | 符号翻转次数 | 末值/波动幅度 | 结论稳健性 |")
    A("|---|---|---|---|---|---|---|---|")
    for p in PROTOS:
        w = vj.get("windows", {}).get(p, {})
        c = conv.get(p, {})
        span = c.get("span")
        ratio = c.get("abs_end_over_span")
        if span and ratio is not None:
            if ratio < 0.15:
                robust = "**不可区分**（末值仅为波动的 %.0f%%）" % (ratio * 100)
            elif ratio < 0.35:
                robust = "弱区分（末值约为波动的 %.0f%%，方向需谨慎）" % (ratio * 100)
            else:
                robust = "**可区分**（末值显著高于波动幅度）"
        else:
            robust = "—"
        A(f"| {p} | {w.get('common_start_execs')} – {w.get('common_end_execs')} | "
          f"{'✓' if w.get('is_public_overlap') else '✗'} | "
          f"{sg(c.get('diff_min'))} / {sg(c.get('diff_max'))} | {sg(c.get('diff_end'))} | "
          f"{c.get('n_sign_flips', '—')} | "
          f"{'—' if ratio is None else f'{ratio*100:.0f}%'} | {robust} |")
    A("")
    A("> 「Δcvg 轨迹极值」= 在公共 execs 区间上按 400 点密集网格重算 "
      "`bitmap_cvg(protorag) − bitmap_cvg(baseline)` 的取值范围；"
      "「符号翻转次数」= 该差值曲线穿过 0 的次数（0 次 = 方向全程一致）。")
    A("> 「末值/波动幅度」= |终值差| ÷ 整段轨迹波动幅度 —— 越接近 0，说明**单看终值越不可判定优劣**。")
    A("")

    # ---------- 表 4 ----------
    if decomp:
        A("## 表 4　差距来源分解：起跑覆盖 vs 模糊期新增")
        A("")
        A("> 官方 `cov_script` 分两段：**段 1** 逐个回放初始种子（每种子写一行）、"
          "**段 2** 回放 fuzzing 产生的测试用例（每 5 个写一行）。"
          "下表在**各组自身的种子数**处切分两阶段 → "
          "「起跑覆盖」= 种子本身的覆盖面，「模糊期新增」= 变异带来的增量。")
        A("")
        A("| 协议 | 组 | 起跑覆盖 l_abs（种子阶段末） | 模糊期末 l_abs | 模糊期新增 Δl_abs |")
        A("|---|---|---|---|---|")
        for p in PROTOS:
            g = decomp.get(p, {}).get("groups", {})
            for grp in ("protorag", "baseline"):
                if grp not in g:
                    continue
                v = g[grp]
                A(f"| {p} | {grp} | {v['seed_stage_end']['l_abs']:.0f} | "
                  f"{v['fuzz_stage_end']['l_abs']:.0f} | {v['fuzz_gain_l_abs']:+.0f} |")
        A("")
        for p in PROTOS:
            g = decomp.get(p, {}).get("groups", {})
            if len(g) < 2:
                continue
            pv, bv = g["protorag"], g["baseline"]
            d_start = pv["seed_stage_end"]["l_abs"] - bv["seed_stage_end"]["l_abs"]
            d_end = pv["fuzz_stage_end"]["l_abs"] - bv["fuzz_stage_end"]["l_abs"]
            A(f"- **{p}**：起跑差距 **{d_start:+.0f}** 行 → 最终差距 **{d_end:+.0f}** 行"
              f"（模糊期变化 {d_end - d_start:+.0f}）。"
              + (f"protorag 的模糊期 `l_abs` **全程冻结**在 {pv['fuzz_stage_l_abs_max']:.0f}"
                 f"（{pv['n_fuzz_rows']} 个采样点，波动 = 0）→ **撞上覆盖天花板**。"
                 if pv.get("fuzz_stage_l_abs_frozen") else
                 f"protorag 模糊期新增 {pv['fuzz_gain_l_abs']:+.0f} 行，"
                 f"baseline 新增 {bv['fuzz_gain_l_abs']:+.0f} 行。"))
        A("")

    # ---------- 表 5 ----------
    if depth:
        A("## 表 5　两组种子的结构画像（解释差距的来源）")
        A("")
        A("| 协议 | 组 | 种子数 | 单种子命令条数（中位 / 最大） | ≤1 条命令占比 | 单种子字节（中位 / 最大） | 总字节 |")
        A("|---|---|---|---|---|---|---|")
        for p in PROTOS:
            for grp in ("baseline", "protorag"):
                s = depth.get(p, {}).get(grp)
                if not s:
                    continue
                A(f"| {p} | {grp} | {s['n']} | {s['cmd_median']} / {s['cmd_max']} | "
                  f"{s['pct_le1_cmd']}% | {s['byte_median']} / {s['byte_max']} | {s['byte_total']} |")
        A("")
        A("> 「命令条数」= 种子文件内协议请求行的条数，刻画**单个种子能驱动多深的协议会话**。")
        A("> 官方种子虽少（1–7 个），但**每个都是 2–6 条命令的完整会话**；")
        A("> ProtoRAG 种子多，但**单种子会话更浅更碎**（中位 2–4 条命令，"
          "且相当比例只有 0–1 条命令），尤其 SMTP 上出现仅 6–12 字节的单命令种子。")
        A("")

    # ---------- 结果段落 ----------
    A("## 结果")
    A("")
    A("在 3 小时预算、单次运行的条件下，ProtoRAG 生成的种子组与官方镜像自带种子组"
      "在三个协议上的端到端模糊测试效果**并不一致**：")
    A("")
    A("**RTSP.** ProtoRAG 组在两种对齐口径下均取得略高的边覆盖"
      "（3 小时终值 +0.22 个百分点；等执行次数处 +0.31 个百分点），"
      "行覆盖与分支覆盖亦同向领先（+0.50 / +0.30 个百分点）。"
      "值得注意的是两组覆盖率曲线的**交叉**：在约 2.3 万次执行之前，官方种子组领先"
      "（种子阶段结束时官方组已覆盖 5 360 行，ProtoRAG 组为 3 797 行），"
      "而 ProtoRAG 组在随后的模糊阶段新增覆盖达 2 102 行，"
      "为官方组（+415 行）的 5.1 倍，最终完成反超。"
      "这表明 ProtoRAG 种子**起跑覆盖较弱但长程收敛后劲更足**。")
    A("")
    A("**SIP.** 两组在全部口径下**基本持平，本轮无法区分**："
      "3 小时终值边覆盖相差 −0.05 个百分点，等执行次数处相差 +0.03 个百分点，"
      "行覆盖相差 +0.20 个百分点。密集网格检验显示，"
      "该边覆盖差曲线在整个执行区间的波动幅度为 2.64 个百分点，"
      "终值差异仅占其中 **1.1%** —— 远小于两组覆盖率的正常波动，"
      "因此**不能**据任一单点判定优劣。")
    A("")
    A("**SMTP.** 官方种子组在两种对齐口径下均明显更好"
      "（边覆盖 −1.66 个百分点，行覆盖 −8.20 个百分点，分支覆盖 −5.20 个百分点），"
      "且该差值在整段执行区间内**方向从未改变**（0 次符号翻转），"
      "终值幅度显著高于轨迹波动幅度，属**稳健差异**。"
      "分解表明这一差距**并非来自变异效率**：在尚未进行任何 fuzzing 变异的"
      "种子阶段结束时，ProtoRAG 组已覆盖 2 564 行而官方组为 5 704 行（相差 −3 140 行）；"
      "此后 ProtoRAG 组的可执行行覆盖**全程冻结**（3 小时模糊期内新增为 0），"
      "官方组则新增 465 行。因此该差距的根源在**种子本身的覆盖面**，"
      "而非「额外覆盖面换不来收益」。")
    A("")

    # ---------- 局限 ----------
    A("## 局限")
    A("")
    A("**(1) 单次运行，无统计效力。** 每个「协议 × 组」组合仅执行一次（n = 1），"
      "无重复实验，因而无法估计运行间方差。本报告中的全部差值均为**观测值**，"
      "**不具备统计效力**：不构成显著性检验的输入，不可表述为「显著」「优于」"
      "或「提升了 X%」，也不应据此做置信区间估计。"
      "三个协议的组间差异方向彼此不一致（RTSP 偏优、SMTP 明显劣、SIP 不可区分），"
      "单次运行无法区分这一差异是方法本身的效应还是运行间随机波动。")
    A("")
    A("**(2) 固定 3 小时预算，且覆盖率已进入平台期。** 每组实际模糊测试时长约 10 797 秒"
      "（预算 10 800 秒）。在执行区间的最后 10% 内，"
      "三组的边覆盖增量均不超过 0.08 个百分点，说明覆盖率已趋于收敛。"
      "因此本实验测度的是**有限预算内的收敛速度**，"
      "其结论**不可外推**为各方案所能达到的最终覆盖率上限。")
    A("")
    A("**(3) 种子数量、长度与质量三因素未分离。** 两组的种子在三个维度上同时不同："
      "数量（RTSP 39 vs 7、SIP 25 vs 1、SMTP 78 vs 2）、"
      "单种子长度（总字节 RTSP 14 513 vs 5 064、SIP 35 894 vs 1 388、SMTP 7 130 vs 182）、"
      "以及单种子的会话完整性（官方种子每个均为 2–6 条命令的完整协议会话，"
      "ProtoRAG 种子中位仅 2–4 条命令且有相当比例仅含 0–1 条命令）。"
      "因此本实验**无法区分**「种子数量效应」与「单种子质量效应」，"
      "任何「ProtoRAG 种子质量更优/更劣」的因果表述都超出了本设计的可识别范围。")
    A("")
    A("**(4) 官方种子的数量由镜像自带决定，无法对齐。** 官方种子组仅有 1–7 个文件，"
      "而 ProtoRAG 组按设计生成数十个。将 ProtoRAG 组抽样至与官方组相同的数量"
      "会破坏其「基于生成方法」的实验语义；若不抽样，则数量差异始终存在。"
      "本轮实验选择了保留 ProtoRAG 组的完整生成结果，"
      "因而**数量效应与质量效应不可分离**这一局限无法在本轮内消解。")
    A("")
    A("**(5) 崩溃指标全为零，不足以支撑任何「发现漏洞」的表述。** 6 个容器的 "
      "`unique_crashes` **均为 0**；`unique_hangs` 仅 SMTP 出现（2 与 3），"
      "属极低计数，无法判断是真实差异还是随机波动。"
      "本实验**未发现任何崩溃**，故**不可**据此声称 ProtoRAG 种子「更易发现漏洞」"
      "或官方种子「更易发现漏洞」。")
    A("")
    A("**(6) 主指标不覆盖协议状态空间。** `bitmap_cvg` 度量的是 AFL 的**边覆盖**"
      "（`count_non_255_bytes(virgin_bits)`），"
      "**不包含** AFLNet 的消息级状态覆盖。"
      "而 ProtoRAG 的种子本就是按协议状态机分区生成的"
      "（`seed_regions` 为 150 / 112 / 355，对比官方组的 29 / 4 / 14），"
      "这一设计意图**无法**由本轮主指标反映。"
      "若要评估 ProtoRAG 在协议状态空间探索上的作用，需另行引入状态覆盖指标。")
    A("")

    body = "\n".join(M)
    Path(args.out).write_text(body, encoding="utf-8")
    print(f"[qa] 论文可用章节写出: {args.out}  ({len(body)} 字符)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
