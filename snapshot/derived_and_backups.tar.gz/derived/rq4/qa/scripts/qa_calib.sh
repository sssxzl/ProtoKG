#!/bin/bash
docker exec rq4_sip_protorag_r1 bash -c 'python3 - <<PY
src = open("/home/ubuntu/aflnet/afl-fuzz.c", errors="replace").read()
lines = src.split("\n")
start = next(i for i,l in enumerate(lines) if l.startswith("static u8 calibrate_case"))
depth=0; end=start
for i in range(start, min(start+300, len(lines))):
    depth += lines[i].count("{") - lines[i].count("}")
    if depth==0 and i>start: end=i; break
body = "\n".join(lines[start:end+1])
print("calibrate_case 行范围:", start+1, "-", end+1)
print("  体内含 run_target      :", "run_target" in body)
print("  体内含 total_execs++   :", "total_execs++" in body)
for i,l in enumerate(lines[start:end+1], start=start+1):
    if "run_target" in l or "total_execs" in l:
        print(f"  {i}: {l.strip()}")
PY'
echo ""
echo "=== execs_done 字段来源 ==="
docker exec rq4_sip_protorag_r1 bash -c 'grep -n "execs_done" /home/ubuntu/aflnet/afl-fuzz.c | head -5'
