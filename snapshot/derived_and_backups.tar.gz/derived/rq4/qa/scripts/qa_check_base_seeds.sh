#!/bin/bash
for p in live555 kamailio exim; do
  echo "== rq2-$p"
  docker run --rm --entrypoint /bin/bash rq2-$p:latest -c 'ls -la /home/ubuntu/experiments/ | grep in- ; echo "--- content:" ; ls -la /home/ubuntu/experiments/in-* 2>/dev/null | head -15'
done
