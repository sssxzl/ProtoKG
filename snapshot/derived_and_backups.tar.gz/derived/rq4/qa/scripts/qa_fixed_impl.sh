#!/bin/bash
# 验证：把 cov_last_row 换成正确实现后，同一组断言应全部通过（证明测试没有过度约束）
FIXED() {
  local csv="$1" key="$2"
  [[ -s "$csv" ]] || { echo ""; return; }
  local hdr col
  hdr=$(head -1 "$csv" | tr -d '\r')
  echo "$hdr" | grep -q '^Time,' || { echo ""; return; }
  col=$(echo "$hdr" | awk -F',' -v k="$key" '{for(i=1;i<=NF;i++) if($i==k){print i; exit}}')
  [[ -n "$col" ]] || { echo ""; return; }
  tail -1 "$csv" | tr -d '\r' | awk -F',' -v c="$col" '{print $c}'
}
T=$(mktemp -d); printf 'Time,l_per,l_abs,b_per,b_abs\n1793316462,11.9,2809,7.2,1331\n1793316463,13.1,3102,7.9,1455\n1793327218,24.7,5899,15.7,2914\n' > $T/c.csv
echo "  修复实现 l_per = '$(FIXED $T/c.csv l_per)'  (期望 24.7)"
echo "  修复实现 b_per = '$(FIXED $T/c.csv b_per)'  (期望 15.7)"
echo "  修复实现 未知列 = '$(FIXED $T/c.csv nope)'  (期望空)"
printf '' > $T/e.csv;      echo "  修复实现 空文件 = '$(FIXED $T/e.csv l_per)'  (期望空)"
printf 'a,b,c\n1,2,3\n' > $T/b.csv; echo "  修复实现 坏表头 = '$(FIXED $T/b.csv l_per)'  (期望空)"
printf 'Time,l_per,l_abs,b_per,b_abs\n' > $T/h.csv; echo "  修复实现 仅表头 = '$(FIXED $T/h.csv l_per)'  (期望空)"
printf 'Time,l_per,l_abs,b_per,b_abs\r\n1793327218,24.7,5899,15.7,2914\r\n' > $T/crlf.csv
echo "  修复实现 CRLF   = '$(FIXED $T/crlf.csv l_per)'  (期望 24.7)"
rm -rf $T
