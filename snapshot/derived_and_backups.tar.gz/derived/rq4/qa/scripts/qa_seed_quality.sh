#!/bin/bash
# qa_seed_quality.sh —— 量化 SMTP 两组种子的「会话深度 vs 命令广度」
echo "=== 1) protorag 种子是否真的含 STARTTLS / BDAT？（验证 team-lead 的前提）==="
for kw in STARTTLS BDAT DATA RCPT MAIL AUTH LOGIN XCLIENT; do
  n=$(grep -l "^$kw" /home/zxy/rq4/seeds/smtp/*.raw 2>/dev/null | wc -l)
  echo "  protorag 含 '$kw' 的种子数 = $n / 78"
done
echo ""
echo "=== 2) baseline 2 个种子含哪些命令 ==="
docker run --rm --entrypoint /bin/bash rq2-exim:latest -c 'for f in /home/ubuntu/experiments/in-smtp/*.raw; do echo "  -- $f"; sed "s/^/     /" "$f"; done' 2>/dev/null
echo ""
echo "=== 3) protorag 种子字节数分布（会话深度代理指标）==="
stat -c '%s' /home/zxy/rq4/seeds/smtp/*.raw 2>/dev/null | sort -n | awk '
{ a[NR]=$1; s+=$1 }
END {
  printf "  n=%d  min=%d  中位=%d  max=%d  均值=%.1f  总字节=%d\n", NR, a[1], a[int(NR/2)+1], a[NR], s/NR, s
  printf "  ≤50 字节的种子数 = %d (%.0f%%)\n", c50, c50/NR*100
  printf "  ≥100 字节的种子数 = %d\n", c100
}'
stat -c '%s' /home/zxy/rq4/seeds/smtp/*.raw 2>/dev/null | sort -n | uniq -c | awk '{printf "    %s 字节 × %s 个\n", $2, $1}' | head -20
echo ""
echo "=== 4) baseline 2 个种子字节数 ==="
docker run --rm --entrypoint /bin/bash rq2-exim:latest -c 'stat -c "    %s 字节  %n" /home/ubuntu/experiments/in-smtp/*.raw' 2>/dev/null
echo ""
echo "=== 5) protorag 种子的「每文件命令数」分布（会话深度代理指标）==="
for f in /home/zxy/rq4/seeds/smtp/*.raw; do
  tr -d '\r' < "$f" | grep -cE '^[A-Z]{3,5} ' 2>/dev/null
done | sort -n | uniq -c | awk '{printf "    %s 个命令 × %s 个种子\n", $2, $1}'
echo ""
echo "=== 6) baseline 每个种子的命令数 ==="
docker run --rm --entrypoint /bin/bash rq2-exim:latest -c 'for f in /home/ubuntu/experiments/in-smtp/*.raw; do n=$(grep -cE "^[A-Z]{3,5} " "$f"); echo "    $n 个命令  $f"; done' 2>/dev/null
