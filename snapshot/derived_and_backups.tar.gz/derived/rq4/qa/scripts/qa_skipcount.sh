#!/bin/bash
echo "=== 各镜像 run.sh 里的 SKIPCOUNT / TIMEOUT / FUZZER ==="
for img in rq2-live555:latest rq2-kamailio:latest rq2-exim:latest; do
  echo "--- $img"
  docker run --rm --entrypoint /bin/bash "$img" -c 'grep -nE "SKIPCOUNT=|TIMEOUT=|FUZZER=|cov_script" /home/ubuntu/experiments/run | head -12'
done
