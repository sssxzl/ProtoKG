# RQ4 实验结果

## RQ4 结果对比（protorag vs baseline）

### rtsp

| 指标 | baseline (n=1) | protorag (n=1) |
|---|---|---|
| bitmap_cvg(%) [主] | 9.31 | 9.26 |
| execs_done | 24210.00 | 22436.00 |
| execs_per_sec | 26.83 | 23.98 |
| paths_total | 567.00 | 490.00 |
| paths_found | 560.00 | 451.00 |
| max_depth | 4.00 | 4.00 |
| stability(%) | 31.34 | 19.63 |
| unique_crashes | 0.00 | 0.00 |
| unique_hangs | 0.00 | 0.00 |
| fuzz_sec | 787.00 | 793.00 |
| peak_rss_mb | — | — |
| seed_files(种子文件数) | 7.00 | 39.00 |
| seed_regions(AFLNet 分区数) | 29.00 | 150.00 |
| dict_tokens(官方字典条目) | 24.00 | 24.00 |
| l_per(%) [次要·行覆盖] | — | — |
| b_per(%) [次要·分支覆盖] | — | — |
| 参数自检(command_line) | OK | OK |

### sip

| 指标 | baseline (n=1) | protorag (n=1) |
|---|---|---|
| bitmap_cvg(%) [主] | 19.46 | 18.54 |
| execs_done | 4497.00 | 3973.00 |
| execs_per_sec | 5.67 | 4.81 |
| paths_total | 317.00 | 339.00 |
| paths_found | 315.00 | 314.00 |
| max_depth | 2.00 | 2.00 |
| stability(%) | 58.77 | 90.67 |
| unique_crashes | 0.00 | 0.00 |
| unique_hangs | 0.00 | 0.00 |
| fuzz_sec | 790.00 | 786.00 |
| peak_rss_mb | 31.00 | 31.00 |
| seed_files(种子文件数) | 1.00 | 25.00 |
| seed_regions(AFLNet 分区数) | 4.00 | 112.00 |
| dict_tokens(官方字典条目) | 0.00 | 0.00 |
| l_per(%) [次要·行覆盖] | — | — |
| b_per(%) [次要·分支覆盖] | — | — |
| 参数自检(command_line) | OK | OK |

### smtp

| 指标 | baseline (n=1) | protorag (n=1) |
|---|---|---|
| bitmap_cvg(%) [主] | 10.46 | 9.46 |
| execs_done | 1603.00 | 1485.00 |
| execs_per_sec | 2.16 | 1.58 |
| paths_total | 57.00 | 88.00 |
| paths_found | 55.00 | 9.00 |
| max_depth | 2.00 | 2.00 |
| stability(%) | 72.89 | 71.54 |
| unique_crashes | 0.00 | 0.00 |
| unique_hangs | 0.00 | 0.00 |
| fuzz_sec | 783.00 | 774.00 |
| peak_rss_mb | 14.00 | 14.00 |
| seed_files(种子文件数) | 2.00 | 78.00 |
| seed_regions(AFLNet 分区数) | 14.00 | 355.00 |
| dict_tokens(官方字典条目) | 14.00 | 14.00 |
| l_per(%) [次要·行覆盖] | — | — |
| b_per(%) [次要·分支覆盖] | — | — |
| 参数自检(command_line) | OK | OK |

## 自证：两组之间只有种子不同

| 协议 | 组 | seed_files | seed_regions | dict_tokens | 字典一致 |
|---|---|---|---|---|---|
| rtsp | baseline | 7 | 29.0 | 24 | |
| rtsp | protorag | 39 | 150.0 | 24 | |
| rtsp | **字典一致性** | | | | ✓ 相同（24.0） |
| sip | baseline | 1 | 4.0 | 0 | |
| sip | protorag | 25 | 112.0 | 0 | |
| sip | **字典一致性** | | | | ✓ 相同（0.0） |
| smtp | baseline | 2 | 14.0 | 14 | |
| smtp | protorag | 78 | 355.0 | 14 | |
| smtp | **字典一致性** | | | | ✓ 相同（14.0） |

## 次要指标：官方 l_per / b_per 与主指标 bitmap_cvg 并列

> `bitmap_cvg` = AFLNet 自报边覆盖；`l_per`/`b_per` = cov_script 行/分支覆盖。
> 二者不是同一个量，**不换算、不取舍**；方向不一致时如实标注。

| 协议 | 指标 | protorag | baseline | 差值 | 同向 |
|---|---|---|---|---|---|
| rtsp | l_per(%) [次要·行覆盖] | — | — | — | — |
| rtsp | b_per(%) [次要·分支覆盖] | — | — | — | — |
| rtsp | bitmap_cvg(%) [主] | 9.26 | 9.31 | -0.05 | 否 |
| sip | l_per(%) [次要·行覆盖] | — | — | — | — |
| sip | b_per(%) [次要·分支覆盖] | — | — | — | — |
| sip | bitmap_cvg(%) [主] | 18.54 | 19.46 | -0.92 | 否 |
| smtp | l_per(%) [次要·行覆盖] | — | — | — | — |
| smtp | b_per(%) [次要·分支覆盖] | — | — | — | — |
| smtp | bitmap_cvg(%) [主] | 9.46 | 10.46 | -1.00 | 否 |

### 口径一致性检查

- **全部协议**（rtsp, sip, smtp）都缺 l_per/b_per（`cov_over_time.csv` 尚未生成 —— 它由 fuzz 结束后的 cov_script 产出）→ **本次无法做口径一致性判定**。

## execs_done 对齐的 bitmap_cvg（主指标口径）

| 协议 | 对齐 execs_done | protorag bitmap_cvg | baseline bitmap_cvg | 差值 |
|---|---|---|---|---|
| rtsp | 6295 | 8.76 | 9.14 | -0.39 |
| rtsp | 12118 | 8.96 | 9.19 | -0.22 |
| rtsp | 17941 | 9.14 | 9.25 | -0.11 |
| rtsp | 23764 | 9.40 | 9.31 | +0.09 |
| sip | 1336 | 15.29 | 17.70 | -2.41 |
| sip | 2311 | 16.48 | 18.28 | -1.80 |
| sip | 3286 | 18.10 | 19.04 | -0.94 |
| sip | 4262 | 18.96 | 19.40 | -0.44 |
| smtp | 1438 | 9.45 | 10.46 | -1.01 |
| smtp | 1483 | 9.46 | 10.46 | -1.00 |
| smtp | 1528 | 9.46 | 10.46 | -1.00 |
| smtp | 1573 | 9.46 | 10.46 | -1.00 |

